/* =========================================================================
   MODULE 6b — Term registration data layer (admin Student Registration
   Management). Backend integration: talks to the real API (/backend, see
   src/routes/registrations.js). GET /api/registrations is already scoped
   server-side (admin=all, student=own), so forStudent() is a client-side
   re-filter of that same cache, kept for backward compatibility.

   Data model:
   {
     id, studentEmail, studentName, term, yearLevel, type: 'Regular' | 'Irregular',
     status: 'pending' | 'approved' | 'rejected',
     submittedAt, decidedAt
   }

   Used by:
   - student-dashboard.html (dashboard-portal.js) → add(), forStudent()
   - admin/dashboard.html   (admin-enrollment-mgmt.js) → all(), approve(), reject(), pendingCount()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('registrations.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function normEmail(e) { return String(e || '').trim().toLowerCase(); }
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-registrations:changed')); } catch (e) { /* no-op */ } }

  function all() { return records.slice().sort(function (a, b) { return (b.submittedAt || '').localeCompare(a.submittedAt || ''); }); }
  function forStudent(email) {
    var target = normEmail(email);
    if (!target) return [];
    return all().filter(function (r) { return r.studentEmail === target; });
  }
  function pendingCount() { return records.filter(function (r) { return r.status === 'pending'; }).length; }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/registrations')
      .then(function (data) { records = data.registrations || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/registrations', data)
      .then(function (res) { records.push(res.registration); notify(); return { record: res.registration }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function setStatus(id, action) {
    return api.post('/registrations/' + id + '/' + action, {})
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.registration : r; });
        notify();
        return res.registration;
      })
      .catch(function () { return null; });
  }
  function approve(id) { return setStatus(id, 'approve'); }
  function reject(id) { return setStatus(id, 'reject'); }

  var ready = refresh();

  global.TCCRegistrations = {
    ready: ready,
    refresh: refresh,
    all: all, forStudent: forStudent, pendingCount: pendingCount,
    add: add, approve: approve, reject: reject,
    onChange: function (fn) { global.addEventListener('tcc-registrations:changed', fn); }
  };
})(window);
