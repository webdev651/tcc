/* =========================================================================
   MODULE 5c — Feedback & suggestions data layer.
   Backend integration: talks to the real API (/backend, see
   src/routes/feedback.js). GET /api/feedback is already scoped
   server-side (admin=all, else own), so forUser() is a client-side
   re-filter of that same cache, kept for backward compatibility.

   Data model:
   {
     id, name, email, role: 'student' | 'teacher',
     category: 'General' | 'Academics' | 'Facilities' | 'Faculty' | 'Suggestion',
     subject, message,
     status: 'new' | 'resolved',
     response, submittedAt, respondedAt
   }

   Used by:
   - student-dashboard.html (dashboard-portal.js) → add(), forUser()
   - teacher-dashboard.html (teacher-portal.js)   → add(), forUser()
   - admin/dashboard.html   (admin-content.js)    → all(), respond()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('feedback.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var items = [];
  function normEmail(email) { return String(email || '').trim().toLowerCase(); }
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-feedback:changed')); } catch (e) { /* no-op */ } }

  function all() {
    return items.slice().sort(function (a, b) { return (b.submittedAt || '').localeCompare(a.submittedAt || ''); });
  }
  function forUser(email) {
    var target = normEmail(email);
    if (!target) return [];
    return all().filter(function (f) { return f.email === target; });
  }
  function pendingCount() {
    return items.filter(function (f) { return f.status !== 'resolved'; }).length;
  }

  function refresh() {
    if (!api.getToken()) { items = []; notify(); return Promise.resolve(items); }
    return api.get('/feedback')
      .then(function (data) { items = data.feedback || []; notify(); return items; })
      .catch(function () { items = []; notify(); return items; });
  }

  function add(data) {
    return api.post('/feedback', data)
      .then(function (res) { items.push(res.feedback); notify(); return { record: res.feedback }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  /* Admin's reply — sets the response text and marks the item resolved
     in one step, since there's nothing left to review once it's answered. */
  function respond(id, response) {
    return api.post('/feedback/' + id + '/respond', { response: response })
      .then(function (res) {
        items = items.map(function (f) { return f.id === id ? res.feedback : f; });
        notify();
        return res.feedback;
      })
      .catch(function () { return null; });
  }

  function remove(id) {
    return api.del('/feedback/' + id)
      .then(function (res) {
        if (res.deleted) { items = items.filter(function (f) { return f.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  var ready = refresh();

  global.TCCFeedback = {
    ready: ready,
    refresh: refresh,
    all: all,
    forUser: forUser,
    pendingCount: pendingCount,
    add: add,
    respond: respond,
    remove: remove,
    onChange: function (fn) { global.addEventListener('tcc-feedback:changed', fn); }
  };
})(window);
