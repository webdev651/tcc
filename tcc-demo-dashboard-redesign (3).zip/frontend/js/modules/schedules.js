/* =========================================================================
   MODULE 6d — Class schedule data layer (admin Class Schedule Management).
   Backend integration: talks to the real API (/backend, see
   src/routes/schedules.js). Any signed-in role can read the full
   schedule; only admin can add/update/remove (enforced server-side too).

   Data model:
   {
     id, subject, section, day, time, room,
     teacherName, teacherEmail, term,
     createdAt, updatedAt
   }

   Used by:
   - admin/dashboard.html (admin-schedule.js) → all() / add() / update() / remove()
   - teacher-dashboard.html (teacher-portal.js) → byTeacherName()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('schedules.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-schedules:changed')); } catch (e) { /* no-op */ } }

  function all() {
    return records.slice().sort(function (a, b) { return a.subject.localeCompare(b.subject) || a.section.localeCompare(b.section); });
  }
  function byTeacherName(name) {
    var target = String(name || '').trim().toLowerCase();
    if (!target) return all();
    return all().filter(function (r) { return String(r.teacherName || '').trim().toLowerCase() === target; });
  }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/schedules')
      .then(function (data) { records = data.schedules || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/schedules', data)
      .then(function (res) { records.push(res.schedule); notify(); return { record: res.schedule }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function update(id, data) {
    return api.put('/schedules/' + id, data)
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.schedule : r; });
        notify();
        return { record: res.schedule };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function remove(id) {
    return api.del('/schedules/' + id)
      .then(function (res) {
        if (res.deleted) { records = records.filter(function (r) { return r.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  var ready = refresh();

  global.TCCSchedules = {
    ready: ready,
    refresh: refresh,
    all: all, byTeacherName: byTeacherName, add: add, update: update, remove: remove,
    onChange: function (fn) { global.addEventListener('tcc-schedules:changed', fn); }
  };
})(window);
