/* =========================================================================
   Staff directory data layer (admin Staff Management screen). Talks to the
   real API (/backend, see src/routes/staff.js) — same pattern as
   js/modules/profiles.js.

   Data model:
   { id, name, email, department, subjects, load, createdAt, updatedAt }

   Used by:
   - admin/dashboard.html (admin-staff.js) → all() / add() / update() / remove()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('staff.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function notify() {
    try { global.dispatchEvent(new CustomEvent('tcc-staff:changed')); } catch (e) { /* no-op */ }
  }

  function all() { return records.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }); }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/staff')
      .then(function (data) { records = data.staff || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/staff', data)
      .then(function (res) { records.push(res.staff); notify(); return { record: res.staff }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function update(id, data) {
    return api.put('/staff/' + id, data)
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.staff : r; });
        notify();
        return { record: res.staff };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function remove(id) {
    return api.del('/staff/' + id)
      .then(function (res) {
        if (res.deleted) { records = records.filter(function (r) { return r.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  var ready = refresh();

  global.TCCStaff = {
    ready: ready,
    refresh: refresh,
    all: all, add: add, update: update, remove: remove,
    onChange: function (fn) { global.addEventListener('tcc-staff:changed', fn); }
  };
})(window);
