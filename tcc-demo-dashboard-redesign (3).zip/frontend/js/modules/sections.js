/* =========================================================================
   Section management data layer (admin Sections screen). Talks to the
   real API (/backend, see src/routes/sections.js) — same pattern as
   js/modules/staff.js.

   Data model:
   { id, sectionCode, program, yearLevel, term, teacherId, teacherName,
     teacherEmail, studentCount, createdAt, updatedAt }
   teacherId/studentId everywhere here are users.id — the same ids used
   by js/core/accounts.js — not the internal Phase 3 teachers.id/students.id.

   Used by:
   - admin/dashboard.html (admin-sections.js) → all() / add() / update() /
     remove() / roster() / addStudent() / removeStudent()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('sections.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function notify() {
    try { global.dispatchEvent(new CustomEvent('tcc-sections:changed')); } catch (e) { /* no-op */ }
  }

  function all() {
    return records.slice().sort(function (a, b) { return a.sectionCode.localeCompare(b.sectionCode); });
  }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/sections')
      .then(function (data) { records = data.sections || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/sections', data)
      .then(function (res) { records.push(res.section); notify(); return { record: res.section }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function update(id, data) {
    return api.put('/sections/' + id, data)
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.section : r; });
        notify();
        return { record: res.section };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function remove(id) {
    return api.del('/sections/' + id)
      .then(function (res) {
        if (res.deleted) { records = records.filter(function (r) { return r.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  function roster(id) {
    return api.get('/sections/' + id + '/students')
      .then(function (data) { return data.students || []; })
      .catch(function () { return []; });
  }

  function addStudent(sectionId, studentUserId) {
    return api.post('/sections/' + sectionId + '/students', { studentId: studentUserId })
      .then(function (res) { refresh(); return { record: res.student }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function removeStudent(sectionId, studentUserId) {
    return api.del('/sections/' + sectionId + '/students/' + studentUserId)
      .then(function (res) { if (res.deleted) refresh(); return res.deleted; })
      .catch(function () { return false; });
  }

  // "Send to Teacher" — confirms the assigned teacher + current roster,
  // notifies them (shows up on their Notifications feed), and marks the
  // section Sent. See src/routes/sections.js POST /:id/send for details.
  function sendToTeacher(id) {
    return api.post('/sections/' + id + '/send', {})
      .then(function (res) {
        records = records.map(function (r) { return r.id === res.section.id ? res.section : r; });
        notify();
        return { record: res.section };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  var ready = refresh();

  global.TCCSections = {
    ready: ready,
    refresh: refresh,
    all: all, add: add, update: update, remove: remove,
    roster: roster, addStudent: addStudent, removeStudent: removeStudent,
    sendToTeacher: sendToTeacher,
    onChange: function (fn) { global.addEventListener('tcc-sections:changed', fn); }
  };
})(window);
