/* =========================================================================
   MODULE 6g — "My students" data layer (teacher-only).
   Backend integration: talks to the real API (/backend, see
   src/routes/roster.js). Returns only the signed-in teacher's own
   students — graded by them, or enrolled in a subject on their Class
   Schedule — never the whole student body.

   Data model (one object per student):
   { email, name, subjects: string[] }

   Used by:
   - teacher-dashboard.html (teacher-portal.js) → all(), count()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('roster.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-roster:changed')); } catch (e) { /* no-op */ } }

  function all() {
    return records.slice();
  }
  function count() {
    return records.length;
  }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/roster')
      .then(function (data) { records = data.students || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  var ready = refresh();

  global.TCCRoster = {
    ready: ready,
    all: all,
    count: count,
    refresh: refresh,
    onChange: function (fn) { global.addEventListener('tcc-roster:changed', fn); }
  };
})(window);
