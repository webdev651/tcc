/* =========================================================================
   MODULE 5a — Grades data layer.
   Backend integration: talks to the real API (/backend, see
   src/routes/grades.js). The backend already scopes GET /api/grades to
   the signed-in role (admin=all, teacher=own, student=own), so all(),
   forStudent() and byTeacher() below are just synchronous reads of
   whatever the last refresh() populated.

   Data model (one object per student + subject + term entry):
   {
     id, studentEmail, studentName, subject, term,
     teacherEmail, teacherName,
     midterm, final,     // numbers 0-100, or null if not yet entered
     remarks,
     adminStatus: 'pending' | 'verified',
     enteredAt, updatedAt
   }

   Used by:
   - teacher-dashboard.html (teacher-portal.js) → add() / update() / remove() / byTeacher()
   - student-dashboard.html (dashboard-portal.js) → forStudent()
   - admin/dashboard.html (admin-grades.js) → all() / verify() / update() / remove()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('grades.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function normEmail(email) { return String(email || '').trim().toLowerCase(); }
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-grades:changed')); } catch (e) { /* no-op */ } }

  /* A student's overall standing for one record, derived from whichever of
     midterm/final have been entered so far. */
  function computeStatus(midterm, final) {
    var vals = [midterm, final].filter(function (v) { return v !== null && v !== undefined; });
    if (!vals.length) return 'pending';
    var avg = vals.reduce(function (a, b) { return a + b; }, 0) / vals.length;
    return avg >= 75 ? 'passing' : 'failing';
  }

  function all() {
    return records.slice().sort(function (a, b) { return (b.updatedAt || '').localeCompare(a.updatedAt || ''); });
  }
  function forStudent(email) {
    var target = normEmail(email);
    if (!target) return [];
    return all().filter(function (r) { return r.studentEmail === target; });
  }
  function byTeacher(email) {
    var target = normEmail(email);
    if (!target) return all();
    return all().filter(function (r) { return r.teacherEmail === target; });
  }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/grades')
      .then(function (data) { records = data.grades || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/grades', data)
      .then(function (res) { records.push(res.grade); notify(); return { record: res.grade }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function update(id, data) {
    return api.put('/grades/' + id, data)
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.grade : r; });
        notify();
        return { record: res.grade };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function verify(id) {
    return api.post('/grades/' + id + '/verify', {})
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.grade : r; });
        notify();
        return { record: res.grade };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function remove(id) {
    return api.del('/grades/' + id)
      .then(function (res) {
        if (res.deleted) { records = records.filter(function (r) { return r.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  var ready = refresh();

  global.TCCGrades = {
    ready: ready,
    refresh: refresh,
    all: all,
    forStudent: forStudent,
    byTeacher: byTeacher,
    add: add,
    update: update,
    remove: remove,
    verify: verify,
    computeStatus: computeStatus,
    onChange: function (fn) { global.addEventListener('tcc-grades:changed', fn); }
  };
})(window);
