/* =========================================================================
   MODULE 6h — "My sections" data layer (teacher-only). Sections the
   signed-in teacher is currently assigned as adviser/teacher for, each
   with its full active student roster inline. Backend integration: talks
   to the real API (/backend, see src/routes/teacher.js GET /sections).

   Data model:
   { id, sectionCode, program, yearLevel, term, studentCount,
     students: [{ id, studentId, name, email, program, yearLevel }] }

   Purely a live read of the current admin-side assignment — if admin
   reassigns a section to someone else, refresh()ing this simply stops
   returning it (and it starts showing up for the new teacher instead).

   Used by:
   - teacher-dashboard.html (teacher-sections.js) → all()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('teacher-sections.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-teacher-sections:changed')); } catch (e) { /* no-op */ } }

  function all() { return records.slice(); }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/teacher/sections')
      .then(function (data) { records = data.sections || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  var ready = refresh();

  global.TCCTeacherSections = {
    ready: ready,
    all: all,
    refresh: refresh,
    onChange: function (fn) { global.addEventListener('tcc-teacher-sections:changed', fn); }
  };
})(window);
