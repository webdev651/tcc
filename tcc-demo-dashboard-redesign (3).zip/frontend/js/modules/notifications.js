/* =========================================================================
   MODULE 6f — Notifications data layer (admin Notification Management).
   Backend integration: talks to the real API (/backend, see
   src/routes/notifications.js). Admin-only, same as before. The server
   promotes due "scheduled" notifications to "sent" on every GET, so
   checkScheduled() below just re-fetches instead of mutating a local
   clock check.

   Data model:
   {
     id, title, message,
     recipientType: 'all' | 'student' | 'teacher' | 'specific',
     recipientEmail,
     scheduledFor,
     status: 'scheduled' | 'sent',
     createdAt, sentAt
   }

   Used by:
   - admin/dashboard.html (admin-notifications.js) → all(), add(), cancel(), remove(), checkScheduled()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('notifications.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var items = [];
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-notifications:changed')); } catch (e) { /* no-op */ } }

  function all() { return items.slice().sort(function (a, b) { return (b.createdAt || '').localeCompare(a.createdAt || ''); }); }
  function forRecipient(role, email) {
    var target = String(email || '').trim().toLowerCase();
    return all().filter(function (n) {
      if (n.status !== 'sent') return false;
      if (n.recipientType === 'all') return true;
      if (n.recipientType === role) return true;
      if (n.recipientType === 'specific') return target && n.recipientEmail === target;
      return false;
    });
  }
  function scheduledCount() { return items.filter(function (n) { return n.status === 'scheduled'; }).length; }

  function refresh() {
    if (!api.getToken()) { items = []; notify(); return Promise.resolve(items); }
    // The backend promotes any due "scheduled" notification to "sent" as
    // part of this GET, so a plain refresh is all checkScheduled() needs.
    return api.get('/notifications')
      .then(function (data) { items = data.notifications || []; notify(); return items; })
      .catch(function () { items = []; notify(); return items; });
  }

  function add(data) {
    return api.post('/notifications', data)
      .then(function (res) { items.push(res.notification); notify(); return { record: res.notification }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function checkScheduled() { return refresh(); }

  function cancel(id) {
    return api.post('/notifications/' + id + '/cancel', {})
      .then(function (res) {
        if (res.notification) { items = items.filter(function (n) { return n.id !== id; }); notify(); }
        return res.notification;
      })
      .catch(function () { return null; });
  }

  function remove(id) {
    return api.del('/notifications/' + id)
      .then(function (res) {
        if (res.deleted) { items = items.filter(function (n) { return n.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  var ready = refresh();

  global.TCCNotifications = {
    ready: ready,
    all: all, forRecipient: forRecipient, scheduledCount: scheduledCount,
    add: add, checkScheduled: checkScheduled, cancel: cancel, remove: remove,
    refresh: refresh,
    onChange: function (fn) { global.addEventListener('tcc-notifications:changed', fn); }
  };
})(window);
