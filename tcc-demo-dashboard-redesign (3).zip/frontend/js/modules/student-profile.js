/* =========================================================================
   Student — own Profile tab (student-dashboard.html only).

   Reads the signed-in student's own record via GET /api/profiles/me
   (backend/src/routes/profiles.js) and fills in the profile-head block —
   name, Student ID, program, and the status / year level / section badges
   — so a section an admin assigns (Admin Dashboard → Students → All
   Student Accounts → Section column) shows up here for real, instead of
   the static "BSCS-2A" placeholder the markup ships with.

   Guarded by element presence, same convention as the rest of
   js/modules/*.js — a no-op on any page without a #profile block (i.e.
   everywhere except student-dashboard.html).
   ========================================================================= */
(function () {
  if (!window.TCCApi) return;
  var api = window.TCCApi;

  var nameEl = document.querySelector('#profile .profile-head-name');
  var detailEl = document.querySelector('#profile .profile-head-detail');
  var badgesEl = document.querySelector('#profile .profile-head-badges');
  var avatarEl = document.querySelector('#profile .profile-avatar-lg');
  if (!nameEl && !badgesEl) return;

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function initials(name) {
    var parts = String(name || '').trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return '?';
    return (parts[0][0] + (parts[1] ? parts[1][0] : '')).toUpperCase();
  }

  function render(p) {
    if (nameEl) nameEl.textContent = p.name || '\u2014';
    if (avatarEl) avatarEl.textContent = initials(p.name);

    if (detailEl) {
      var bits = [];
      if (p.studentId) bits.push('Student ID ' + p.studentId);
      if (p.program) bits.push(p.program);
      detailEl.textContent = bits.length ? bits.join(' \u00b7 ') : '\u2014';
    }

    if (badgesEl) {
      var badges = [];
      badges.push('<span class="badge badge--good">' + escapeHtml(p.status || 'Regular') + '</span>');
      if (p.yearLevel) badges.push('<span class="badge badge--muted">' + escapeHtml(p.yearLevel) + '</span>');
      // A student who hasn't been placed in a section yet sees that
      // plainly, rather than a leftover demo section that was never theirs.
      badges.push(p.section
        ? '<span class="badge badge--muted">Section ' + escapeHtml(p.section) + '</span>'
        : '<span class="badge badge--warn">No section assigned yet</span>');
      badgesEl.innerHTML = badges.join('');
    }
  }

  api.get('/profiles/me')
    .then(function (data) { if (data && data.profile) render(data.profile); })
    .catch(function () { /* leave the static placeholder in place, e.g. if offline */ });
})();
