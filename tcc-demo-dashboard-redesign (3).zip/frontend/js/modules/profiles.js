/* =========================================================================
   MODULE 6a — Student profiles data layer (admin Student Profile Management).
   Backend integration: talks to the real API (/backend, see
   src/routes/profiles.js) instead of localStorage. Same public interface
   as before — admin-students.js just needs its add/update calls to
   handle a Promise now (see that file's own comment).

   Data model:
   {
     id, name, email, studentId, program, yearLevel, section,
     status: 'Regular' | 'Irregular' | 'Inactive',
     dateOfBirth, sex, civilStatus, nationality, religion, address, mobile,
     guardianName, guardianContact, adviser, dateAdmitted,
     createdAt, updatedAt
   }

   Used by:
   - admin/dashboard.html (admin-students.js) → all() / add() / update() / remove() / findByEmail()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('profiles.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function normEmail(e) { return String(e || '').trim().toLowerCase(); }
  function notify() {
    try { global.dispatchEvent(new CustomEvent('tcc-profiles:changed')); } catch (e) { /* no-op */ }
  }

  function all() { return records.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }); }
  function findByEmail(email) {
    var target = normEmail(email);
    if (!target) return null;
    return records.filter(function (r) { return normEmail(r.email) === target; })[0] || null;
  }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/profiles')
      .then(function (data) { records = data.profiles || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/profiles', data)
      .then(function (res) { records.push(res.profile); notify(); return { record: res.profile }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function update(id, data) {
    return api.put('/profiles/' + id, data)
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.profile : r; });
        notify();
        return { record: res.profile };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function remove(id) {
    return api.del('/profiles/' + id)
      .then(function (res) {
        if (res.deleted) { records = records.filter(function (r) { return r.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  var ready = refresh();

  global.TCCProfiles = {
    ready: ready,
    refresh: refresh,
    all: all, findByEmail: findByEmail, add: add, update: update, remove: remove,
    onChange: function (fn) { global.addEventListener('tcc-profiles:changed', fn); }
  };
})(window);
