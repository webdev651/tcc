/* =========================================================================
   MODULE 5b / FEATURE 6 — Announcements data layer (Announcement Center).
   Backend integration: talks to the real API (/backend, see
   src/routes/announcements.js). GET /api/announcements is already
   audience-filtered server-side to whatever the signed-in role should
   see (including this reader's own read/unread state), so forAudience()
   below is just a client-side re-filter of that same (already-scoped)
   cache — kept for backward compatibility with existing callers.

   Data model (one object per announcement):
   {
     id, title, body,
     audience: 'all' | 'student' | 'teacher',
     category: 'General' | 'Academic' | 'Enrollment' | 'Registration' | 'Schedule' | 'Important',
     priority: 'Low' | 'Normal' | 'High' | 'Urgent',
     status: 'Published' | 'Draft' | 'Archived',
     postedByName, postedByRole: 'teacher' | 'admin', postedByEmail,
     postedAt,
     readAt, isRead
   }

   Used by:
   - js/core/announcement-center.js          → the shared search/filter/sort/
     detail-view UI, mounted on all three dashboards
   - teacher-dashboard.html (teacher-portal.js)   → add() (audience 'student'), byPoster()
   - admin/dashboard.html   (admin-content.js)    → add() (audience 'all'), all(), remove()
   - student-dashboard.html (dashboard-portal.js) → forAudience('student')
   - teacher-dashboard.html (teacher-portal.js)   → forAudience('teacher') for the college-wide feed
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('announcements.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var CATEGORIES = ['General', 'Academic', 'Enrollment', 'Registration', 'Schedule', 'Important'];
  var PRIORITIES = ['Low', 'Normal', 'High', 'Urgent'];
  var STATUSES = ['Published', 'Draft', 'Archived'];

  var records = [];
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-announcements:changed')); } catch (e) { /* no-op */ } }
  // The backend has no concept of "seed" announcements anymore (Phase 2
  // tables start empty) — isSeed() is kept only so old callers that still
  // check it don't error; nothing posted through the real API is ever a seed.
  function isSeed() { return false; }

  function all() {
    return records.slice().sort(function (a, b) { return (b.postedAt || '').localeCompare(a.postedAt || ''); });
  }
  function forAudience(role) {
    return all().filter(function (a) { return a.audience === 'all' || a.audience === role; });
  }
  function byPoster(name) {
    var target = String(name || '').trim();
    if (!target) return [];
    return all().filter(function (a) { return a.postedByName === target; });
  }
  function unreadCount(role) {
    var items = role ? forAudience(role) : all();
    return items.filter(function (a) { return !a.isRead; }).length;
  }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/announcements')
      .then(function (data) { records = data.announcements || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/announcements', data)
      .then(function (res) { records.push(res.announcement); notify(); return { record: res.announcement }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function update(id, data) {
    return api.put('/announcements/' + id, data)
      .then(function (res) {
        records = records.map(function (a) { return a.id === id ? res.announcement : a; });
        notify();
        return { record: res.announcement };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function remove(id) {
    return api.del('/announcements/' + id)
      .then(function (res) {
        if (res.deleted) { records = records.filter(function (a) { return a.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  // markRead()/markUnread() update the local cache optimistically (so the
  // Announcement Center's unread dot / filter reacts immediately) and are
  // reconciled with whatever the server actually stored once the request
  // resolves. Silent no-op on failure — read state is a nice-to-have, not
  // something worth surfacing an error toast for.
  function markRead(id) {
    var record = records.filter(function (a) { return a.id === id; })[0];
    if (record && record.isRead) return Promise.resolve(true);
    if (record) { record.isRead = true; record.readAt = record.readAt || new Date().toISOString(); notify(); }
    return api.post('/announcements/' + id + '/read')
      .then(function (res) {
        if (record) { record.readAt = res.readAt || record.readAt; notify(); }
        return true;
      })
      .catch(function () { return false; });
  }
  function markUnread(id) {
    var record = records.filter(function (a) { return a.id === id; })[0];
    if (record) { record.isRead = false; record.readAt = null; notify(); }
    return api.del('/announcements/' + id + '/read')
      .then(function () { return true; })
      .catch(function () { return false; });
  }

  var ready = refresh();

  global.TCCAnnouncements = {
    ready: ready,
    CATEGORIES: CATEGORIES,
    PRIORITIES: PRIORITIES,
    STATUSES: STATUSES,
    all: all,
    forAudience: forAudience,
    byPoster: byPoster,
    unreadCount: unreadCount,
    add: add,
    update: update,
    remove: remove,
    markRead: markRead,
    markUnread: markUnread,
    isSeed: isSeed,
    refresh: refresh,
    onChange: function (fn) { global.addEventListener('tcc-announcements:changed', fn); }
  };
})(window);
