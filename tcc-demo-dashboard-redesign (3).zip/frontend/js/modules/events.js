/* =========================================================================
   Feature 4 — Events data layer (Upcoming Events widget). Backend
   integration: talks to the real API (/backend, see src/routes/events.js).
   GET /api/events is already audience-scoped server-side (admin=all,
   student/teacher='all' + their own role), so all() below is just a
   synchronous read of whatever the last refresh() populated — same
   pattern as every other js/modules/*.js file.

   Data model:
   {
     id, title, description,
     type: 'announcement' | 'registration_deadline' | 'enrollment_deadline'
           | 'school_event' | 'activity',
     eventDate, audience: 'all' | 'student' | 'teacher',
     createdByName, createdByEmail, createdAt
   }

   Only admin can add/update/remove (enforced server-side too, same
   boundary as js/modules/notifications.js).

   Used by:
   - js/core/upcoming-events.js (all three dashboards) → all(), upcoming()
   - admin/dashboard.html (js/admin/admin-events.js) → add() / update() / remove()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('events.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-events:changed')); } catch (e) { /* no-op */ } }

  function all() {
    return records.slice().sort(function (a, b) { return String(a.eventDate).localeCompare(String(b.eventDate)); });
  }
  /* Same list, filtered to event_date >= now — what the widget itself
     wants; kept here too (not just server-side ?upcoming=1) so a plain
     refresh() still lets other callers (e.g. an admin "all events" table)
     read every record via all(). */
  function upcoming() {
    var now = new Date();
    return all().filter(function (e) { var d = new Date(e.eventDate); return !isNaN(d) && d >= now; });
  }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/events')
      .then(function (data) { records = data.events || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/events', data)
      .then(function (res) { records.push(res.event); notify(); return { record: res.event }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function update(id, data) {
    return api.put('/events/' + id, data)
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.event : r; });
        notify();
        return { record: res.event };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function remove(id) {
    return api.del('/events/' + id)
      .then(function (res) {
        if (res.deleted) { records = records.filter(function (r) { return r.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  var ready = refresh();

  global.TCCEvents = {
    ready: ready,
    refresh: refresh,
    all: all,
    upcoming: upcoming,
    add: add,
    update: update,
    remove: remove,
    onChange: function (fn) { global.addEventListener('tcc-events:changed', fn); }
  };
})(window);
