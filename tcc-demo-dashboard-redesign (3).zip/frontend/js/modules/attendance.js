/* =========================================================================
   MODULE 6e — Attendance data layer (admin Attendance Management).
   Backend integration: talks to the real API (/backend, see
   src/routes/attendance.js). GET /api/attendance is already scoped
   server-side (admin=all, student=own), so forStudent() is a
   client-side re-filter of that same cache, kept for backward
   compatibility.

   Data model:
   {
     id, studentEmail, studentName, subject, date (YYYY-MM-DD),
     status: 'Present' | 'Late' | 'Absent',
     remarks, recordedAt
   }

   Used by:
   - admin/dashboard.html   (admin-schedule.js) → all() / add() / update() / remove() / generateForClass()
   - student-dashboard.html (dashboard-portal.js) → forStudent()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('attendance.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function normEmail(e) { return String(e || '').trim().toLowerCase(); }
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-attendance:changed')); } catch (e) { /* no-op */ } }

  function all() { return records.slice().sort(function (a, b) { return (b.date || '').localeCompare(a.date || ''); }); }
  function forStudent(email) {
    var target = normEmail(email);
    if (!target) return [];
    return all().filter(function (r) { return r.studentEmail === target; });
  }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/attendance')
      .then(function (data) { records = data.attendance || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/attendance', data)
      .then(function (res) { records.push(res.attendance); notify(); return { record: res.attendance }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function update(id, data) {
    return api.put('/attendance/' + id, data)
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.attendance : r; });
        notify();
        return { record: res.attendance };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function remove(id) {
    return api.del('/attendance/' + id)
      .then(function (res) {
        if (res.deleted) { records = records.filter(function (r) { return r.id !== id; }); notify(); }
        return res.deleted;
      })
      .catch(function () { return false; });
  }

  /* Bulk-creates one record per current student profile for a given
     subject/date (server skips students who already have one). */
  function generateForClass(subject, date, status, remarks) {
    return api.post('/attendance/generate', { subject: subject, date: date, status: status, remarks: remarks })
      .then(function (res) { return refresh().then(function () { return { created: res.created }; }); })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  var ready = refresh();

  global.TCCAttendance = {
    ready: ready,
    refresh: refresh,
    all: all, forStudent: forStudent, add: add, update: update, remove: remove, generateForClass: generateForClass,
    onChange: function (fn) { global.addEventListener('tcc-attendance:changed', fn); }
  };
})(window);
