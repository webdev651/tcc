/* =========================================================================
   MODULE 6c — Subject enrollment data layer (admin Subject Enrollment
   Management). Backend integration: talks to the real API (/backend, see
   src/routes/enrollments.js). GET /api/enrollments is already scoped
   server-side (admin=all, student=own), so forStudent() is a client-side
   re-filter of that same cache, kept for backward compatibility.

   Data model:
   {
     id, studentEmail, studentName, term,
     subjects: [{ code, name, units }],
     totalUnits,
     status: 'pending' | 'approved' | 'rejected',
     source: 'request' | 'assigned',
     submittedAt, decidedAt
   }

   Used by:
   - student-dashboard.html (dashboard-portal.js) → add(), forStudent()
   - admin/dashboard.html   (admin-enrollment-mgmt.js) → all(), assign(), approve(), reject(), pendingCount()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('enrollments.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var records = [];
  function normEmail(e) { return String(e || '').trim().toLowerCase(); }
  function notify() { try { global.dispatchEvent(new CustomEvent('tcc-enrollments:changed')); } catch (e) { /* no-op */ } }

  function all() { return records.slice().sort(function (a, b) { return (b.submittedAt || '').localeCompare(a.submittedAt || ''); }); }
  function forStudent(email) {
    var target = normEmail(email);
    if (!target) return [];
    return all().filter(function (r) { return r.studentEmail === target; });
  }
  function pendingCount() { return records.filter(function (r) { return r.status === 'pending'; }).length; }

  function refresh() {
    if (!api.getToken()) { records = []; notify(); return Promise.resolve(records); }
    return api.get('/enrollments')
      .then(function (data) { records = data.enrollments || []; notify(); return records; })
      .catch(function () { records = []; notify(); return records; });
  }

  function add(data) {
    return api.post('/enrollments', data)
      .then(function (res) { records.push(res.enrollment); notify(); return { record: res.enrollment }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  /* Admin assigning a subject directly — created already-approved, since
     there's nothing left to review. */
  function assign(data) {
    return api.post('/enrollments/assign', data)
      .then(function (res) { records.push(res.enrollment); notify(); return { record: res.enrollment }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function setStatus(id, action) {
    return api.post('/enrollments/' + id + '/' + action, {})
      .then(function (res) {
        records = records.map(function (r) { return r.id === id ? res.enrollment : r; });
        notify();
        return res.enrollment;
      })
      .catch(function () { return null; });
  }
  function approve(id) { return setStatus(id, 'approve'); }
  function reject(id) { return setStatus(id, 'reject'); }

  var ready = refresh();

  global.TCCEnrollments = {
    ready: ready,
    refresh: refresh,
    all: all, forStudent: forStudent, pendingCount: pendingCount,
    add: add, assign: assign, approve: approve, reject: reject,
    onChange: function (fn) { global.addEventListener('tcc-enrollments:changed', fn); }
  };
})(window);
