/* =========================================================================
   MODULE 5 — Teacher portal additions (teacher-dashboard.html only).
   Gradebook (enter/list/delete grades for your students), posting class
   announcements, and submitting feedback/suggestions to admin. Guarded by
   element presence, same convention as dashboard-portal.js's student block,
   so this file is a no-op if loaded anywhere else.
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }

  var session = null;
  try { session = JSON.parse(sessionStorage.getItem('tccSession') || 'null'); } catch (e) { session = null; }

  /* Falls back to whatever name is already showing in the sidebar (the
     built-in placeholder "Prof. Reyes" when no one's actually signed in),
     so posts/entries look consistent with "Signed in as" even in the
     zero-setup demo flow. */
  var teacherName = (session && session.name) || (function () {
    var el = document.getElementById('personName');
    return el ? el.textContent.trim() : 'Teacher';
  })();
  var teacherEmail = (session && session.email) || '';

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function timeAgo(iso) {
    if (!iso) return '—';
    var then = new Date(iso).getTime();
    if (isNaN(then)) return '—';
    var diff = Math.max(0, Date.now() - then);
    var mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + ' minute' + (mins === 1 ? '' : 's') + ' ago';
    var hours = Math.floor(mins / 60);
    if (hours < 24) return hours + ' hour' + (hours === 1 ? '' : 's') + ' ago';
    var days = Math.floor(hours / 24);
    if (days < 7) return days + ' day' + (days === 1 ? '' : 's') + ' ago';
    var weeks = Math.floor(days / 7);
    if (weeks < 5) return weeks + ' week' + (weeks === 1 ? '' : 's') + ' ago';
    return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  /* ---- Overview — real numbers, sourced from the same data layers the
     rest of the dashboard already uses (TCCTeacherSections, TCCSchedules,
     TCCAnnouncements). No separate "assignments/submissions" model exists
     in the backend yet, so there's no real stat for that — the old
     "Ungraded submissions" card is gone rather than faked. ---- */
  var ovStatSections = document.getElementById('ovStatSections');
  if (ovStatSections && window.TCCTeacherSections) {
    var ovStatStudents = document.getElementById('ovStatStudents');
    var ovStatToday = document.getElementById('ovStatToday');
    var ovStatAnnouncements = document.getElementById('ovStatAnnouncements');
    var ovStatSectionsDetail = document.getElementById('ovStatSectionsDetail');
    var ovStatStudentsDetail = document.getElementById('ovStatStudentsDetail');
    var ovStatTodayDetail = document.getElementById('ovStatTodayDetail');
    var ovStatAnnouncementsDetail = document.getElementById('ovStatAnnouncementsDetail');
    var ovTodayDay = document.getElementById('ovTodayDay');
    var overviewTodayList = document.getElementById('overviewTodayList');
    var overviewTodayEmpty = document.getElementById('overviewTodayEmpty');
    var overviewClassesList = document.getElementById('overviewClassesList');
    var overviewClassesEmpty = document.getElementById('overviewClassesEmpty');

    var WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var WEEKDAY_ABBR = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];

    /* schedules.day is free text an admin typed ("Wed", "MWF", "TTh"…),
       no fixed format — this is a best-effort match, not a guarantee.
       Thursday is checked as the 'th' pair before Tuesday's bare 't' so
       a "TTh" row correctly counts for both without a lone Thursday row
       ("Th") falsely also matching Tuesday. */
    function dayMatchesToday(dayStr) {
      var d = String(dayStr || '').trim();
      if (!d) return false;
      var lower = d.toLowerCase();
      var today = new Date().getDay();
      if (lower.indexOf(WEEKDAY_NAMES[today].toLowerCase()) !== -1 || lower.indexOf(WEEKDAY_ABBR[today]) !== -1) return true;
      switch (today) {
        case 0: return /su/i.test(d);
        case 1: return /m/i.test(d);
        case 2: return /t(?!h)/i.test(d);
        case 3: return /w/i.test(d);
        case 4: return /th/i.test(d);
        case 5: return /f/i.test(d);
        case 6: return /s(?!u)/i.test(d);
        default: return false;
      }
    }

    function renderOverviewToday() {
      if (!overviewTodayList || !window.TCCSchedules) return;
      if (ovTodayDay) ovTodayDay.textContent = WEEKDAY_NAMES[new Date().getDay()];
      var items = window.TCCSchedules.byTeacherName(teacherName).filter(function (s) { return dayMatchesToday(s.day); });
      if (ovStatToday) ovStatToday.textContent = String(items.length);
      if (ovStatTodayDetail) ovStatTodayDetail.textContent = items.length ? ('Next: ' + items[0].section + ' \u00b7 ' + items[0].time) : 'Nothing on today\u2019s timetable';
      if (!items.length) {
        overviewTodayList.innerHTML = '';
        if (overviewTodayEmpty) overviewTodayEmpty.hidden = false;
        return;
      }
      if (overviewTodayEmpty) overviewTodayEmpty.hidden = true;
      overviewTodayList.innerHTML = items.map(function (s) {
        return '<div class="portal-row">' +
          '<div class="portal-row-main"><b>' + escapeHtml(s.subject) + ' \u2014 ' + escapeHtml(s.section) + '</b><span>' + escapeHtml(s.room || '\u2014') + '</span></div>' +
          '<div class="portal-row-meta">' + escapeHtml(s.time) + '<span class="portal-daytag">' + escapeHtml(s.day) + '</span><br /><a href="#attendance">Take attendance</a></div>' +
          '</div>';
      }).join('');
    }

    function renderOverviewClasses() {
      if (!overviewClassesList) return;
      var sections = window.TCCTeacherSections.all();
      if (ovStatSections) ovStatSections.textContent = String(sections.length);
      if (ovStatSectionsDetail) ovStatSectionsDetail.textContent = sections.length === 1 ? '1 section' : sections.length + ' sections';

      var uniqueStudents = {};
      sections.forEach(function (s) { (s.students || []).forEach(function (st) { uniqueStudents[st.id] = true; }); });
      var studentCount = Object.keys(uniqueStudents).length;
      if (ovStatStudents) ovStatStudents.textContent = String(studentCount);
      if (ovStatStudentsDetail) ovStatStudentsDetail.textContent = sections.length === 1 ? 'In your section' : 'Across ' + sections.length + ' sections';

      if (!sections.length) {
        overviewClassesList.innerHTML = '';
        if (overviewClassesEmpty) overviewClassesEmpty.hidden = false;
        return;
      }
      if (overviewClassesEmpty) overviewClassesEmpty.hidden = true;
      overviewClassesList.innerHTML = sections.map(function (s) {
        var meta = [s.program, s.yearLevel, s.term].filter(Boolean).join(' \u2014 ');
        return '<div class="portal-row">' +
          '<div class="portal-row-main"><b>' + escapeHtml(s.sectionCode) + '</b><span>' + escapeHtml(meta) + ' \u00b7 ' + s.studentCount + ' student' + (s.studentCount === 1 ? '' : 's') + '</span></div>' +
          '<div class="portal-row-meta"><a href="#sections">Roster</a><br /><a href="#gradebook">Gradebook</a></div>' +
          '</div>';
      }).join('');
    }

    function renderOverviewAnnouncementCount() {
      if (!ovStatAnnouncements || !window.TCCAnnouncements) return;
      var count = window.TCCAnnouncements.byPoster(teacherName).length;
      ovStatAnnouncements.textContent = String(count);
      if (ovStatAnnouncementsDetail) ovStatAnnouncementsDetail.textContent = count ? 'Posted by you' : 'None posted yet';
    }

    renderOverviewClasses();
    renderOverviewToday();
    renderOverviewAnnouncementCount();
    window.TCCTeacherSections.onChange(renderOverviewClasses);
    window.TCCTeacherSections.ready.then(renderOverviewClasses);
    if (window.TCCSchedules) {
      window.TCCSchedules.onChange(renderOverviewToday);
      window.TCCSchedules.ready.then(renderOverviewToday);
    }
    if (window.TCCAnnouncements) {
      window.TCCAnnouncements.onChange(renderOverviewAnnouncementCount);
      window.TCCAnnouncements.ready.then(renderOverviewAnnouncementCount);
    }
  }

  /* ---- Gradebook ---- */
  var gradeForm = document.getElementById('gradeEntryForm');
  if (gradeForm && window.TCCGrades) {
    var gradebookBody = document.getElementById('gradebookBody');
    var gradebookEmpty = document.getElementById('gradebookEmpty');

    function badgeFor(status) {
      if (status === 'passing') return '<span class="badge badge--good">Passing</span>';
      if (status === 'failing') return '<span class="badge badge--bad">Failing</span>';
      return '<span class="badge badge--warn">Pending</span>';
    }

    function renderGradebook() {
      if (!gradebookBody) return;
      var rows = window.TCCGrades.byTeacher(teacherEmail);
      if (!rows.length) {
        gradebookBody.innerHTML = '';
        if (gradebookEmpty) gradebookEmpty.hidden = false;
        return;
      }
      if (gradebookEmpty) gradebookEmpty.hidden = true;
      gradebookBody.innerHTML = rows.map(function (r) {
        var status = window.TCCGrades.computeStatus(r.midterm, r.final);
        return '<tr>' +
          '<td>' + escapeHtml(r.studentName) + '</td>' +
          '<td class="portal-table-ellipsis portal-table-ellipsis--email" title="' + escapeHtml(r.studentEmail) + '">' + escapeHtml(r.studentEmail) + '</td>' +
          '<td>' + escapeHtml(r.subject) + '</td>' +
          '<td>' + escapeHtml(r.term) + '</td>' +
          '<td>' + (r.midterm == null ? '\u2014' : r.midterm) + '</td>' +
          '<td>' + (r.final == null ? '\u2014' : r.final) + '</td>' +
          '<td>' + badgeFor(status) + '</td>' +
          '<td class="portal-table-actions"><button type="button" class="btn-mini btn-mini--bad" data-remove-grade="' + r.id + '">Remove</button></td>' +
          '</tr>';
      }).join('');
    }
    renderGradebook();
    window.TCCGrades.onChange(renderGradebook);
    window.TCCGrades.ready.then(renderGradebook);

    gradeForm.addEventListener('submit', function (e) {
      e.preventDefault();
      window.TCCGrades.add({
        studentName: document.getElementById('gStudentName').value,
        studentEmail: document.getElementById('gStudentEmail').value,
        subject: document.getElementById('gSubject').value,
        term: document.getElementById('gTerm').value,
        midterm: document.getElementById('gMidterm').value,
        final: document.getElementById('gFinal').value,
        remarks: document.getElementById('gRemarks').value,
        teacherEmail: teacherEmail, teacherName: teacherName
      }).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast('Grade saved for ' + result.record.studentName, 'success');
        gradeForm.reset();
        renderGradebook();
      });
    });

    if (gradebookBody) {
      gradebookBody.addEventListener('click', function (e) {
        var id = e.target.getAttribute && e.target.getAttribute('data-remove-grade');
        if (!id) return;
        window.TCCGrades.remove(id).then(function (deleted) {
          if (!deleted) { toast('Could not remove that grade entry.', 'error'); return; }
          toast('Grade entry removed', 'success');
        });
      });
    }
  }

  /* ---- Students — your own roster, read from the real backend
     (js/modules/roster.js): anyone you've graded, or anyone enrolled in
     a subject on your Class Schedule. Never the whole student body. ---- */
  var studentsBody = document.getElementById('studentsBody');
  var taHint = document.getElementById('taHint');
  function defaultHint() { return 'Posted to your students\u2019 Announcements tab under your name.'; }

  function updateAnnouncementHint(n) {
    if (!taHint) return;
    if (n === null) { taHint.textContent = defaultHint(); return; }
    if (n === 0) {
      taHint.textContent = 'You have no linked students yet, so this won\u2019t reach anyone. Enter a grade or check your Class Schedule first \u2014 see the Students tab.';
      return;
    }
    taHint.textContent = 'Posted to your students\u2019 Announcements tab under your name \u2014 reaches ' + n + ' student' + (n === 1 ? '' : 's') + ' in your classes.';
  }

  if (studentsBody && window.TCCRoster) {
    var studentsEmpty = document.getElementById('studentsEmpty');
    function renderStudents() {
      var items = window.TCCRoster.all();
      updateAnnouncementHint(items.length);
      if (!items.length) {
        studentsBody.innerHTML = '';
        if (studentsEmpty) studentsEmpty.hidden = false;
        return;
      }
      if (studentsEmpty) studentsEmpty.hidden = true;
      studentsBody.innerHTML = items.map(function (s) {
        return '<tr>' +
          '<td>' + escapeHtml(s.name) + '</td>' +
          '<td class="portal-table-ellipsis portal-table-ellipsis--email" title="' + escapeHtml(s.email) + '">' + escapeHtml(s.email) + '</td>' +
          '<td>' + escapeHtml((s.subjects || []).join(', ') || '\u2014') + '</td>' +
          '</tr>';
      }).join('');
    }
    renderStudents();
    window.TCCRoster.onChange(renderStudents);
    window.TCCRoster.ready.then(renderStudents);

    var studentsExportColumns = [
      { label: 'Name', value: function (s) { return s.name; }, width: 26 },
      { label: 'Email', value: function (s) { return s.email; }, width: 32 },
      { label: 'Subjects with you', value: function (s) { return (s.subjects || []).join(', '); }, width: 28 }
    ];
    function safeFileSlug() { return String(teacherName || 'teacher').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'teacher'; }

    var exportExcelBtn = document.getElementById('studentsExportExcel');
    if (exportExcelBtn) {
      exportExcelBtn.addEventListener('click', function () {
        var items = window.TCCRoster.all();
        if (!items.length) { toast('No students to export yet.', 'error'); return; }
        var ok = window.TCCExport && window.TCCExport.toExcel('my-students-' + safeFileSlug() + '.xlsx', 'My Students', studentsExportColumns, items);
        if (ok === false) toast('Could not build the Excel file \u2014 check your connection and try again.', 'error');
      });
    }
    var exportPdfBtn = document.getElementById('studentsExportPdf');
    if (exportPdfBtn) {
      exportPdfBtn.addEventListener('click', function () {
        var items = window.TCCRoster.all();
        if (!items.length) { toast('No students to export yet.', 'error'); return; }
        var subtitle = 'Talisay City College \u00b7 ' + teacherName + ' \u00b7 ' + new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
        var ok = window.TCCExport && window.TCCExport.toPDF('my-students-' + safeFileSlug() + '.pdf', 'My Students', subtitle, studentsExportColumns, items);
        if (ok === false) toast('Could not build the PDF \u2014 check your connection and try again.', 'error');
      });
    }
  } else if (taHint) {
    updateAnnouncementHint(null);
  }

  /* ---- Attendance — your own students only. Backend also enforces
     this (403 if you try to touch a record for someone not on your
     roster), this is just the matching UI. ---- */
  var taAttBody = document.getElementById('taAttendanceBody');
  if (taAttBody && window.TCCAttendance) {
    var taAttEmpty = document.getElementById('taAttendanceEmpty');

    function taStatusBadge(status) {
      if (status === 'Present') return '<span class="badge badge--good">Present</span>';
      if (status === 'Late') return '<span class="badge badge--warn">Late</span>';
      return '<span class="badge badge--bad">Absent</span>';
    }
    function fmtDate(iso) {
      if (!iso) return '\u2014';
      var d = new Date(iso);
      if (isNaN(d)) return String(iso);
      return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
    }

    function renderTaAttendance() {
      var items = window.TCCAttendance.all();
      if (!items.length) {
        taAttBody.innerHTML = '';
        if (taAttEmpty) taAttEmpty.hidden = false;
        return;
      }
      if (taAttEmpty) taAttEmpty.hidden = true;
      taAttBody.innerHTML = items.map(function (a) {
        return '<tr data-attendance-row="' + a.id + '">' +
          '<td>' + escapeHtml(a.studentName) + '</td>' +
          '<td>' + escapeHtml(a.subject) + '</td>' +
          '<td>' + fmtDate(a.date) + '</td>' +
          '<td>' +
          '<select class="portal-table-select" data-attendance-status="' + a.id + '">' +
          ['Present', 'Late', 'Absent'].map(function (opt) { return '<option' + (a.status === opt ? ' selected' : '') + '>' + opt + '</option>'; }).join('') +
          '</select></td>' +
          '<td class="portal-table-ellipsis" title="' + escapeHtml(a.remarks || '') + '">' + escapeHtml(a.remarks || '\u2014') + '</td>' +
          '<td class="portal-table-actions"><button type="button" class="btn-mini btn-mini--bad" data-remove-attendance="' + a.id + '">Delete</button></td>' +
          '</tr>';
      }).join('');
    }
    renderTaAttendance();
    window.TCCAttendance.onChange(renderTaAttendance);
    window.TCCAttendance.ready.then(renderTaAttendance);

    taAttBody.addEventListener('change', function (e) {
      var id = e.target.getAttribute && e.target.getAttribute('data-attendance-status');
      if (!id) return;
      window.TCCAttendance.update(id, { status: e.target.value }).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast('Attendance status updated', 'success');
      });
    });
    taAttBody.addEventListener('click', function (e) {
      var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-attendance');
      if (removeId) {
        window.TCCAttendance.remove(removeId).then(function (deleted) {
          if (!deleted) { toast('Could not remove that attendance record.', 'error'); return; }
          toast('Attendance record removed', 'success');
        });
      }
    });
  }

  var taGenForm = document.getElementById('taGenerateForm');
  if (taGenForm && window.TCCAttendance) {
    taGenForm.addEventListener('submit', function (e) {
      e.preventDefault();
      window.TCCAttendance.generateForClass(
        document.getElementById('taGenSubject').value,
        document.getElementById('taGenDate').value,
        document.getElementById('taGenStatus').value,
        document.getElementById('taGenRemarks').value
      ).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast('Generated ' + result.created + ' attendance record' + (result.created === 1 ? '' : 's'), 'success');
        taGenForm.reset();
      });
    });
  }

  /* ---- Class schedule — your classes, read from the admin-managed
     schedules.js (falls back to everything if no name match, same
     graceful-fallback convention as byTeacher() elsewhere). ---- */
  var teacherScheduleBody = document.getElementById('teacherScheduleBody');
  if (teacherScheduleBody && window.TCCSchedules) {
    var teacherScheduleEmpty = document.getElementById('teacherScheduleEmpty');
    function renderTeacherSchedule() {
      var items = window.TCCSchedules.byTeacherName(teacherName);
      if (!items.length) {
        teacherScheduleBody.innerHTML = '';
        if (teacherScheduleEmpty) teacherScheduleEmpty.hidden = false;
        return;
      }
      if (teacherScheduleEmpty) teacherScheduleEmpty.hidden = true;
      teacherScheduleBody.innerHTML = items.map(function (s) {
        return '<tr>' +
          '<td>' + escapeHtml(s.subject) + '</td>' +
          '<td>' + escapeHtml(s.section) + '</td>' +
          '<td>' + escapeHtml(s.day) + '</td>' +
          '<td>' + escapeHtml(s.time) + '</td>' +
          '<td>' + escapeHtml(s.room || '\u2014') + '</td>' +
          '</tr>';
      }).join('');
    }
    renderTeacherSchedule();
    window.TCCSchedules.onChange(renderTeacherSchedule);
    window.TCCSchedules.ready.then(renderTeacherSchedule);
  }

  /* ---- Announcements — post to your students, then browse everything
     you can see (your own posts + the college-wide admin feed) through
     the shared Announcement Center: search, filter by category/priority/
     status, sort, read/unread state, and a detail view. ---- */
  var annForm = document.getElementById('teacherAnnouncementForm');
  if (annForm && window.TCCAnnouncements) {
    var overviewList = document.getElementById('overviewAnnouncementsList');
    var overviewEmpty = document.getElementById('overviewAnnouncementsEmpty');

    function renderOverview() {
      if (!overviewList) return;
      var items = window.TCCAnnouncements.byPoster(teacherName).slice(0, 3);
      if (!items.length) {
        overviewList.innerHTML = '';
        if (overviewEmpty) overviewEmpty.hidden = false;
        return;
      }
      if (overviewEmpty) overviewEmpty.hidden = true;
      overviewList.innerHTML = items.map(function (a) {
        return '<div class="portal-row">' +
          '<div class="portal-row-main"><b>' + escapeHtml(a.title) + '</b><span>' + escapeHtml(a.body) + '</span></div>' +
          '<div class="portal-row-meta">' + timeAgo(a.postedAt) + '</div>' +
          '</div>';
      }).join('');
    }
    renderOverview();
    window.TCCAnnouncements.onChange(renderOverview);
    window.TCCAnnouncements.ready.then(renderOverview);

    if (document.getElementById('teacherAnnouncementCenter') && window.TCCAnnouncementCenter) {
      window.TCCAnnouncementCenter.mount({
        containerId: 'teacherAnnouncementCenter',
        getItems: function () { return window.TCCAnnouncements.all(); },
        role: 'teacher',
        currentUserName: teacherName,
        canDeleteOwn: true,
        emptyMessage: 'No announcements yet.'
      });
    }

    annForm.addEventListener('submit', function (e) {
      e.preventDefault();
      window.TCCAnnouncements.add({
        title: document.getElementById('taTitle').value,
        body: document.getElementById('taBody').value,
        audience: 'student', postedByName: teacherName, postedByRole: 'teacher'
      }).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        var n = window.TCCRoster ? window.TCCRoster.count() : null;
        toast(n ? ('Announcement posted to ' + n + ' student' + (n === 1 ? '' : 's')) : 'Announcement posted to your students', 'success');
        annForm.reset();
      });
    });
  }

  /* ---- Feedback & suggestions — same shape as the student-side form in
     dashboard-portal.js, submitted with role 'teacher'. ---- */
  var fbForm = document.getElementById('teacherFeedbackForm');
  if (fbForm && window.TCCFeedback) {
    var fbNameInput = document.getElementById('tfbName');
    var fbEmailInput = document.getElementById('tfbEmail');
    var fbList = document.getElementById('teacherFeedbackList');
    var fbEmpty = document.getElementById('teacherFeedbackEmpty');

    if (session && session.name && fbNameInput) fbNameInput.value = session.name;
    if (session && session.email && fbEmailInput) fbEmailInput.value = session.email;

    function renderFeedback() {
      if (!fbList) return;
      var email = (fbEmailInput && fbEmailInput.value.trim()) || teacherEmail;
      var items = email ? window.TCCFeedback.forUser(email) : [];
      if (!items.length) {
        fbList.innerHTML = '';
        if (fbEmpty) fbEmpty.hidden = false;
        return;
      }
      if (fbEmpty) fbEmpty.hidden = true;
      fbList.innerHTML = items.map(function (f) {
        var statusBadge = f.status === 'resolved' ? '<span class="badge badge--good">Resolved</span>' : '<span class="badge badge--warn">New</span>';
        var responseHtml = f.response
          ? '<div class="portal-row-response portal-row-full"><b>Admin response:</b> ' + escapeHtml(f.response) + '</div>'
          : '';
        return '<div class="portal-row">' +
          '<div class="portal-row-main"><b>' + escapeHtml(f.subject || f.category) + '</b><span>' + escapeHtml(f.category) + '</span>' + responseHtml + '</div>' +
          '<div class="portal-row-meta">' + statusBadge + '<br />' + timeAgo(f.submittedAt) + '</div>' +
          '</div>';
      }).join('');
    }
    renderFeedback();
    window.TCCFeedback.onChange(renderFeedback);
    window.TCCFeedback.ready.then(renderFeedback);

    fbForm.addEventListener('submit', function (e) {
      e.preventDefault();
      window.TCCFeedback.add({
        name: fbNameInput.value, email: fbEmailInput.value, role: 'teacher',
        category: document.getElementById('tfbCategory').value,
        subject: document.getElementById('tfbSubject').value,
        message: document.getElementById('tfbMessage').value
      }).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        var keepName = fbNameInput.value, keepEmail = fbEmailInput.value;
        fbForm.reset();
        fbNameInput.value = keepName;
        fbEmailInput.value = keepEmail;
        toast('Feedback submitted \u2014 the admin office will review it', 'success');
        renderFeedback();
      });
    });
  }
})();
