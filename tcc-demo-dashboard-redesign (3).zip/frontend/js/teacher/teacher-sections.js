/* =========================================================================
   Teacher — My Sections (teacher-dashboard.html only). Renders the
   sections js/modules/teacher-sections.js loaded from GET
   /api/teacher/sections: section name, student count, and an expandable
   roster (name, email, student ID, program, year level) per section.
   Guarded by element presence, same convention as teacher-portal.js.
   ========================================================================= */
(function () {
  if (!window.TCCTeacherSections) return;

  var list = document.getElementById('teacherSectionsList');
  var empty = document.getElementById('teacherSectionsEmpty');
  if (!list) return;

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function renderRoster(section) {
    if (!section.students.length) {
      return '<p class="portal-note">No students assigned to this section yet.</p>';
    }
    return (
      '<div class="portal-table-wrap">' +
      '<table class="portal-table">' +
      '<thead><tr><th>Student ID</th><th>Name</th><th>Email</th><th>Program</th><th>Year level</th></tr></thead>' +
      '<tbody>' +
      section.students.map(function (s) {
        return '<tr>' +
          '<td>' + escapeHtml(s.studentId || '\u2014') + '</td>' +
          '<td>' + escapeHtml(s.name) + '</td>' +
          '<td class="portal-table-ellipsis portal-table-ellipsis--email" title="' + escapeHtml(s.email) + '">' + escapeHtml(s.email) + '</td>' +
          '<td>' + escapeHtml(s.program || '\u2014') + '</td>' +
          '<td>' + escapeHtml(s.yearLevel || '\u2014') + '</td>' +
          '</tr>';
      }).join('') +
      '</tbody></table></div>'
    );
  }

  function render() {
    var sections = window.TCCTeacherSections.all();
    if (!sections.length) {
      list.innerHTML = '';
      if (empty) empty.hidden = false;
      return;
    }
    if (empty) empty.hidden = true;
    list.innerHTML = sections.map(function (s, i) {
      var meta = [s.program, s.yearLevel].filter(Boolean).join(' \u2014 ');
      return (
        '<details class="portal-card" ' + (i === 0 ? 'open' : '') + '>' +
        '<summary style="cursor:pointer; display:flex; align-items:center; justify-content:space-between; gap:1rem;">' +
        '<span><b>' + escapeHtml(s.sectionCode) + '</b>' +
        (meta ? ' <span class="portal-row-meta">' + escapeHtml(meta) + '</span>' : '') +
        (s.term ? ' <span class="portal-row-meta">' + escapeHtml(s.term) + '</span>' : '') +
        '</span>' +
        '<span class="badge badge--good">' + s.studentCount + ' student' + (s.studentCount === 1 ? '' : 's') + '</span>' +
        '</summary>' +
        '<div style="margin-top:1rem;">' + renderRoster(s) + '</div>' +
        '</details>'
      );
    }).join('');
  }

  render();
  window.TCCTeacherSections.onChange(render);
  window.TCCTeacherSections.ready.then(render);
})();
