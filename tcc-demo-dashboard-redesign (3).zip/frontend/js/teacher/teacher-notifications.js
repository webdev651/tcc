/* =========================================================================
   Teacher — Notifications (teacher-dashboard.html only).
   GET /api/teacher/notifications for this signed-in teacher's own feed
   (admin broadcasts + "master list shared with you" alerts). Clicking a
   master-list notification loads it via GET /api/teacher/master-list/:id
   — the backend only ever returns a share addressed to this teacher's own
   email, so this can't be used to peek at another teacher's list — and
   previews it here with Excel/PDF download (Student ID, Name, Section).
   ========================================================================= */
(function () {
  if (!window.TCCApi) return;
  var api = window.TCCApi;

  var listEl = document.getElementById('teacherNotificationsList');
  var emptyEl = document.getElementById('teacherNotificationsEmpty');
  var navBadge = document.getElementById('ntfBadge');
  var navBadgeCount = document.getElementById('ntfBadgeCount');
  var mlCard = document.getElementById('ntfMasterListCard');
  var mlSectionEl = document.getElementById('ntfMasterListSection');
  var mlMetaEl = document.getElementById('ntfMasterListMeta');
  var mlBody = document.getElementById('ntfMasterListBody');
  var mlExportExcelBtn = document.getElementById('ntfMasterListExportExcel');
  var mlExportPdfBtn = document.getElementById('ntfMasterListExportPdf');

  if (!listEl) return; // not this page

  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDateTime(iso) {
    if (!iso) return '\u2014';
    var d = new Date(iso);
    if (isNaN(d)) return '\u2014';
    return d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  }

  var exportColumns = [
    { label: 'Student ID', value: function (s) { return s.studentId; }, width: 16 },
    { label: 'Name', value: function (s) { return s.name; }, width: 26 },
    { label: 'Section', value: function (s) { return s.section; }, width: 16 }
  ];

  var items = [];
  var currentMasterList = null; // { section, sentByName, sentAt, students }

  function refresh() {
    return api.get('/teacher/notifications')
      .then(function (data) { items = data.notifications || []; render(); return items; })
      .catch(function () { items = []; render(); return items; });
  }

  function render() {
    var unread = items.filter(function (n) { return n.relatedMasterlistId && !n.masterlistViewed; }).length;
    if (navBadgeCount) navBadgeCount.textContent = String(unread);
    if (navBadge) navBadge.hidden = unread === 0;

    if (!items.length) {
      listEl.innerHTML = '';
      if (emptyEl) emptyEl.hidden = false;
      return;
    }
    if (emptyEl) emptyEl.hidden = true;
    listEl.innerHTML = items.map(function (n) {
      var action = n.relatedMasterlistId
        ? '<a href="#notifications" data-view-masterlist="' + n.relatedMasterlistId + '">' +
          (n.masterlistViewed ? 'View master list' : 'View master list <span class="badge badge--warn">New</span>') + '</a>'
        : '';
      return '<div class="portal-row">' +
        '<div class="portal-row-main"><b>' + escapeHtml(n.title) + '</b><span>' + escapeHtml(n.message) + '</span></div>' +
        '<span class="portal-row-meta">' + fmtDateTime(n.sentAt || n.createdAt) + (action ? '<br />' + action : '') + '</span>' +
        '</div>';
    }).join('');
  }

  function loadMasterList(shareId) {
    api.get('/teacher/master-list/' + encodeURIComponent(shareId))
      .then(function (data) {
        currentMasterList = data;
        renderMasterList();
        refresh(); // picks up the now-viewed state, clears its "New" badge
      })
      .catch(function (err) { toast(api.errorMessage(err), 'error'); });
  }

  function renderMasterList() {
    if (!currentMasterList || !mlCard) return;
    mlCard.hidden = false;
    if (mlSectionEl) mlSectionEl.textContent = '\u2014 ' + (currentMasterList.section || 'All sections');
    if (mlMetaEl) {
      mlMetaEl.textContent = 'Sent by ' + currentMasterList.sentByName + ' on ' + fmtDateTime(currentMasterList.sentAt) +
        ' \u00b7 ' + currentMasterList.students.length + (currentMasterList.students.length === 1 ? ' student' : ' students');
    }
    mlBody.innerHTML = currentMasterList.students.map(function (s) {
      return '<tr><td>' + escapeHtml(s.studentId || '\u2014') + '</td><td>' + escapeHtml(s.name) + '</td><td>' + escapeHtml(s.section || '\u2014') + '</td></tr>';
    }).join('');
    mlCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  listEl.addEventListener('click', function (e) {
    var link = e.target.closest ? e.target.closest('[data-view-masterlist]') : null;
    if (!link) return;
    e.preventDefault();
    loadMasterList(link.getAttribute('data-view-masterlist'));
  });

  function fileSlug() {
    var section = (currentMasterList && currentMasterList.section) || 'all-sections';
    return String(section).trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'section';
  }

  if (mlExportExcelBtn) {
    mlExportExcelBtn.addEventListener('click', function () {
      if (!currentMasterList || !currentMasterList.students.length) return;
      var ok = window.TCCExport && window.TCCExport.toExcel('master-list-' + fileSlug() + '.xlsx', 'Master List', exportColumns, currentMasterList.students);
      if (ok === false) toast('Could not build the Excel file \u2014 check your connection and try again.', 'error');
    });
  }
  if (mlExportPdfBtn) {
    mlExportPdfBtn.addEventListener('click', function () {
      if (!currentMasterList || !currentMasterList.students.length) return;
      var subtitle = 'Talisay City College \u00b7 ' + (currentMasterList.section || 'All sections') + ' \u00b7 ' + new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
      var ok = window.TCCExport && window.TCCExport.toPDF('master-list-' + fileSlug() + '.pdf', 'Master List', subtitle, exportColumns, currentMasterList.students);
      if (ok === false) toast('Could not build the PDF \u2014 check your connection and try again.', 'error');
    });
  }

  refresh();
  setInterval(refresh, 30000);
})();
