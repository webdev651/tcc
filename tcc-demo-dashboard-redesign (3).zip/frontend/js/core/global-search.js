/* =========================================================================
   Global search (admin/dashboard.html only) — search across Students,
   Teachers, Subjects, Sections, Announcements and Pages (the sidebar nav
   itself), grouped results, and jump straight to the matching record.

   No new backend calls: reads whatever js/modules/*.js (profiles.js,
   staff.js, sections.js, announcements.js, schedules.js) already has
   loaded, the same "database" every admin-*.js screen renders from.
   "Subjects" isn't its own table — it's derived from the distinct subject
   names in the Class Schedule records.

   Navigating to a result reuses that page's own [data-filter] table
   search (same live-filter wiring as js/core/dashboard-portal.js) where
   one exists; Announcements instead drives the Announcement Center's own
   search box (js/core/announcement-center.js) and then scrolls to and
   briefly highlights the matching card.

   Guarded by element presence, same convention as the other admin-*.js
   files — a no-op on any page that doesn't have the search markup.
   ========================================================================= */
(function () {
  'use strict';

  var topbarBtn = document.getElementById('gsearchTopbarBtn');
  var sidebarBtn = document.getElementById('gsearchSidebarBtn');
  var overlay = document.getElementById('gsearchOverlay');
  var scrim = document.getElementById('gsearchScrim');
  var closeBtn = document.getElementById('gsearchClose');
  var input = document.getElementById('gsearchInput');
  var clearBtn = document.getElementById('gsearchClear');
  var resultsBox = document.getElementById('gsearchResults');
  var hintEl = document.getElementById('gsearchHint');
  var emptyEl = document.getElementById('gsearchEmpty');
  var kbdHint = document.getElementById('gsearchKbdHint');

  if (!overlay || !input || !resultsBox) return;

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---- Open / close ---- */
  var lastFocused = null;
  function openSearch() {
    lastFocused = document.activeElement;
    overlay.hidden = false;
    input.focus();
    input.select();
  }
  function closeSearch() {
    overlay.hidden = true;
    if (lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus();
  }

  [topbarBtn, sidebarBtn].forEach(function (btn) {
    if (btn) btn.addEventListener('click', openSearch);
  });
  if (scrim) scrim.addEventListener('click', closeSearch);
  if (closeBtn) closeBtn.addEventListener('click', closeSearch);

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !overlay.hidden) { closeSearch(); return; }
    var meta = e.metaKey || e.ctrlKey;
    if (meta && (e.key === 'k' || e.key === 'K')) {
      e.preventDefault();
      if (overlay.hidden) openSearch(); else closeSearch();
    }
  });

  /* Show the right modifier key hint (⌘K on Mac, Ctrl K elsewhere) on the
     sidebar entry button. */
  if (kbdHint) {
    var isMac = /Mac|iPhone|iPad|iPod/.test(navigator.platform || navigator.userAgent || '');
    kbdHint.textContent = isMac ? '\u2318K' : 'Ctrl K';
  }

  /* ---- Pages: derived from the sidebar nav itself, so a nav item added
     later shows up here automatically. Strips the icon glyph and any
     pending-count badge, keeping just the label text. ---- */
  function getPages() {
    return Array.prototype.slice.call(document.querySelectorAll('.portal-nav a[href^="#"]')).map(function (a) {
      var clone = a.cloneNode(true);
      var badge = clone.querySelector('.portal-nav-badge');
      if (badge && badge.parentNode) badge.parentNode.removeChild(badge);
      var ico = clone.querySelector('.ico');
      if (ico && ico.parentNode) ico.parentNode.removeChild(ico);
      return { id: (a.getAttribute('href') || '').replace('#', ''), label: clone.textContent.trim() };
    }).filter(function (p) { return p.id && p.label; });
  }

  function matches(fields, q) {
    return fields.some(function (f) { return String(f == null ? '' : f).toLowerCase().indexOf(q) > -1; });
  }

  var MAX_PER_GROUP = 6;

  /* ---- Navigation helpers ---- */
  function goToView(id) {
    window.location.hash = id;
  }

  function runFilter(tableSelector, query) {
    var box = document.querySelector('input[data-filter="' + tableSelector + '"]');
    if (!box) return;
    box.value = query;
    box.dispatchEvent(new Event('input', { bubbles: true }));
    setTimeout(function () { box.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 60);
  }

  function highlightAnnouncement(title) {
    setTimeout(function () {
      var list = document.getElementById('adminAnnouncementCenter');
      if (!list) return;
      var searchBox = list.querySelector('.ann-search');
      if (searchBox) {
        searchBox.value = title;
        searchBox.dispatchEvent(new Event('input', { bubbles: true }));
      }
      var cards = Array.prototype.slice.call(list.querySelectorAll('.ann-card'));
      var target = cards.filter(function (card) {
        var t = card.querySelector('.ann-card-title');
        return t && t.textContent.trim() === title;
      })[0];
      if (!target) return;
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      target.classList.remove('gsearch-highlight');
      void target.offsetWidth; /* restart the flash animation if the same result is clicked twice */
      target.classList.add('gsearch-highlight');
      setTimeout(function () { target.classList.remove('gsearch-highlight'); }, 1700);
    }, 80);
  }

  function activate(result) {
    closeSearch();
    goToView(result.pageId);
    if (result.filterTable) runFilter(result.filterTable, result.filterQuery);
    else if (result.highlightTitle) highlightAnnouncement(result.highlightTitle);
  }

  /* ---- Build grouped results for a (lowercased) query ---- */
  function buildGroups(q) {
    var groups = [];

    if (window.TCCProfiles) {
      var students = window.TCCProfiles.all().filter(function (s) {
        return matches([s.name, s.email, s.studentId, s.program, s.section, s.yearLevel], q);
      }).slice(0, MAX_PER_GROUP).map(function (s) {
        return {
          title: s.name,
          sub: [s.studentId, s.program, s.section].filter(Boolean).join(' \u00b7 ') || s.email || 'Student',
          pageId: 'students', filterTable: '#studentsTable', filterQuery: s.name
        };
      });
      if (students.length) groups.push({ label: 'Students', items: students });
    }

    if (window.TCCStaff) {
      var teachers = window.TCCStaff.all().filter(function (t) {
        return matches([t.name, t.email, t.department, t.subjects], q);
      }).slice(0, MAX_PER_GROUP).map(function (t) {
        return {
          title: t.name,
          sub: [t.department, t.subjects].filter(Boolean).join(' \u00b7 ') || t.email || 'Teacher',
          pageId: 'staff', filterTable: '#staffTable', filterQuery: t.name
        };
      });
      if (teachers.length) groups.push({ label: 'Teachers', items: teachers });
    }

    if (window.TCCSchedules) {
      var seen = {};
      window.TCCSchedules.all().forEach(function (entry) {
        var name = String(entry.subject || '').trim();
        if (!name) return;
        var key = name.toLowerCase();
        if (!seen[key]) seen[key] = { name: name, teachers: {}, count: 0 };
        seen[key].count += 1;
        if (entry.teacherName) seen[key].teachers[entry.teacherName] = true;
      });
      var subjects = Object.keys(seen).map(function (key) { return seen[key]; })
        .filter(function (s) { return matches([s.name].concat(Object.keys(s.teachers)), q); })
        .slice(0, MAX_PER_GROUP)
        .map(function (s) {
          var teacherNames = Object.keys(s.teachers);
          return {
            title: s.name,
            sub: (teacherNames.length ? teacherNames.join(', ') + ' \u00b7 ' : '') + s.count + (s.count === 1 ? ' class' : ' classes'),
            pageId: 'schedule', filterTable: '#scheduleMgmtTable', filterQuery: s.name
          };
        });
      if (subjects.length) groups.push({ label: 'Subjects', items: subjects });
    }

    if (window.TCCSections) {
      var sections = window.TCCSections.all().filter(function (s) {
        return matches([s.sectionCode, s.program, s.yearLevel, s.term, s.teacherName], q);
      }).slice(0, MAX_PER_GROUP).map(function (s) {
        return {
          title: s.sectionCode,
          sub: [s.program, s.yearLevel, s.teacherName].filter(Boolean).join(' \u00b7 ') || 'No teacher assigned',
          pageId: 'sections', filterTable: '#sectionsTable', filterQuery: s.sectionCode
        };
      });
      if (sections.length) groups.push({ label: 'Sections', items: sections });
    }

    if (window.TCCAnnouncements) {
      var announcements = window.TCCAnnouncements.all().filter(function (a) {
        return matches([a.title, a.body, a.postedByName], q);
      }).slice(0, MAX_PER_GROUP).map(function (a) {
        var audienceLabel = a.audience === 'all' ? 'Everyone' : a.audience === 'student' ? 'Students only' : 'Staff only';
        return {
          title: a.title,
          sub: (a.postedByName ? a.postedByName + ' \u00b7 ' : '') + audienceLabel,
          pageId: 'announcements', highlightTitle: a.title
        };
      });
      if (announcements.length) groups.push({ label: 'Announcements', items: announcements });
    }

    var pages = getPages().filter(function (p) { return matches([p.label], q); })
      .map(function (p) { return { title: p.label, sub: 'Jump to this section', pageId: p.id }; });
    if (pages.length) groups.push({ label: 'Pages', items: pages });

    return groups;
  }

  /* ---- Render ---- */
  var resultIndex = [];
  function render(q) {
    if (!q) {
      resultsBox.innerHTML = '';
      resultsBox.hidden = true;
      if (emptyEl) emptyEl.hidden = true;
      if (hintEl) hintEl.hidden = false;
      return;
    }

    var groups = buildGroups(q);
    if (hintEl) hintEl.hidden = true;

    if (!groups.length) {
      resultsBox.innerHTML = '';
      resultsBox.hidden = true;
      if (emptyEl) emptyEl.hidden = false;
      return;
    }

    if (emptyEl) emptyEl.hidden = true;
    resultsBox.hidden = false;
    resultIndex = [];
    resultsBox.innerHTML = groups.map(function (group) {
      return '<div class="gsearch-group">' +
        '<p class="gsearch-group-label">' + escapeHtml(group.label) + '</p>' +
        group.items.map(function (item) {
          var idx = resultIndex.length;
          resultIndex.push(item);
          return '<button type="button" class="gsearch-result" data-gsearch-idx="' + idx + '">' +
            '<span class="gsearch-result-main">' +
              '<span class="gsearch-result-title">' + escapeHtml(item.title) + '</span>' +
              (item.sub ? '<span class="gsearch-result-sub">' + escapeHtml(item.sub) + '</span>' : '') +
            '</span>' +
            '<span class="gsearch-result-arrow" aria-hidden="true">\u2192</span>' +
            '</button>';
        }).join('') +
        '</div>';
    }).join('');
  }

  resultsBox.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('[data-gsearch-idx]') : null;
    if (!btn) return;
    var item = resultIndex[Number(btn.getAttribute('data-gsearch-idx'))];
    if (item) activate(item);
  });

  input.addEventListener('input', function () {
    var raw = input.value;
    var q = raw.trim().toLowerCase();
    if (clearBtn) clearBtn.hidden = !raw;
    render(q);
  });

  if (clearBtn) {
    clearBtn.addEventListener('click', function () {
      input.value = '';
      clearBtn.hidden = true;
      render('');
      input.focus();
    });
  }

  /* Keep results fresh if the underlying data changes while the panel is
     open (e.g. an announcement gets posted in another tab). */
  ['TCCProfiles', 'TCCStaff', 'TCCSections', 'TCCAnnouncements', 'TCCSchedules'].forEach(function (name) {
    var mod = window[name];
    if (mod && typeof mod.onChange === 'function') {
      mod.onChange(function () {
        if (!overlay.hidden && input.value.trim()) render(input.value.trim().toLowerCase());
      });
    }
  });
})();
