/* =========================================================================
   Overview tab — "Academic Performance" chart + "Academic Overview" panel
   (student-dashboard.html, teacher-dashboard.html, admin/dashboard.html).

   SalesOps-reference visual (see css/14-dashboard-performance.css), backed
   by the SAME data layers the rest of each dashboard already loads —
   window.TCCGrades and window.TCCAttendance (js/modules/grades.js,
   js/modules/attendance.js) — no new API calls, no invented numbers:

   - Chart: one point per grade "term" value on file, averaging whatever
     midterm/final scores exist for that term (grades.js already computes
     per-record status the same way — see computeStatus's 75% cutoff,
     reused below as the constant "passing target" line so it isn't a
     fabricated number). Terms are ordered by the earliest entry recorded
     for that term, so the x-axis reads chronologically without needing a
     real date field on grades (there isn't one — see grades.js's data
     model comment).
   - Right panel: a handful of rate bars (attendance / pass rate / grade-
     verification, scoped per role below) plus a derived "Overall status"
     pill — a plain threshold read of the same numbers, not a new metric.
   - Every row/bar is hidden (not zero-filled) when its underlying record
     count is 0, per the "don't fabricate, show an empty state" rule.

   Guarded by element presence (#perfChart / #opsRows) — no-op on any page
   without this section, so one file covers all three dashboards.
   ========================================================================= */
(function () {
  'use strict';

  var chartEl = document.getElementById('perfChart');
  var opsRowsEl = document.getElementById('opsRows');
  if (!chartEl && !opsRowsEl) return; // not on this page

  var PASS_TARGET = 75; // same cutoff js/modules/grades.js's computeStatus() already uses

  var siteEl = document.querySelector('.site[data-role]');
  var role = siteEl ? siteEl.getAttribute('data-role') : '';

  var session = null;
  try { session = JSON.parse(sessionStorage.getItem('tccSession') || 'null'); } catch (e) { session = null; }
  var myEmail = (session && session.email) || '';

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---- pull the grade records relevant to this role ---- */
  function myGrades() {
    if (!window.TCCGrades) return [];
    if (role === 'teacher') return window.TCCGrades.byTeacher(myEmail);
    if (role === 'student') return window.TCCGrades.forStudent(myEmail);
    return window.TCCGrades.all(); // admin: college-wide
  }
  function myAttendance() {
    if (!window.TCCAttendance) return [];
    var all = window.TCCAttendance.all();
    if (role === 'student') return window.TCCAttendance.forStudent(myEmail);
    return all; // admin/teacher: attendance has no teacher scoping field on file
  }

  /* ---- chart: average score per term, chronological by first entry ---- */
  function termSeries(grades) {
    var byTerm = {}; // term -> { total, count, firstAt }
    grades.forEach(function (g) {
      var vals = [g.midterm, g.final].filter(function (v) { return v !== null && v !== undefined; });
      if (!vals.length) return;
      var term = String(g.term || 'Untitled term').trim() || 'Untitled term';
      var avg = vals.reduce(function (a, b) { return a + b; }, 0) / vals.length;
      if (!byTerm[term]) byTerm[term] = { total: 0, count: 0, firstAt: g.enteredAt || g.updatedAt || '' };
      byTerm[term].total += avg;
      byTerm[term].count += 1;
      var at = g.enteredAt || g.updatedAt || '';
      if (at && (!byTerm[term].firstAt || at < byTerm[term].firstAt)) byTerm[term].firstAt = at;
    });
    return Object.keys(byTerm)
      .map(function (term) { return { term: term, value: byTerm[term].total / byTerm[term].count, firstAt: byTerm[term].firstAt }; })
      .sort(function (a, b) { return (a.firstAt || '').localeCompare(b.firstAt || '') || a.term.localeCompare(b.term); });
  }

  function svgChart(points) {
    var W = 640, H = 240, padL = 34, padR = 12, padT = 14, padB = 26;
    var plotW = W - padL - padR, plotH = H - padT - padB;
    function mapY(v) { return padT + plotH * (1 - Math.max(0, Math.min(100, v)) / 100); }
    function mapX(i) { return points.length <= 1 ? padL + plotW / 2 : padL + (plotW * i) / (points.length - 1); }

    var gridLines = [0, 25, 50, 75, 100].map(function (v) {
      var y = mapY(v);
      return '<line class="perf-chart-grid" x1="' + padL + '" y1="' + y + '" x2="' + (W - padR) + '" y2="' + y + '"></line>' +
        '<text class="perf-chart-axis" x="' + (padL - 8) + '" y="' + (y + 3) + '" text-anchor="end">' + v + '</text>';
    }).join('');

    var targetY = mapY(PASS_TARGET);
    var targetLine = '<line class="perf-chart-line--target" x1="' + padL + '" y1="' + targetY + '" x2="' + (W - padR) + '" y2="' + targetY + '"></line>';

    var coords = points.map(function (p, i) { return mapX(i) + ',' + mapY(p.value); });
    var areaEl = '', lineEl = '';
    if (points.length > 1) {
      lineEl = '<polyline class="perf-chart-line--actual" points="' + coords.join(' ') + '"></polyline>';
      var areaPath = 'M ' + mapX(0) + ',' + mapY(0) + ' L ' + coords.join(' L ') + ' L ' + mapX(points.length - 1) + ',' + mapY(0) + ' Z';
      areaEl = '<path class="perf-chart-area" d="' + areaPath + '"></path>';
    }

    var dots = points.map(function (p, i) {
      return '<circle class="perf-chart-dot" cx="' + mapX(i) + '" cy="' + mapY(p.value) + '" r="3.5"><title>' + escapeHtml(p.term) + ': ' + p.value.toFixed(1) + '%</title></circle>';
    }).join('');

    var labels = points.map(function (p, i) {
      var lbl = p.term.length > 12 ? p.term.slice(0, 11) + '\u2026' : p.term;
      return '<text class="perf-chart-label" x="' + mapX(i) + '" y="' + (H - 6) + '">' + escapeHtml(lbl) + '</text>';
    }).join('');

    return '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Academic performance by term">' +
      '<defs><linearGradient id="perfAreaFill" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0%" stop-color="var(--perf-actual)" stop-opacity="0.28"></stop>' +
      '<stop offset="100%" stop-color="var(--perf-actual)" stop-opacity="0"></stop>' +
      '</linearGradient></defs>' +
      gridLines + targetLine + areaEl + lineEl + dots + labels +
      '</svg>';
  }

  function renderChart() {
    if (!chartEl) return;
    var emptyEl = document.getElementById('perfChartEmpty');
    var points = termSeries(myGrades());
    if (!points.length) {
      chartEl.innerHTML = '';
      if (emptyEl) emptyEl.hidden = false;
      return;
    }
    if (emptyEl) emptyEl.hidden = true;
    chartEl.innerHTML = svgChart(points);
  }

  /* ---- ops panel: a few rate bars + a derived status pill ---- */
  function attendanceRate(records) {
    // Same "Late counts as half" weighting as js/core/student-overview.js's
    // own Attendance rate stat card, so this panel never disagrees with it.
    if (!records.length) return null;
    var score = records.reduce(function (sum, r) {
      return sum + (r.status === 'Present' ? 1 : r.status === 'Late' ? 0.5 : 0);
    }, 0);
    return (score / records.length) * 100;
  }
  function passRate(grades) {
    var scored = grades.filter(function (g) { return (g.midterm !== null && g.midterm !== undefined) || (g.final !== null && g.final !== undefined); });
    if (!scored.length) return null;
    var passing = scored.filter(function (g) { return window.TCCGrades.computeStatus(g.midterm, g.final) === 'passing'; }).length;
    return (passing / scored.length) * 100;
  }
  function verifiedRate(grades) {
    if (!grades.length) return null;
    var verified = grades.filter(function (g) { return g.adminStatus === 'verified'; }).length;
    return (verified / grades.length) * 100;
  }
  function averageScore(grades) {
    var vals = [];
    grades.forEach(function (g) {
      [g.midterm, g.final].forEach(function (v) { if (v !== null && v !== undefined) vals.push(v); });
    });
    if (!vals.length) return null;
    return vals.reduce(function (a, b) { return a + b; }, 0) / vals.length;
  }

  function barRow(label, value, colorClass) {
    if (value === null) {
      return '<div class="ops-empty-row">' + escapeHtml(label) + ' — no data on file yet</div>';
    }
    var pct = Math.max(0, Math.min(100, value));
    return '<div class="ops-row">' +
      '<div class="ops-row-top"><span class="ops-row-label">' + escapeHtml(label) + '</span>' +
      '<span class="ops-row-value"><b>' + pct.toFixed(1) + '%</b></span></div>' +
      '<div class="ops-track"><div class="ops-fill ' + colorClass + '" style="width:' + pct + '%;"></div></div>' +
      '</div>';
  }

  function renderOpsPanel() {
    if (!opsRowsEl) return;
    var grades = myGrades();
    var attendance = myAttendance();
    var rows = [];
    var attRate = attendanceRate(attendance);
    var pRate = passRate(grades);
    var vRate = verifiedRate(grades);
    var checks; // whichever rates are actually shown for this role — status must match what's on screen

    if (role === 'student') {
      rows.push(barRow('Attendance rate', attRate, 'ops-fill--cyan'));
      rows.push(barRow('Average grade', averageScore(grades), 'ops-fill--blue'));
      rows.push(barRow('Passing subjects', pRate, 'ops-fill--orange'));
      checks = [attRate, pRate];
    } else if (role === 'teacher') {
      rows.push(barRow('Average score (my sections)', averageScore(grades), 'ops-fill--cyan'));
      rows.push(barRow('Pass rate', pRate, 'ops-fill--blue'));
      rows.push(barRow('Grades verified', vRate, 'ops-fill--orange'));
      checks = [pRate, vRate];
    } else {
      rows.push(barRow('Attendance rate', attRate, 'ops-fill--cyan'));
      rows.push(barRow('Pass rate', pRate, 'ops-fill--blue'));
      rows.push(barRow('Grades verified', vRate, 'ops-fill--orange'));
      checks = [attRate, pRate];
    }
    opsRowsEl.innerHTML = rows.join('');

    var statusBadge = document.getElementById('opsStatusBadge');
    if (statusBadge) {
      checks = checks.filter(function (v) { return v !== null; });
      if (!checks.length) {
        statusBadge.textContent = 'No data yet';
        statusBadge.className = 'badge badge--muted';
      } else {
        var worst = Math.min.apply(null, checks);
        if (worst >= 90) { statusBadge.textContent = 'Good standing'; statusBadge.className = 'badge badge--good'; }
        else if (worst >= 75) { statusBadge.textContent = 'Fair standing'; statusBadge.className = 'badge badge--warn'; }
        else { statusBadge.textContent = 'Needs attention'; statusBadge.className = 'badge badge--bad'; }
      }
    }
  }

  function renderAll() { renderChart(); renderOpsPanel(); }

  var readyPromises = [];
  if (window.TCCGrades) readyPromises.push(window.TCCGrades.ready);
  if (window.TCCAttendance) readyPromises.push(window.TCCAttendance.ready);
  Promise.all(readyPromises).then(renderAll).catch(renderAll);

  if (window.TCCGrades) window.TCCGrades.onChange(renderAll);
  if (window.TCCAttendance) window.TCCAttendance.onChange(renderAll);
})();
