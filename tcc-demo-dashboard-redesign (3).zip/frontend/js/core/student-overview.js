/* =========================================================================
   Student — Overview (student-dashboard.html only). Replaces the
   hardcoded demo numbers/rows (6 subjects, 96%, 3 pending assignments,
   Wed 8:00 General Chemistry…) with the signed-in student's real records,
   the same way js/core/dashboard-portal.js already does for the
   Grades/Attendance/Announcements tabs below — this file just does the
   same for the Overview cards at the top of the page.

   "Pending assignments" is gone rather than faked: there's no
   assignments/submissions table anywhere in the schema (grades.js only
   stores midterm/final entries a teacher typed in). Replaced with
   "Grades recorded", which is real. Likewise "Unread announcements" —
   nothing tracks read/unread — becomes plain "Announcements".

   Guarded by element presence; no-op on any page without these ids.
   ========================================================================= */
(function () {
  if (!window.TCCApi) return;
  var api = window.TCCApi;

  var subjectsValue = document.getElementById('ovSubjectsValue');
  if (!subjectsValue) return; // not on this page

  var subjectsDetail = document.getElementById('ovSubjectsDetail');
  var attendanceValue = document.getElementById('ovAttendanceValue');
  var attendanceDetail = document.getElementById('ovAttendanceDetail');
  var gradesValue = document.getElementById('ovGradesValue');
  var gradesDetail = document.getElementById('ovGradesDetail');
  var annCountValue = document.getElementById('ovAnnCountValue');
  var annCountDetail = document.getElementById('ovAnnCountDetail');

  var scheduleDay = document.getElementById('ovScheduleDay');
  var scheduleList = document.getElementById('overviewScheduleList');
  var scheduleEmpty = document.getElementById('overviewScheduleEmpty');
  var gradesList = document.getElementById('overviewGradesList');
  var gradesListEmpty = document.getElementById('overviewGradesEmpty');
  var annList = document.getElementById('overviewAnnList');
  var annListEmpty = document.getElementById('overviewAnnEmpty');

  var session = null;
  try { session = JSON.parse(sessionStorage.getItem('tccSession') || 'null'); } catch (e) { session = null; }
  var studentEmail = (session && session.email) || '';
  var mySection = null; // filled in from /profiles/me below, used to match schedules.section

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function timeAgo(iso) {
    if (!iso) return '\u2014';
    var then = new Date(iso).getTime();
    if (isNaN(then)) return '\u2014';
    var diff = Math.max(0, Date.now() - then);
    var mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + ' minute' + (mins === 1 ? '' : 's') + ' ago';
    var hours = Math.floor(mins / 60);
    if (hours < 24) return hours + ' hour' + (hours === 1 ? '' : 's') + ' ago';
    var days = Math.floor(hours / 24);
    return days + ' day' + (days === 1 ? '' : 's') + ' ago';
  }

  var WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var WEEKDAY_ABBR = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  /* Same best-effort free-text day matcher used on the teacher dashboard
     (see js/teacher/teacher-portal.js) — schedules.day is admin-typed
     text ("Wed", "MWF", "TTh"…) with no fixed format. */
  function dayMatchesToday(dayStr) {
    var d = String(dayStr || '').trim();
    if (!d) return false;
    var lower = d.toLowerCase();
    var today = new Date().getDay();
    if (lower.indexOf(WEEKDAY_NAMES[today].toLowerCase()) !== -1 || lower.indexOf(WEEKDAY_ABBR[today]) !== -1) return true;
    switch (today) {
      case 0: return /su/i.test(d);
      case 1: return /m/i.test(d);
      case 2: return /t(?!h)/i.test(d);
      case 3: return /w/i.test(d);
      case 4: return /th/i.test(d);
      case 5: return /f/i.test(d);
      case 6: return /s(?!u)/i.test(d);
      default: return false;
    }
  }

  /* ---- Enrolled subjects (from enrollments.js, approved records only —
     pending isn't officially enrolled yet). ---- */
  function renderSubjects() {
    if (!window.TCCEnrollments) return;
    var approved = window.TCCEnrollments.forStudent(studentEmail).filter(function (r) { return r.status === 'approved'; });
    var count = approved.reduce(function (sum, r) { return sum + (r.subjects || []).length; }, 0);
    subjectsValue.textContent = String(count);
    if (subjectsDetail) subjectsDetail.textContent = approved.length ? approved[0].term : 'No approved enrollment yet';
  }

  /* ---- Attendance rate (from attendance.js) — Late counts as half, same
     weighting the Attendance tab itself already documents. ---- */
  function renderAttendanceStat() {
    if (!window.TCCAttendance || !attendanceValue) return;
    var rows = window.TCCAttendance.forStudent(studentEmail);
    if (!rows.length) {
      attendanceValue.textContent = '\u2014';
      if (attendanceDetail) attendanceDetail.textContent = 'No records yet';
      return;
    }
    var score = rows.reduce(function (sum, r) {
      return sum + (r.status === 'Present' ? 1 : r.status === 'Late' ? 0.5 : 0);
    }, 0);
    var pct = Math.round((score / rows.length) * 100);
    attendanceValue.textContent = pct + '%';
    if (attendanceDetail) attendanceDetail.textContent = pct >= 90 ? 'Above the 90% requirement' : 'Below the 90% requirement';
  }

  /* ---- Grades recorded (from grades.js). ---- */
  function renderGradesStat() {
    if (!window.TCCGrades) return;
    var rows = window.TCCGrades.forStudent(studentEmail);
    if (gradesValue) gradesValue.textContent = String(rows.length);
    var passing = rows.filter(function (r) { return window.TCCGrades.computeStatus(r.midterm, r.final) === 'passing'; }).length;
    var pending = rows.filter(function (r) { return window.TCCGrades.computeStatus(r.midterm, r.final) === 'pending'; }).length;
    if (gradesDetail) gradesDetail.textContent = rows.length ? (passing + ' passing \u00b7 ' + pending + ' pending') : 'No grades entered yet';

    if (gradesList) {
      var top = rows.slice(0, 3);
      if (!top.length) {
        gradesList.innerHTML = '';
        if (gradesListEmpty) gradesListEmpty.hidden = false;
      } else {
        if (gradesListEmpty) gradesListEmpty.hidden = true;
        gradesList.innerHTML = top.map(function (r) {
          var status = window.TCCGrades.computeStatus(r.midterm, r.final);
          var badgeClass = status === 'passing' ? 'badge--good' : status === 'failing' ? 'badge--bad' : 'badge--warn';
          var scoreLabel = r.final != null ? r.final : (r.midterm != null ? r.midterm : 'Pending');
          return '<div class="portal-row">' +
            '<div class="portal-row-main"><b>' + escapeHtml(r.subject) + '</b><span>' + escapeHtml(r.term) + '</span></div>' +
            '<div class="portal-row-meta"><span class="badge ' + badgeClass + '">' + escapeHtml(String(scoreLabel)) + '</span></div>' +
            '</div>';
        }).join('');
      }
    }
  }

  /* ---- Announcements (from announcements.js). ---- */
  function renderAnnouncements() {
    if (!window.TCCAnnouncements) return;
    var items = window.TCCAnnouncements.forAudience('student');
    if (annCountValue) annCountValue.textContent = String(items.length);
    if (annCountDetail) annCountDetail.textContent = items.length ? 'From registrar & instructors' : 'None posted yet';

    if (annList) {
      var top = items.slice(0, 3);
      if (!top.length) {
        annList.innerHTML = '';
        if (annListEmpty) annListEmpty.hidden = false;
      } else {
        if (annListEmpty) annListEmpty.hidden = true;
        annList.innerHTML = top.map(function (a) {
          return '<div class="portal-row">' +
            '<div class="portal-row-main"><b>' + escapeHtml(a.title) + '</b><span>' + escapeHtml(a.postedByName) + '</span></div>' +
            '<div class="portal-row-meta">' + timeAgo(a.postedAt) + '</div>' +
            '</div>';
        }).join('');
      }
    }
  }

  /* ---- Today's schedule (from schedules.js, admin-managed) — matched by
     this student's own section, the same free-text field admin assigns
     from Students → Section (see student-profile.js for where the badge
     on the Profile tab comes from). No section on file means no reliable
     match, so the card says so plainly instead of showing someone else's
     classes. ---- */
  function renderSchedule() {
    if (!scheduleList || !window.TCCSchedules) return;
    if (scheduleDay) scheduleDay.textContent = WEEKDAY_NAMES[new Date().getDay()];
    if (!mySection) {
      scheduleList.innerHTML = '';
      if (scheduleEmpty) { scheduleEmpty.hidden = false; scheduleEmpty.textContent = 'No section on file yet \u2014 check the Profile tab, or ask the registrar to assign one.'; }
      return;
    }
    var target = mySection.trim().toLowerCase();
    var items = window.TCCSchedules.all().filter(function (s) {
      return String(s.section || '').trim().toLowerCase() === target && dayMatchesToday(s.day);
    });
    if (!items.length) {
      scheduleList.innerHTML = '';
      if (scheduleEmpty) { scheduleEmpty.hidden = false; scheduleEmpty.textContent = 'No classes on today\u2019s timetable for Section ' + mySection + '.'; }
      return;
    }
    if (scheduleEmpty) scheduleEmpty.hidden = true;
    scheduleList.innerHTML = items.map(function (s) {
      return '<div class="portal-row">' +
        '<div class="portal-row-main"><b>' + escapeHtml(s.subject) + '</b><span>' + escapeHtml(s.room || '\u2014') + (s.teacherName ? ' \u00b7 ' + escapeHtml(s.teacherName) : '') + '</span></div>' +
        '<div class="portal-row-meta">' + escapeHtml(s.time) + '<span class="portal-daytag">' + escapeHtml(s.day) + '</span></div>' +
        '</div>';
    }).join('');
  }

  renderSubjects();
  renderAttendanceStat();
  renderGradesStat();
  renderAnnouncements();
  renderSchedule();

  if (window.TCCEnrollments) { window.TCCEnrollments.onChange(renderSubjects); window.TCCEnrollments.ready.then(renderSubjects); }
  if (window.TCCAttendance) { window.TCCAttendance.onChange(renderAttendanceStat); window.TCCAttendance.ready.then(renderAttendanceStat); }
  if (window.TCCGrades) { window.TCCGrades.onChange(renderGradesStat); window.TCCGrades.ready.then(renderGradesStat); }
  if (window.TCCAnnouncements) { window.TCCAnnouncements.onChange(renderAnnouncements); window.TCCAnnouncements.ready.then(renderAnnouncements); }
  if (window.TCCSchedules) { window.TCCSchedules.onChange(renderSchedule); window.TCCSchedules.ready.then(renderSchedule); }

  // Own profile — just for the section badge used to match today's schedule.
  if (studentEmail && api.getToken()) {
    api.get('/profiles/me').then(function (p) {
      mySection = p && p.section ? p.section : null;
      renderSchedule();
    }).catch(function () { renderSchedule(); });
  }
})();
