/* =========================================================================
   Shared Excel / PDF export helper.
   Built on SheetJS (xlsx.full.min.js) and jsPDF + jspdf-autotable, both
   loaded via CDN <script> tags before this file. Used anywhere a table
   of records needs a "Download Excel" / "Download PDF" button.

   Used by:
   - teacher-dashboard.html (teacher-portal.js) -> "My students" export
   - admin/dashboard.html   (admin-roster.js)    -> teacher master list export
   ========================================================================= */
(function (global) {
  'use strict';

  // columns: [{ label: 'Name', value: function(row){ return row.name; }, width: 22 }]
  function toExcel(filename, sheetName, columns, rows) {
    if (!global.XLSX) { console.error('export.js: XLSX (SheetJS) did not load — check your connection and try again.'); return false; }
    var headers = columns.map(function (c) { return c.label; });
    var data = rows.map(function (r) { return columns.map(function (c) { return c.value(r); }); });
    var ws = global.XLSX.utils.aoa_to_sheet([headers].concat(data));
    ws['!cols'] = columns.map(function (c) { return { wch: c.width || 22 }; });
    var wb = global.XLSX.utils.book_new();
    global.XLSX.utils.book_append_sheet(wb, ws, (sheetName || 'Sheet1').slice(0, 31));
    global.XLSX.writeFile(wb, filename);
    return true;
  }

  function toPDF(filename, title, subtitle, columns, rows) {
    var jsPDFCtor = global.jspdf && global.jspdf.jsPDF;
    if (!jsPDFCtor) { console.error('export.js: jsPDF did not load — check your connection and try again.'); return false; }
    var doc = new jsPDFCtor({ orientation: 'landscape' });
    doc.setFontSize(14);
    doc.text(title || 'Report', 14, 16);
    var startY = 20;
    if (subtitle) {
      doc.setFontSize(10);
      doc.setTextColor(110);
      doc.text(subtitle, 14, 22);
      startY = 27;
    }
    doc.autoTable({
      head: [columns.map(function (c) { return c.label; })],
      body: rows.map(function (r) { return columns.map(function (c) { return c.value(r); }); }),
      startY: startY,
      styles: { fontSize: 9, cellPadding: 3 },
      headStyles: { fillColor: [17, 55, 38] },
      margin: { left: 14, right: 14 }
    });
    doc.save(filename);
    return true;
  }

  global.TCCExport = { toExcel: toExcel, toPDF: toPDF };
})(window);
