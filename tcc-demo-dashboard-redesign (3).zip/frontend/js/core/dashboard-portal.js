/* =========================================================================
   Shared behaviour for the sidebar dashboards
   (student-dashboard.html / teacher-dashboard.html / admin/dashboard.html).
   - Opens/closes the sidebar as a drawer on mobile
   - Switches between .portal-view sections via the URL hash
   - Filters any table wired up with data-filter="#tableId"
   ========================================================================= */
/* ---- Greet the actual signed-in person instead of the placeholder name --
   script.js stashes {name, email, role, detail} in sessionStorage at sign-in
   (there's no backend/session yet to look it up here instead). Only applies
   it if the role matches this page's data-role, so a stale/mismatched
   session never overwrites the placeholder with the wrong person. ---- */
(function () {
  var pageRole = document.documentElement.querySelector('[data-role]');
  pageRole = pageRole ? pageRole.getAttribute('data-role') : null;
  if (!pageRole) return;

  var session = null;
  try { session = JSON.parse(sessionStorage.getItem('tccSession') || 'null'); } catch (e) { session = null; }
  if (!session || session.role !== pageRole || !session.name) return;

  var fullName = String(session.name).trim();
  var firstName = fullName.split(/\s+/)[0] || fullName;
  var initials = fullName.split(/\s+/).filter(Boolean).slice(0, 2)
    .map(function (w) { return w.charAt(0).toUpperCase(); }).join('');

  var welcomeEl = document.getElementById('welcomeName');
  if (welcomeEl) welcomeEl.textContent = firstName;

  var nameEl = document.getElementById('personName');
  if (nameEl) nameEl.textContent = fullName;

  var avatarEl = document.getElementById('personAvatar');
  if (avatarEl && initials) avatarEl.textContent = initials;

  var detailEl = document.getElementById('personDetail');
  if (detailEl && session.detail) detailEl.textContent = session.detail;

  // ---- Same info, mirrored onto the new header profile menu (see
  // .portal-header in css/04-dashboard.css). Guarded independently so a
  // page without the header menu (none, currently) just skips this. ----
  var headerNameEl = document.getElementById('headerPersonName');
  if (headerNameEl) headerNameEl.textContent = fullName;
  var headerAvatarEl = document.getElementById('headerPersonAvatar');
  if (headerAvatarEl && initials) headerAvatarEl.textContent = initials;
  var headerDetailEl = document.getElementById('headerPersonDetail');
  if (headerDetailEl && session.detail) headerDetailEl.textContent = session.detail;
  var headerTriggerNameEl = document.getElementById('headerPersonTriggerName');
  if (headerTriggerNameEl) headerTriggerNameEl.textContent = firstName;
})();

/* ---- Header greeting — "Good morning/afternoon/evening, {name}!" in
   place of the old static "Welcome back,". Only touches the prefix span;
   #welcomeName itself is still set above (or left as the page's
   placeholder name if there's no matching session). ---- */
(function () {
  var prefixEl = document.getElementById('greetingPrefix');
  if (!prefixEl) return;
  var hour = new Date().getHours();
  var greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  prefixEl.textContent = greeting + ',';
})();

/* ---- Header date — "Tuesday, August 25, 2026" next to the greeting.
   Plain client-side clock read, not app data, so no API call needed. ---- */
(function () {
  var dateEl = document.getElementById('portalHeaderDate');
  if (!dateEl) return;
  dateEl.textContent = new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
})();

/* ---- Header profile menu — open/close only; "Change password" and
   "Log out" inside it are the site's existing link/handler
   (js/core/script.js already delegates [data-tcc-logout] globally). ---- */
(function () {
  var profile = document.querySelector('.portal-profile');
  var trigger = document.getElementById('headerProfileTrigger');
  if (!profile || !trigger) return;

  function close() { profile.classList.remove('open'); trigger.setAttribute('aria-expanded', 'false'); }
  function toggle() {
    var willOpen = !profile.classList.contains('open');
    profile.classList.toggle('open', willOpen);
    trigger.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
  }

  trigger.addEventListener('click', function (e) { e.stopPropagation(); toggle(); });
  document.addEventListener('click', function (e) { if (!profile.contains(e.target)) close(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
})();

(function () {
  var sidebar = document.getElementById('portalSidebar');
  var scrim = document.getElementById('portalScrim');
  var menuBtn = document.getElementById('portalMenuBtn');

  function openSidebar() {
    if (sidebar) sidebar.classList.add('open');
    if (scrim) scrim.classList.add('show');
  }
  function closeSidebar() {
    if (sidebar) sidebar.classList.remove('open');
    if (scrim) scrim.classList.remove('show');
  }
  if (menuBtn) menuBtn.addEventListener('click', openSidebar);
  if (scrim) scrim.addEventListener('click', closeSidebar);

  var navLinks = Array.prototype.slice.call(document.querySelectorAll('.portal-nav a[href^="#"]'));
  var views = Array.prototype.slice.call(document.querySelectorAll('.portal-view'));

  function showView(id) {
    views.forEach(function (v) { v.classList.toggle('active', v.id === id); });
    navLinks.forEach(function (a) { a.classList.toggle('active', a.getAttribute('href') === '#' + id); });
    // Let admin-*.js view scripts know a tab just became visible, so they
    // can pull fresh data immediately instead of showing whatever was last
    // fetched (which may be stale if it changed while this tab wasn't
    // active). See js/core/live-poll.js.
    try { window.dispatchEvent(new CustomEvent('tcc-view:shown', { detail: { id: id } })); } catch (e) { /* no-op */ }
  }

  function route() {
    var hash = (window.location.hash || '').replace('#', '');
    var fallback = views.length ? views[0].id : null;
    var id = hash && document.getElementById(hash) ? hash : fallback;
    if (id) showView(id);
    closeSidebar();
  }

  if (views.length) {
    window.addEventListener('hashchange', route);
    route();
  }

  /* Simple client-side table search: <input data-filter="#tableId"> */
  Array.prototype.slice.call(document.querySelectorAll('[data-filter]')).forEach(function (input) {
    var table = document.querySelector(input.getAttribute('data-filter'));
    if (!table) return;
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase();
      Array.prototype.slice.call(table.querySelectorAll('tbody tr')).forEach(function (tr) {
        tr.style.display = tr.textContent.toLowerCase().indexOf(q) > -1 ? '' : 'none';
      });
    });
  });
})();

/* =========================================================================
   Student portal additions (student-dashboard.html only) — Profile's
   edit/save toggle, Subject enrollment's running unit total, and Online
   registration's submit handler. Every piece is guarded by the element(s)
   it needs, so this whole block is a no-op on the teacher/admin dashboards
   even though they load this same shared file.
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }

  var session = null;
  try { session = JSON.parse(sessionStorage.getItem('tccSession') || 'null'); } catch (e) { session = null; }

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function timeAgo(iso) {
    if (!iso) return '—';
    var then = new Date(iso).getTime();
    if (isNaN(then)) return '—';
    var diff = Math.max(0, Date.now() - then);
    var mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + ' minute' + (mins === 1 ? '' : 's') + ' ago';
    var hours = Math.floor(mins / 60);
    if (hours < 24) return hours + ' hour' + (hours === 1 ? '' : 's') + ' ago';
    var days = Math.floor(hours / 24);
    if (days < 7) return days + ' day' + (days === 1 ? '' : 's') + ' ago';
    var weeks = Math.floor(days / 7);
    if (weeks < 5) return weeks + ' week' + (weeks === 1 ? '' : 's') + ' ago';
    return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  /* ---- Profile — "Edit contact details" reveals the fields, the same
     button becomes "Save changes" to commit (no backend yet, so this just
     re-locks the fields and confirms with a toast — see portal-note). ---- */
  var editBtn = document.getElementById('profileEditBtn');
  var contactForm = document.getElementById('profileContactForm');
  if (editBtn && contactForm) {
    var contactInputs = Array.prototype.slice.call(contactForm.querySelectorAll('input, select'));
    editBtn.addEventListener('click', function () {
      var editing = editBtn.getAttribute('data-editing') === 'true';
      if (!editing) {
        contactInputs.forEach(function (i) { i.disabled = false; });
        if (contactInputs[0]) contactInputs[0].focus();
        editBtn.textContent = 'Save changes';
        editBtn.setAttribute('data-editing', 'true');
      } else {
        contactInputs.forEach(function (i) { i.disabled = true; });
        editBtn.textContent = 'Edit contact details';
        editBtn.setAttribute('data-editing', 'false');
        toast('Profile updated', 'success');
      }
    });
  }

  /* ---- Subject enrollment — live unit total across checked subjects,
     capped at 24 units before "Enroll selected subjects" is enabled. ---- */
  var enrollForm = document.getElementById('enrollForm');
  if (enrollForm) {
    var MAX_UNITS = 24;
    var checks = Array.prototype.slice.call(enrollForm.querySelectorAll('input[type="checkbox"]'));
    var totalEl = document.getElementById('enrollUnitTotal');
    var countEl = document.getElementById('enrollSubjectCount');
    var submitBtn = document.getElementById('enrollSubmitBtn');
    function recalc() {
      var units = 0, count = 0;
      checks.forEach(function (c) {
        if (c.checked) { units += parseFloat(c.getAttribute('data-units') || '0'); count += 1; }
      });
      if (totalEl) totalEl.textContent = units;
      if (countEl) countEl.textContent = count;
      if (submitBtn) submitBtn.disabled = count === 0 || units > MAX_UNITS;
    }
    checks.forEach(function (c) { c.addEventListener('change', recalc); });
    recalc();
    enrollForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var selected = checks.filter(function (c) { return c.checked; });
      if (!selected.length || !window.TCCEnrollments) return;
      var subjects = selected.map(function (c) {
        return { code: c.getAttribute('data-code') || '', name: c.getAttribute('data-name') || '', units: Number(c.getAttribute('data-units')) || 0 };
      });
      var fallbackEmailEl = document.getElementById('profEmail');
      var studentEmail = (session && session.email) || (fallbackEmailEl ? fallbackEmailEl.value : '');
      var studentName = (session && session.name) || (document.getElementById('personName') ? document.getElementById('personName').textContent.trim() : 'Student');
      window.TCCEnrollments.add({ studentEmail: studentEmail, studentName: studentName, subjects: subjects, term: '1st Semester, SY 2026\u20132027' })
        .then(function (result) {
          if (result.error) { toast(result.error, 'error'); return; }
          toast(subjects.length + ' subject' + (subjects.length === 1 ? '' : 's') + ' submitted for enrollment', 'success');
          selected.forEach(function (c) { c.checked = false; });
          recalc();
          renderEnrollmentRequests();
        });
    });
  }

  /* ---- Your enrollment requests — status of subject-enrollment requests
     submitted above, scoped to the signed-in student. ---- */
  var enrollmentRequestsList = document.getElementById('enrollmentRequestsList');
  function renderEnrollmentRequests() {
    if (!enrollmentRequestsList || !window.TCCEnrollments) return;
    var fallbackEmailEl = document.getElementById('profEmail');
    var email = (session && session.email) || (fallbackEmailEl ? fallbackEmailEl.value : '');
    var items = email ? window.TCCEnrollments.forStudent(email) : [];
    var emptyEl = document.getElementById('enrollmentRequestsEmpty');
    if (!items.length) {
      enrollmentRequestsList.innerHTML = '';
      if (emptyEl) emptyEl.hidden = false;
      return;
    }
    if (emptyEl) emptyEl.hidden = true;
    enrollmentRequestsList.innerHTML = items.map(function (r) {
      var badgeClass = r.status === 'approved' ? 'badge--good' : r.status === 'rejected' ? 'badge--bad' : 'badge--warn';
      var badgeLabel = r.status === 'approved' ? 'Approved' : r.status === 'rejected' ? 'Rejected' : 'Pending';
      var names = r.subjects.map(function (s) { return s.name; }).join(', ');
      return '<div class="portal-row">' +
        '<div class="portal-row-main"><b>' + escapeHtml(names) + '</b><span>' + r.totalUnits + ' units \u00b7 ' + (r.source === 'assigned' ? 'Assigned by admin' : 'Your request') + '</span></div>' +
        '<div class="portal-row-meta"><span class="badge ' + badgeClass + '">' + badgeLabel + '</span></div>' +
        '</div>';
    }).join('');
  }
  if (enrollmentRequestsList && window.TCCEnrollments) {
    renderEnrollmentRequests();
    window.TCCEnrollments.onChange(renderEnrollmentRequests);
    window.TCCEnrollments.ready.then(renderEnrollmentRequests);
  }

  /* ---- Online registration — submits a real registration request to
     registrations.js for admin review; the status badge and history table
     reflect its actual pending/approved/rejected state (see
     admin/admin-enrollment-mgmt.js). Falls back to the static placeholder
     rows already in the markup until a request exists for this email. ---- */
  var regForm = document.getElementById('registrationForm');
  if (regForm && window.TCCRegistrations) {
    var statusBadge = document.getElementById('regStatusBadge');
    var historyBody = document.getElementById('regHistoryBody');

    function renderRegistrationStatus() {
      var fallbackEmailEl = document.getElementById('profEmail');
      var email = (session && session.email) || (fallbackEmailEl ? fallbackEmailEl.value : '');
      var mine = email ? window.TCCRegistrations.forStudent(email) : [];
      if (!mine.length) return; // keep the static placeholder badge + history
      var latest = mine[0];
      if (statusBadge) {
        var label = latest.status === 'approved' ? 'Registered' : latest.status === 'rejected' ? 'Rejected' : 'Pending review';
        var cls = latest.status === 'approved' ? 'badge--good' : latest.status === 'rejected' ? 'badge--bad' : 'badge--warn';
        statusBadge.textContent = label;
        statusBadge.className = 'badge ' + cls;
      }
      if (historyBody) {
        historyBody.innerHTML = mine.map(function (r) {
          var badgeCls = r.status === 'approved' ? 'badge--good' : r.status === 'rejected' ? 'badge--bad' : 'badge--warn';
          var label = r.status === 'approved' ? 'Completed' : r.status === 'rejected' ? 'Rejected' : 'Pending';
          var dateStr = new Date(r.submittedAt).toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
          return '<tr><td>' + escapeHtml(r.term) + '</td><td>' + escapeHtml(r.type) + '</td><td>' + dateStr + '</td><td><span class="badge ' + badgeCls + '">' + label + '</span></td></tr>';
        }).join('');
      }
    }
    renderRegistrationStatus();
    window.TCCRegistrations.onChange(renderRegistrationStatus);
    window.TCCRegistrations.ready.then(renderRegistrationStatus);

    regForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var termSelect = regForm.querySelector('[name="regTerm"]');
      var typeChecked = regForm.querySelector('input[name="regType"]:checked');
      var termLabel = (termSelect && termSelect.options[termSelect.selectedIndex]) ? termSelect.options[termSelect.selectedIndex].text : 'this term';
      var fallbackEmailEl = document.getElementById('profEmail');
      var studentEmail = (session && session.email) || (fallbackEmailEl ? fallbackEmailEl.value : '');
      var studentName = (session && session.name) || (document.getElementById('personName') ? document.getElementById('personName').textContent.trim() : 'Student');
      window.TCCRegistrations.add({
        studentEmail: studentEmail, studentName: studentName, term: termLabel,
        yearLevel: document.getElementById('regYearLevel') ? document.getElementById('regYearLevel').value : '',
        type: typeChecked ? typeChecked.value : 'Regular'
      }).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        if (statusBadge) { statusBadge.textContent = 'Pending review'; statusBadge.className = 'badge badge--warn'; }
        toast('Registration submitted for ' + termLabel + ' \u2014 awaiting admin review', 'success');
        renderRegistrationStatus();
      });
    });
  }

  /* ---- Grades — swaps in the signed-in student's real entries from
     grades.js, if any exist. Leaves the placeholder rows alone otherwise,
     so the section never looks empty for a demo login that doesn't match
     a teacher-entered record (see the Gradebook on teacher-dashboard.html). ---- */
  var gradesBody = document.getElementById('studentGradesBody');
  if (gradesBody && window.TCCGrades) {
    var renderGrades = function () {
      var email = session && session.email;
      var rows = email ? window.TCCGrades.forStudent(email) : [];
      if (!rows.length) return;
      gradesBody.innerHTML = rows.map(function (r) {
        var status = window.TCCGrades.computeStatus(r.midterm, r.final);
        var badgeClass = status === 'passing' ? 'badge--good' : status === 'failing' ? 'badge--bad' : 'badge--warn';
        var badgeLabel = status === 'passing' ? 'Passing' : status === 'failing' ? 'Failing' : 'Pending';
        return '<tr>' +
          '<td>' + escapeHtml(r.subject) + '</td>' +
          '<td>' + escapeHtml(r.teacherName || '\u2014') + '</td>' +
          '<td>' + escapeHtml(r.term) + '</td>' +
          '<td>' + (r.midterm == null ? '\u2014' : r.midterm) + '</td>' +
          '<td>' + (r.final == null ? '\u2014' : r.final) + '</td>' +
          '<td><span class="badge ' + badgeClass + '">' + badgeLabel + '</span></td>' +
          '<td>' + escapeHtml(r.remarks || '\u2014') + '</td>' +
          '</tr>';
      }).join('');
    };
    renderGrades();
    window.TCCGrades.onChange(renderGrades);
    window.TCCGrades.ready.then(renderGrades);
  }

  /* ---- Attendance — swaps in the signed-in student's real records from
     attendance.js, if any exist. Leaves the placeholder rows alone
     otherwise (see admin's Attendance Management for how records get
     created/edited). ---- */
  var attendanceBody = document.getElementById('studentAttendanceBody');
  if (attendanceBody && window.TCCAttendance) {
    var renderAttendance = function () {
      var fallbackEmailEl = document.getElementById('profEmail');
      var email = (session && session.email) || (fallbackEmailEl ? fallbackEmailEl.value : '');
      var rows = email ? window.TCCAttendance.forStudent(email) : [];
      if (!rows.length) return;
      attendanceBody.innerHTML = rows.map(function (a) {
        var badgeClass = a.status === 'Present' ? 'badge--good' : a.status === 'Late' ? 'badge--warn' : 'badge--bad';
        var dateStr = new Date(a.date + 'T00:00:00').toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
        return '<tr>' +
          '<td>' + dateStr + '</td>' +
          '<td>' + escapeHtml(a.subject) + '</td>' +
          '<td><span class="badge ' + badgeClass + '">' + escapeHtml(a.status) + '</span></td>' +
          '<td>' + escapeHtml(a.remarks || '\u2014') + '</td>' +
          '</tr>';
      }).join('');
    };
    renderAttendance();
    window.TCCAttendance.onChange(renderAttendance);
    window.TCCAttendance.ready.then(renderAttendance);
  }

  /* ---- Announcement Center — searchable/filterable/sortable feed with
     read/unread state and a detail view, from announcement-center.js.
     GET /api/announcements is already scoped to this student server-side
     (broadcasts + their own teachers' posts), so all() is the full feed. ---- */
  if (document.getElementById('studentAnnouncementCenter') && window.TCCAnnouncementCenter) {
    window.TCCAnnouncementCenter.mount({
      containerId: 'studentAnnouncementCenter',
      getItems: function () { return window.TCCAnnouncements.all(); },
      role: 'student',
      emptyMessage: 'No announcements yet.'
    });
  }

  /* ---- Feedback & suggestions — submit form + "your submissions" list,
     scoped to whatever email is currently in the form (defaults to the
     signed-in session's email, same as Profile's prefilled contact info). ---- */
  var fbForm = document.getElementById('studentFeedbackForm');
  if (fbForm && window.TCCFeedback) {
    var fbNameInput = document.getElementById('fbName');
    var fbEmailInput = document.getElementById('fbEmail');
    var fbList = document.getElementById('studentFeedbackList');
    var fbEmpty = document.getElementById('studentFeedbackEmpty');

    if (session && session.name && fbNameInput) fbNameInput.value = session.name;
    if (session && session.email && fbEmailInput) fbEmailInput.value = session.email;

    var renderFeedback = function () {
      if (!fbList) return;
      var email = (fbEmailInput && fbEmailInput.value.trim()) || (session && session.email) || '';
      var items = email ? window.TCCFeedback.forUser(email) : [];
      if (!items.length) {
        fbList.innerHTML = '';
        if (fbEmpty) fbEmpty.hidden = false;
        return;
      }
      if (fbEmpty) fbEmpty.hidden = true;
      fbList.innerHTML = items.map(function (f) {
        var statusBadge = f.status === 'resolved' ? '<span class="badge badge--good">Resolved</span>' : '<span class="badge badge--warn">New</span>';
        var responseHtml = f.response
          ? '<div class="portal-row-response portal-row-full"><b>Admin response:</b> ' + escapeHtml(f.response) + '</div>'
          : '';
        return '<div class="portal-row">' +
          '<div class="portal-row-main"><b>' + escapeHtml(f.subject || f.category) + '</b><span>' + escapeHtml(f.category) + '</span>' + responseHtml + '</div>' +
          '<div class="portal-row-meta">' + statusBadge + '<br />' + timeAgo(f.submittedAt) + '</div>' +
          '</div>';
      }).join('');
    };
    renderFeedback();
    window.TCCFeedback.onChange(renderFeedback);
    window.TCCFeedback.ready.then(renderFeedback);

    fbForm.addEventListener('submit', function (e) {
      e.preventDefault();
      window.TCCFeedback.add({
        name: fbNameInput.value, email: fbEmailInput.value, role: 'student',
        category: document.getElementById('fbCategory').value,
        subject: document.getElementById('fbSubject').value,
        message: document.getElementById('fbMessage').value
      }).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        var keepName = fbNameInput.value, keepEmail = fbEmailInput.value;
        fbForm.reset();
        fbNameInput.value = keepName;
        fbEmailInput.value = keepEmail;
        toast('Feedback submitted \u2014 the admin office will review it', 'success');
        renderFeedback();
      });
    });
  }
})();
