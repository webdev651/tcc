/* =========================================================================
   Page guard for the sidebar dashboards (student-dashboard.html /
   teacher-dashboard.html / admin/dashboard.html).

   Problem this fixes: those pages are plain static HTML. Before this file
   existed, nothing stopped someone from typing the URL directly (or
   bookmarking it) and landing on the full dashboard shell with no login
   at all — the backend correctly rejected the *data* requests
   (requireAuth/requireAdmin on every /api/... route), but the page itself
   still rendered.

   Two layers, both must pass:
     1. Synchronous, runs immediately in <head> before the page paints.
        No token for this role in storage at all -> instant redirect,
        so there's no flash of the dashboard shell.
     2. Async, runs once api-client.js is loaded. Confirms the token is
        still genuinely valid (not expired/forged/stale from a previous
        session) by asking the backend via GET /api/auth/me. If that
        fails, the stored session is cleared and the page redirects too.

   Include this as the very first thing in <head>, tagged with which role
   the page requires, e.g.:
     <script src="../js/core/auth-guard.js" data-page-role="admin"></script>
   It has to run before <body> exists (that's what makes layer 1 flash-
   free), so the role comes from the <script> tag's own data attribute via
   document.currentScript rather than from an element in the body.
   ========================================================================= */
(function () {
  'use strict';

  function getPageRole() {
    var thisScript = document.currentScript;
    return thisScript ? thisScript.getAttribute('data-page-role') : null;
  }

  function getLoginUrl(role) {
    // admin/dashboard.html lives one folder down from the rest.
    var inSubfolder = /\/admin\//.test(window.location.pathname);
    if (role === 'admin') return inSubfolder ? '../login-admin.html' : 'login-admin.html';
    return inSubfolder ? '../login.html' : 'login.html';
  }

  function readSession() {
    try { return JSON.parse(sessionStorage.getItem('tccSession') || 'null'); }
    catch (e) { return null; }
  }

  function readToken() {
    try { return sessionStorage.getItem('tcc-token'); }
    catch (e) { return null; }
  }

  function clearSession() {
    try { sessionStorage.removeItem('tccSession'); } catch (e) { /* no-op */ }
    try { sessionStorage.removeItem('tcc-token'); } catch (e) { /* no-op */ }
  }

  function bounce(role) {
    clearSession();
    window.location.replace(getLoginUrl(role));
  }

  var role = getPageRole();
  if (!role) return; // not a guarded page

  var token = readToken();
  var session = readSession();

  // ---- Layer 1: no token, or the session on file is for a different
  // role than this page — reject before anything renders. ----
  if (!token || !session || session.role !== role) {
    bounce(role);
    return;
  }

  // ---- Layer 2: once TCCApi is available, confirm the token is still
  // good with the backend itself. Runs after DOM content loads so
  // api-client.js (loaded later in body) has had a chance to register. ----
  document.addEventListener('DOMContentLoaded', function () {
    if (!window.TCCApi) return; // api-client.js failed to load; nothing more we can check client-side
    window.TCCApi.get('/auth/me').then(function (me) {
      if (!me || me.role !== role) bounce(role);
    }).catch(function () {
      bounce(role);
    });
  });
})();
