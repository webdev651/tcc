/* =========================================================================
   FEATURE 6 — Announcement Center.
   One shared, mountable widget (search + category/priority/status filters
   + sort + read/unread state + detail view) used by all three dashboards.
   Each dashboard mounts it against its own scoped container and supplies
   getItems() — but since GET /api/announcements is already role-scoped
   server-side (see js/modules/announcements.js), getItems is just
   `window.TCCAnnouncements.all` everywhere; the Center itself does the
   further slicing (search/filter/sort) client-side.

   Usage:
     window.TCCAnnouncementCenter.mount({
       containerId: 'announcementCenterRoot',   // empty <div> to render into
       getItems: function () { return window.TCCAnnouncements.all(); },
       role: 'student' | 'teacher' | 'admin',
       currentUserName: 'Jane Dela Cruz',        // for "own post" delete/edit
       canManageAll: false,                      // admin: edit/delete any + see status filter
       canDeleteOwn: false,                       // teacher: delete their own posts
       onEdit: function (item) { ... },           // admin only — populate the existing form
       emptyMessage: 'No announcements yet.'
     });

   Depends on: js/core/api-client.js, js/modules/announcements.js.
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCAnnouncements) { console.error('announcement-center.js requires js/modules/announcements.js to be loaded first.'); return; }

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function timeAgo(iso) {
    if (!iso) return '\u2014';
    var then = new Date(iso).getTime();
    if (isNaN(then)) return '\u2014';
    var diff = Math.max(0, Date.now() - then);
    var mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + ' minute' + (mins === 1 ? '' : 's') + ' ago';
    var hours = Math.floor(mins / 60);
    if (hours < 24) return hours + ' hour' + (hours === 1 ? '' : 's') + ' ago';
    var days = Math.floor(hours / 24);
    if (days < 7) return days + ' day' + (days === 1 ? '' : 's') + ' ago';
    var weeks = Math.floor(days / 7);
    if (weeks < 5) return weeks + ' week' + (weeks === 1 ? '' : 's') + ' ago';
    return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }
  function fmtDateTime(iso) {
    if (!iso) return '\u2014';
    var d = new Date(iso);
    if (isNaN(d)) return '\u2014';
    return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) +
      ' \u00b7 ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  }
  function snippet(body, max) {
    var s = String(body || '').replace(/\s+/g, ' ').trim();
    return s.length > max ? s.slice(0, max).trim() + '\u2026' : s;
  }
  function audienceLabel(a) {
    if (a === 'student') return 'Students';
    if (a === 'teacher') return 'Staff';
    return 'Everyone';
  }

  var PRIORITY_RANK = { Urgent: 4, High: 3, Normal: 2, Low: 1 };
  var CATEGORY_CLASS = {
    General: 'ann-badge--cat-general', Academic: 'ann-badge--cat-academic',
    Enrollment: 'ann-badge--cat-enrollment', Registration: 'ann-badge--cat-registration',
    Schedule: 'ann-badge--cat-schedule', Important: 'ann-badge--cat-important'
  };
  var PRIORITY_CLASS = {
    Low: 'ann-badge--pri-low', Normal: 'ann-badge--pri-normal',
    High: 'ann-badge--pri-high', Urgent: 'ann-badge--pri-urgent'
  };
  var STATUS_CLASS = {
    Published: 'ann-badge--status-published', Draft: 'ann-badge--status-draft', Archived: 'ann-badge--status-archived'
  };

  // ---- Shared detail modal — created once, reused by every mounted
  // instance (only one can ever be open at a time anyway). ----
  var modalEl = null;
  function ensureModal() {
    if (modalEl) return modalEl;
    modalEl = document.createElement('div');
    modalEl.className = 'ann-modal-overlay';
    modalEl.innerHTML =
      '<div class="ann-modal" role="dialog" aria-modal="true" aria-labelledby="annModalTitle">' +
      '  <button type="button" class="ann-modal-close" aria-label="Close">\u2715</button>' +
      '  <div class="ann-badges" id="annModalBadges"></div>' +
      '  <h2 id="annModalTitle" class="ann-modal-title"></h2>' +
      '  <div class="ann-modal-meta" id="annModalMeta"></div>' +
      '  <div class="ann-modal-body" id="annModalBody"></div>' +
      '  <div class="ann-modal-actions" id="annModalActions"></div>' +
      '</div>';
    document.body.appendChild(modalEl);
    modalEl.addEventListener('click', function (e) { if (e.target === modalEl) closeModal(); });
    modalEl.querySelector('.ann-modal-close').addEventListener('click', closeModal);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
    return modalEl;
  }
  function closeModal() { if (modalEl) modalEl.classList.remove('show'); }

  function badgesHtml(item, includeStatus) {
    var html = '<span class="badge ann-badge ' + (CATEGORY_CLASS[item.category] || '') + '">' + escapeHtml(item.category) + '</span>' +
      '<span class="badge ann-badge ' + (PRIORITY_CLASS[item.priority] || '') + '">' + escapeHtml(item.priority) + '</span>';
    if (includeStatus && item.status !== 'Published') {
      html += '<span class="badge ann-badge ' + (STATUS_CLASS[item.status] || '') + '">' + escapeHtml(item.status) + '</span>';
    }
    return html;
  }

  function openDetail(item, opts) {
    var api = window.TCCAnnouncements;
    var m = ensureModal();
    m.querySelector('#annModalBadges').innerHTML = badgesHtml(item, true);
    m.querySelector('#annModalTitle').textContent = item.title;
    m.querySelector('#annModalMeta').innerHTML =
      '<span>' + escapeHtml(item.postedByName) + (item.postedByRole ? ' \u00b7 ' + (item.postedByRole === 'admin' ? 'Admin office' : 'Teacher') : '') + '</span>' +
      '<span>' + fmtDateTime(item.postedAt) + '</span>' +
      '<span>Audience: ' + audienceLabel(item.audience) + '</span>';
    m.querySelector('#annModalBody').textContent = item.body;

    var isOwn = opts.currentUserName && item.postedByName === opts.currentUserName;
    var actions = [];
    actions.push('<button type="button" class="btn-outline" id="annModalToggleRead">' + (item.isRead ? 'Mark as unread' : 'Mark as read') + '</button>');
    if (opts.canManageAll) {
      actions.push('<button type="button" class="btn-outline" id="annModalEdit">Edit</button>');
      actions.push('<button type="button" class="btn-outline" id="annModalDelete">Delete</button>');
    } else if (opts.canDeleteOwn && isOwn) {
      actions.push('<button type="button" class="btn-outline" id="annModalDelete">Delete</button>');
    }
    m.querySelector('#annModalActions').innerHTML = actions.join('');

    var toggleBtn = m.querySelector('#annModalToggleRead');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', function () {
        var action = item.isRead ? api.markUnread(item.id) : api.markRead(item.id);
        action.then(function () {
          toggleBtn.textContent = item.isRead ? 'Mark as unread' : 'Mark as read';
        });
      });
    }
    var editBtn = m.querySelector('#annModalEdit');
    if (editBtn) {
      editBtn.addEventListener('click', function () {
        closeModal();
        if (opts.onEdit) opts.onEdit(item);
      });
    }
    var deleteBtn = m.querySelector('#annModalDelete');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', function () {
        if (!global.confirm('Delete "' + item.title + '"? This can\'t be undone.')) return;
        api.remove(item.id).then(function (deleted) {
          if (deleted) closeModal();
        });
      });
    }

    m.classList.add('show');
    if (!item.isRead) api.markRead(item.id);
  }

  function mount(opts) {
    var container = document.getElementById(opts.containerId);
    if (!container) return;
    var role = opts.role;
    var showStatusFilter = !!(opts.canManageAll || role === 'teacher');

    container.innerHTML =
      '<div class="ann-toolbar">' +
      '  <input type="search" class="portal-search ann-search" placeholder="Search announcements\u2026" aria-label="Search announcements" />' +
      '  <select class="ann-select" id="annFilterCategory" aria-label="Filter by category">' +
      '    <option value="">All categories</option>' +
      window.TCCAnnouncements.CATEGORIES.map(function (c) { return '<option value="' + c + '">' + c + '</option>'; }).join('') +
      '  </select>' +
      '  <select class="ann-select" id="annFilterPriority" aria-label="Filter by priority">' +
      '    <option value="">All priorities</option>' +
      window.TCCAnnouncements.PRIORITIES.map(function (p) { return '<option value="' + p + '">' + p + '</option>'; }).join('') +
      '  </select>' +
      (showStatusFilter ?
        '  <select class="ann-select" id="annFilterStatus" aria-label="Filter by status">' +
        '    <option value="">All statuses</option>' +
        window.TCCAnnouncements.STATUSES.map(function (s) { return '<option value="' + s + '">' + s + '</option>'; }).join('') +
        '  </select>' : '') +
      '  <select class="ann-select" id="annFilterRead" aria-label="Filter by read status">' +
      '    <option value="">All</option>' +
      '    <option value="unread">Unread</option>' +
      '    <option value="read">Read</option>' +
      '  </select>' +
      '  <select class="ann-select" id="annSort" aria-label="Sort">' +
      '    <option value="newest">Newest first</option>' +
      '    <option value="oldest">Oldest first</option>' +
      '    <option value="priority">Priority</option>' +
      '  </select>' +
      '</div>' +
      '<div class="portal-list" id="annCenterList"></div>' +
      '<p class="portal-note" id="annCenterEmpty" hidden>' + escapeHtml(opts.emptyMessage || 'No announcements yet.') + '</p>';

    var searchInput = container.querySelector('.ann-search');
    var catSelect = container.querySelector('#annFilterCategory');
    var priSelect = container.querySelector('#annFilterPriority');
    var statusSelect = container.querySelector('#annFilterStatus');
    var readSelect = container.querySelector('#annFilterRead');
    var sortSelect = container.querySelector('#annSort');
    var listEl = container.querySelector('#annCenterList');
    var emptyEl = container.querySelector('#annCenterEmpty');

    function render() {
      var items = (opts.getItems() || []).slice();
      var q = searchInput.value.trim().toLowerCase();
      var cat = catSelect.value;
      var pri = priSelect.value;
      var status = statusSelect ? statusSelect.value : '';
      var readFilter = readSelect.value;
      var sort = sortSelect.value;

      if (q) {
        items = items.filter(function (a) {
          return (a.title + ' ' + a.body + ' ' + a.postedByName + ' ' + a.category).toLowerCase().indexOf(q) > -1;
        });
      }
      if (cat) items = items.filter(function (a) { return a.category === cat; });
      if (pri) items = items.filter(function (a) { return a.priority === pri; });
      if (status) items = items.filter(function (a) { return a.status === status; });
      if (readFilter === 'unread') items = items.filter(function (a) { return !a.isRead; });
      if (readFilter === 'read') items = items.filter(function (a) { return a.isRead; });

      items.sort(function (a, b) {
        if (sort === 'oldest') return (a.postedAt || '').localeCompare(b.postedAt || '');
        if (sort === 'priority') {
          var diff = (PRIORITY_RANK[b.priority] || 0) - (PRIORITY_RANK[a.priority] || 0);
          return diff !== 0 ? diff : (b.postedAt || '').localeCompare(a.postedAt || '');
        }
        return (b.postedAt || '').localeCompare(a.postedAt || '');
      });

      if (!items.length) {
        listEl.innerHTML = '';
        emptyEl.hidden = false;
        return;
      }
      emptyEl.hidden = true;
      listEl.innerHTML = items.map(function (a) {
        return '<div class="ann-card' + (a.isRead ? '' : ' ann-card--unread') + '" data-ann-id="' + escapeHtml(a.id) + '" tabindex="0" role="button">' +
          '<div class="ann-card-top">' +
          (a.isRead ? '' : '<span class="ann-dot" aria-hidden="true"></span>') +
          '<span class="ann-card-title">' + escapeHtml(a.title) + '</span>' +
          '</div>' +
          '<div class="ann-badges">' + badgesHtml(a, true) + '</div>' +
          '<p class="ann-card-snippet">' + escapeHtml(snippet(a.body, 140)) + '</p>' +
          '<div class="ann-card-meta">' +
          '<span>' + escapeHtml(a.postedByName) + '</span>' +
          '<span>' + timeAgo(a.postedAt) + '</span>' +
          '<span>' + audienceLabel(a.audience) + '</span>' +
          '</div>' +
          '</div>';
      }).join('');
    }

    function openById(id) {
      var items = opts.getItems() || [];
      var item = items.filter(function (a) { return a.id === id; })[0];
      if (item) openDetail(item, opts);
    }

    listEl.addEventListener('click', function (e) {
      var card = e.target.closest('[data-ann-id]');
      if (card) openById(card.getAttribute('data-ann-id'));
    });
    listEl.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      var card = e.target.closest('[data-ann-id]');
      if (card) { e.preventDefault(); openById(card.getAttribute('data-ann-id')); }
    });

    [searchInput, catSelect, priSelect, statusSelect, readSelect, sortSelect].forEach(function (el) {
      if (!el) return;
      el.addEventListener('input', render);
      el.addEventListener('change', render);
    });

    render();
    window.TCCAnnouncements.onChange(render);
    window.TCCAnnouncements.ready.then(render);

    return { refresh: render };
  }

  global.TCCAnnouncementCenter = { mount: mount };
})(window);
