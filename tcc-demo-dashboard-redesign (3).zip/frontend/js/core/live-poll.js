/* =========================================================================
   Live auto-refresh — loaded on all three dashboards (admin, teacher,
   student).

   Every data module in js/modules/*.js (js/core/accounts.js, and the
   teacher-only js/modules/teacher-sections.js) follows the same shape: a
   `refresh()` that re-fetches from the API and fires a `tcc-<name>:changed`
   event, which the matching view script (js/admin/*.js, teacher-portal.js,
   dashboard-portal.js, etc.) listens for and re-renders on. That gets a
   view up to date the moment ITS OWN action (approve, add, delete, send...)
   resolves — but changes made elsewhere (an admin sending a section to a
   teacher, another tab, a different device) had no way to reach an
   already-open dashboard until the page was reloaded.

   This file closes that gap: every few seconds it finds every currently
   loaded module — anything on `window` whose name starts with "TCC" and
   exposes a `refresh()` — and calls it, plus immediately whenever the tab
   regains focus/visibility or the user switches to a different sidebar
   view. Each module's own notify()/event-listener plumbing takes care of
   the actual re-render, so nothing here needs a hardcoded list of module
   names (a hardcoded list silently stops covering a module the moment a
   new one is added, or a `refresh` isn't exported yet — auto-discovery
   can't go stale that way) or to know about tables, DOM, or which tab is
   open. Safe to load on any page: a module that isn't present on this
   page (e.g. TCCGrades on student-dashboard.html) just isn't found and is
   skipped, same as before.
   ========================================================================= */
(function (global) {
  'use strict';

  var POLL_MS = 3000;

  function pollAll() {
    if (document.visibilityState === 'hidden') return;
    Object.keys(global).forEach(function (key) {
      if (key.slice(0, 3) !== 'TCC') return;
      var mod = global[key];
      if (mod && typeof mod.refresh === 'function') {
        try { mod.refresh(); } catch (e) { /* no-op — next tick tries again */ }
      }
    });
  }

  setInterval(pollAll, POLL_MS);
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'visible') pollAll();
  });
  global.addEventListener('focus', pollAll);
  global.addEventListener('tcc-view:shown', pollAll);
})(window);
