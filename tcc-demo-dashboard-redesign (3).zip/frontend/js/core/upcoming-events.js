/* =========================================================================
   Feature 4 — Upcoming Events widget (student-dashboard.html,
   teacher-dashboard.html, admin/dashboard.html — Overview tab).

   Two sources, merged into one forward-looking timeline:
   1. window.TCCEvents (js/modules/events.js → GET /api/events) — admin-
      curated deadlines, school events, scheduled activities, and pinned
      "important announcement" entries. Already audience-scoped
      server-side (see src/routes/events.js), same as every other module.
   2. Upcoming classes — derived on the fly from window.TCCSchedules,
      the same source js/core/student-overview.js and
      js/teacher/teacher-portal.js already use for "Today's schedule" /
      "Today's classes", just projected forward to the next matching
      weekday instead of only checking today. Student/teacher only —
      admin's version of this widget shows institution-level events, not
      one person's personal timetable (that's what Section Management /
      the schedule tables are for).

   Guarded by element presence (#upcomingEventsList) — no-op on any page
   without that card, so one file covers all three dashboards.
   ========================================================================= */
(function () {
  if (!window.TCCApi) return;
  var api = window.TCCApi;

  var listEl = document.getElementById('upcomingEventsList');
  if (!listEl) return; // not on this page
  var emptyEl = document.getElementById('upcomingEventsEmpty');

  var MAX_ITEMS = 8;
  var WINDOW_DAYS = 30; // don't show anything further out than this

  var siteEl = document.querySelector('.site[data-role]');
  var role = siteEl ? siteEl.getAttribute('data-role') : '';

  var session = null;
  try { session = JSON.parse(sessionStorage.getItem('tccSession') || 'null'); } catch (e) { session = null; }
  var myName = (session && session.name) || (function () {
    var el = document.getElementById('personName');
    return el ? el.textContent.trim() : '';
  })();

  var mySection = null; // student only — filled from /profiles/me below

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDate(d) {
    return d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
  }
  function fmtWhen(d) {
    return d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  }
  function startOfDay(d) { return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
  function timeUntil(d) {
    var diffDays = Math.round((startOfDay(d) - startOfDay(new Date())) / 86400000);
    if (diffDays <= 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays < 7) return 'In ' + diffDays + ' days';
    var weeks = Math.round(diffDays / 7);
    if (diffDays < 30) return 'In ' + weeks + ' week' + (weeks === 1 ? '' : 's');
    return fmtDate(d);
  }
  function urgencyClass(d) {
    var diffDays = Math.round((startOfDay(d) - startOfDay(new Date())) / 86400000);
    if (diffDays <= 3) return 'bad';
    if (diffDays <= 7) return 'warn';
    return 'muted';
  }

  var TYPE_META = {
    announcement: { icon: '\u25A3', label: 'Important announcement', dot: 'announcement' },
    registration_deadline: { icon: '\u23F0', label: 'Registration deadline', dot: 'reg' },
    enrollment_deadline: { icon: '\u23F0', label: 'Enrollment deadline', dot: 'enroll' },
    academic_deadline: { icon: '\u23F0', label: 'Academic deadline', dot: 'academic' },
    school_event: { icon: '\u2605', label: 'School event', dot: 'event' },
    activity: { icon: '\u25C6', label: 'Scheduled activity', dot: 'activity' },
    exam: { icon: '\u270F', label: 'Exam', dot: 'exam' }
  };
  var DEADLINE_TYPES = ['registration_deadline', 'enrollment_deadline', 'academic_deadline'];

  var WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var WEEKDAY_ABBR = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  /* Same best-effort free-text day matcher used on the student/teacher
     overview cards (schedules.day is admin-typed text like "Wed", "MWF",
     "TTh" — no fixed format), just parameterized on which weekday to
     test instead of always "today". */
  function dayMatchesWeekday(dayStr, weekday) {
    var d = String(dayStr || '').trim();
    if (!d) return false;
    var lower = d.toLowerCase();
    if (lower.indexOf(WEEKDAY_NAMES[weekday].toLowerCase()) !== -1 || lower.indexOf(WEEKDAY_ABBR[weekday]) !== -1) return true;
    switch (weekday) {
      case 0: return /su/i.test(d);
      case 1: return /m/i.test(d);
      case 2: return /t(?!h)/i.test(d);
      case 3: return /w/i.test(d);
      case 4: return /th/i.test(d);
      case 5: return /f/i.test(d);
      case 6: return /s(?!u)/i.test(d);
      default: return false;
    }
  }
  /* Next date (today counts) this schedule's day-string next falls on,
     within the coming week — or null if nothing in the string matches
     any weekday. */
  function nextOccurrence(dayStr) {
    var today = new Date();
    for (var offset = 0; offset < 7; offset++) {
      var idx = (today.getDay() + offset) % 7;
      if (dayMatchesWeekday(dayStr, idx)) {
        var d = startOfDay(today);
        d.setDate(d.getDate() + offset);
        return d;
      }
    }
    return null;
  }

  function collect() {
    var items = [];
    var now = new Date();
    var windowEnd = new Date(now.getTime() + WINDOW_DAYS * 86400000);

    // ---- Admin-curated events (deadlines, school events, activities,
    //      pinned announcements) — already audience-scoped server-side. ----
    if (window.TCCEvents) {
      window.TCCEvents.upcoming().forEach(function (e) {
        var d = new Date(e.eventDate);
        if (isNaN(d) || d > windowEnd) return;
        var meta = TYPE_META[e.type] || TYPE_META.school_event;
        var isDeadline = DEADLINE_TYPES.indexOf(e.type) !== -1;
        items.push({
          icon: meta.icon,
          dotClass: meta.dot,
          title: e.title,
          detail: e.description || meta.label,
          date: d,
          badgeLabel: timeUntil(d),
          badgeClass: isDeadline ? urgencyClass(d) : 'muted'
        });
      });
    }

    // ---- Upcoming classes (student: own section · teacher: own name) —
    //      one entry per schedule row for its next occurrence only, not
    //      every week going forward, so the widget doesn't fill up with
    //      the same class repeated. ----
    if (window.TCCSchedules && (role === 'student' || role === 'teacher')) {
      var schedules = [];
      if (role === 'teacher') schedules = window.TCCSchedules.byTeacherName(myName);
      else if (mySection) {
        var target = mySection.trim().toLowerCase();
        schedules = window.TCCSchedules.all().filter(function (s) {
          return String(s.section || '').trim().toLowerCase() === target;
        });
      }
      schedules.forEach(function (s) {
        var d = nextOccurrence(s.day);
        if (!d) return;
        items.push({
          icon: '\u25A6',
          dotClass: 'class',
          title: s.subject,
          detail: (s.time || '') + (s.room ? ' \u00b7 Rm ' + s.room : '') + (role !== 'student' && s.section ? ' \u00b7 ' + s.section : ''),
          date: d,
          badgeLabel: timeUntil(d),
          badgeClass: 'muted'
        });
      });
    }

    render(items);
  }

  function render(items) {
    var sorted = items.slice().sort(function (a, b) { return a.date - b.date; }).slice(0, MAX_ITEMS);

    if (!sorted.length) {
      listEl.innerHTML = '';
      if (emptyEl) emptyEl.hidden = false;
      return;
    }
    if (emptyEl) emptyEl.hidden = true;
    listEl.innerHTML = sorted.map(function (i) {
      return '<div class="timeline-item">' +
        '<span class="timeline-dot timeline-dot--' + i.dotClass + '" aria-hidden="true">' + i.icon + '</span>' +
        '<div class="timeline-card">' +
          '<div class="timeline-card-head">' +
            '<b>' + escapeHtml(i.title) + '</b>' +
            '<span class="badge badge--' + i.badgeClass + '">' + escapeHtml(i.badgeLabel) + '</span>' +
          '</div>' +
          '<p class="timeline-detail">' + escapeHtml(i.detail) + '</p>' +
          '<span class="timeline-when" title="' + escapeHtml(fmtWhen(i.date)) + '">' + escapeHtml(fmtDate(i.date)) + '</span>' +
        '</div>' +
        '</div>';
    }).join('');
  }

  if (window.TCCEvents) { window.TCCEvents.onChange(collect); window.TCCEvents.ready.then(collect); }
  if (window.TCCSchedules) { window.TCCSchedules.onChange(collect); window.TCCSchedules.ready.then(collect); }

  if (role === 'student' && api.getToken()) {
    api.get('/profiles/me').then(function (p) {
      mySection = p && p.section ? p.section : null;
      collect();
    }).catch(function () { collect(); });
  }

  collect();
})();
