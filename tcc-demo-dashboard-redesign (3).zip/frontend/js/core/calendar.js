/* =========================================================================
   Feature 5 — My Calendar (student-dashboard.html, teacher-dashboard.html,
   admin/dashboard.html — its own "Calendar" tab).

   Same two data sources as js/core/upcoming-events.js, just expanded
   across a full month grid instead of a short forward-looking list:
   1. window.TCCEvents (GET /api/events, already audience-scoped
      server-side) — school events, registration/enrollment/academic
      deadlines, exams, important announcements. Uses all() rather than
      upcoming() so browsing to a past month still shows what happened.
   2. Recurring classes from window.TCCSchedules, placed on every date in
      the visible grid whose weekday matches — student's own section /
      teacher's own name. Admin's calendar intentionally has no class
      overlay (same scoping decision as the Upcoming Events widget):
      admin's four event types are all institution-level, not one
      person's personal timetable.

   Guarded by element presence (#calendarGrid) — no-op on any page
   without that tab, so one file covers all three dashboards.
   ========================================================================= */
(function () {
  if (!window.TCCApi) return;
  var api = window.TCCApi;

  var gridEl = document.getElementById('calendarGrid');
  if (!gridEl) return; // not on this page
  var monthLabelEl = document.getElementById('calendarMonthLabel');
  var prevBtn = document.getElementById('calendarPrevBtn');
  var nextBtn = document.getElementById('calendarNextBtn');
  var todayBtn = document.getElementById('calendarTodayBtn');
  var agendaTitleEl = document.getElementById('calendarAgendaTitle');
  var agendaListEl = document.getElementById('calendarAgendaList');
  var agendaEmptyEl = document.getElementById('calendarAgendaEmpty');

  var siteEl = document.querySelector('.site[data-role]');
  var role = siteEl ? siteEl.getAttribute('data-role') : '';

  var session = null;
  try { session = JSON.parse(sessionStorage.getItem('tccSession') || 'null'); } catch (e) { session = null; }
  var myName = (session && session.name) || (function () {
    var el = document.getElementById('personName');
    return el ? el.textContent.trim() : '';
  })();

  var mySection = null; // student only — filled from /profiles/me below
  var today = new Date();
  var currentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  var selectedDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function pad2(n) { return String(n).padStart(2, '0'); }
  function dateKey(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function sameDay(a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
  function fmtTime(d) { return d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }); }

  var TYPE_META = {
    announcement: { icon: '\u25A3', label: 'Important announcement', dot: 'announcement' },
    registration_deadline: { icon: '\u23F0', label: 'Registration deadline', dot: 'reg' },
    enrollment_deadline: { icon: '\u23F0', label: 'Enrollment deadline', dot: 'enroll' },
    academic_deadline: { icon: '\u23F0', label: 'Academic deadline', dot: 'academic' },
    school_event: { icon: '\u2605', label: 'School event', dot: 'event' },
    activity: { icon: '\u25C6', label: 'Scheduled activity', dot: 'activity' },
    exam: { icon: '\u270F', label: 'Exam', dot: 'exam' }
  };

  var WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var WEEKDAY_ABBR = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  // Same best-effort free-text day matcher used by js/core/upcoming-events.js
  // and the student/teacher overview cards (schedules.day is admin-typed
  // text like "Wed", "MWF", "TTh" — no fixed format).
  function dayMatchesWeekday(dayStr, weekday) {
    var d = String(dayStr || '').trim();
    if (!d) return false;
    var lower = d.toLowerCase();
    if (lower.indexOf(WEEKDAY_NAMES[weekday].toLowerCase()) !== -1 || lower.indexOf(WEEKDAY_ABBR[weekday]) !== -1) return true;
    switch (weekday) {
      case 0: return /su/i.test(d);
      case 1: return /m/i.test(d);
      case 2: return /t(?!h)/i.test(d);
      case 3: return /w/i.test(d);
      case 4: return /th/i.test(d);
      case 5: return /f/i.test(d);
      case 6: return /s(?!u)/i.test(d);
      default: return false;
    }
  }

  function buildEventMap(gridDates) {
    var map = {};
    function addItem(d, item) {
      var key = dateKey(d);
      if (!map[key]) map[key] = [];
      map[key].push(item);
    }

    if (window.TCCEvents) {
      window.TCCEvents.all().forEach(function (e) {
        var d = new Date(e.eventDate);
        if (isNaN(d)) return;
        var meta = TYPE_META[e.type] || TYPE_META.school_event;
        addItem(d, {
          icon: meta.icon, dotClass: meta.dot, title: e.title,
          detail: e.description || meta.label,
          time: fmtTime(d), badgeLabel: meta.label, badgeClass: 'muted'
        });
      });
    }

    if (window.TCCSchedules && (role === 'student' || role === 'teacher')) {
      var schedules = [];
      if (role === 'teacher') schedules = window.TCCSchedules.byTeacherName(myName);
      else if (mySection) {
        var target = mySection.trim().toLowerCase();
        schedules = window.TCCSchedules.all().filter(function (s) {
          return String(s.section || '').trim().toLowerCase() === target;
        });
      }
      if (schedules.length) {
        gridDates.forEach(function (d) {
          schedules.forEach(function (s) {
            if (!dayMatchesWeekday(s.day, d.getDay())) return;
            addItem(d, {
              icon: '\u25A6', dotClass: 'class', title: s.subject,
              detail: (s.time || '') + (s.room ? ' \u00b7 Rm ' + s.room : '') + (role !== 'student' && s.section ? ' \u00b7 ' + s.section : ''),
              time: s.time || '', badgeLabel: role === 'teacher' ? 'Teaching' : 'Class', badgeClass: 'muted'
            });
          });
        });
      }
    }

    return map;
  }

  function render() {
    var firstOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
    var gridStart = new Date(firstOfMonth);
    gridStart.setDate(gridStart.getDate() - firstOfMonth.getDay());

    var gridDates = [];
    for (var i = 0; i < 42; i++) {
      var d = new Date(gridStart);
      d.setDate(gridStart.getDate() + i);
      gridDates.push(d);
    }

    var eventMap = buildEventMap(gridDates);

    if (monthLabelEl) monthLabelEl.textContent = currentMonth.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

    gridEl.innerHTML = gridDates.map(function (d) {
      var key = dateKey(d);
      var items = eventMap[key] || [];
      var classes = ['calendar-day'];
      if (d.getMonth() !== currentMonth.getMonth()) classes.push('calendar-day--other');
      if (sameDay(d, today)) classes.push('calendar-day--today');
      if (sameDay(d, selectedDate)) classes.push('calendar-day--selected');
      var dots = items.slice(0, 4).map(function (it) {
        return '<span class="calendar-dot calendar-dot--' + it.dotClass + '"></span>';
      }).join('');
      var more = items.length > 4 ? '<span class="calendar-more">+' + (items.length - 4) + '</span>' : '';
      var label = d.toDateString() + (items.length ? ', ' + items.length + ' event' + (items.length === 1 ? '' : 's') : '');
      return '<button type="button" class="' + classes.join(' ') + '" data-date="' + key + '" aria-label="' + escapeHtml(label) + '">' +
        '<span class="calendar-day-num">' + d.getDate() + '</span>' +
        '<span class="calendar-day-dots">' + dots + more + '</span>' +
        '</button>';
    }).join('');

    renderAgenda(eventMap[dateKey(selectedDate)] || []);
  }

  function renderAgenda(items) {
    if (agendaTitleEl) {
      agendaTitleEl.textContent = selectedDate.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
    }
    if (!agendaListEl) return;
    if (!items.length) {
      agendaListEl.innerHTML = '';
      if (agendaEmptyEl) agendaEmptyEl.hidden = false;
      return;
    }
    if (agendaEmptyEl) agendaEmptyEl.hidden = true;
    agendaListEl.innerHTML = items.map(function (it) {
      return '<div class="portal-row portal-row--activity">' +
        '<span class="activity-icon" aria-hidden="true">' + it.icon + '</span>' +
        '<div class="portal-row-main"><b>' + escapeHtml(it.title) + '</b><span>' + escapeHtml(it.detail) + '</span></div>' +
        '<div class="portal-row-meta"><span class="badge badge--' + it.badgeClass + '">' + escapeHtml(it.badgeLabel) + '</span>' +
        (it.time ? '<span class="activity-when">' + escapeHtml(it.time) + '</span>' : '') + '</div>' +
        '</div>';
    }).join('');
  }

  if (prevBtn) prevBtn.addEventListener('click', function () {
    currentMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1);
    render();
  });
  if (nextBtn) nextBtn.addEventListener('click', function () {
    currentMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1);
    render();
  });
  if (todayBtn) todayBtn.addEventListener('click', function () {
    currentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    selectedDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    render();
  });
  gridEl.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('[data-date]') : null;
    if (!btn) return;
    var parts = btn.getAttribute('data-date').split('-').map(Number);
    selectedDate = new Date(parts[0], parts[1] - 1, parts[2]);
    if (selectedDate.getMonth() !== currentMonth.getMonth() || selectedDate.getFullYear() !== currentMonth.getFullYear()) {
      currentMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
    }
    render();
  });

  if (window.TCCEvents) { window.TCCEvents.onChange(render); window.TCCEvents.ready.then(render); }
  if (window.TCCSchedules) { window.TCCSchedules.onChange(render); window.TCCSchedules.ready.then(render); }

  if (role === 'student' && api.getToken()) {
    api.get('/profiles/me').then(function (p) {
      mySection = p && p.section ? p.section : null;
      render();
    }).catch(function () { render(); });
  }

  render();
})();
