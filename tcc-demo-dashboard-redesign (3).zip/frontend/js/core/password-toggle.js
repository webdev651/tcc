/* =========================================================================
   Show / hide password toggle.
   Wraps every .field input[type="password"] on the page with a small
   eye-icon button that flips the input between type="password" and
   type="text". Pure UI (no form/validation logic touched), so it's safe
   to drop into any page that already has password fields — login.html,
   admin/index.html (admin login), signup.html, change-password.html.

   Usage: just include this script tag anywhere after componentcraft-ui.js
   and before the closing </body>; it wires itself up on DOMContentLoaded.
   ========================================================================= */
(function () {
  'use strict';

  var EYE_ON =
    '<svg class="pw-eye-on" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
  var EYE_OFF =
    '<svg class="pw-eye-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.6 20.6 0 0 1 5.06-5.94M9.9 4.24A10.4 10.4 0 0 1 12 4c7 0 11 7 11 7a20.6 20.6 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>' +
    '<line x1="1" y1="1" x2="23" y2="23"/></svg>';

  function wire(input) {
    if (!input || input.dataset.pwWired) return;
    input.dataset.pwWired = 'true';

    var wrap = document.createElement('div');
    wrap.className = 'pw-field';
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pw-toggle';
    btn.setAttribute('aria-pressed', 'false');
    btn.setAttribute('aria-label', 'Show password');
    btn.tabIndex = 0;
    btn.innerHTML = EYE_ON + EYE_OFF;
    wrap.appendChild(btn);

    btn.addEventListener('click', function () {
      var showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      btn.setAttribute('aria-pressed', String(!showing));
      btn.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
    });
  }

  function init() {
    var inputs = document.querySelectorAll('.field input[type="password"]');
    for (var i = 0; i < inputs.length; i++) wire(inputs[i]);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
