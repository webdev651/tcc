/* =========================================================================
   Recent Activity (student-dashboard.html, teacher-dashboard.html,
   admin/dashboard.html — Overview tab, shared across all three).

   Builds a single "what just happened" feed out of data the page has
   already loaded — no new backend endpoint. Every js/modules/*.js data
   layer's GET is already scoped server-side to the signed-in role (see
   each route's `router.use(requireAuth, ...)` and its admin=all /
   teacher=own / student=own branching), so this file just re-shapes
   whatever's already sitting in window.TCCEnrollments / TCCGrades /
   TCCSections / TCCSchedules / TCCAnnouncements / TCCAttendance into one
   sorted timeline. A module that isn't loaded on a given page (e.g.
   TCCSections only exists on admin/dashboard.html) is simply skipped —
   feature-detected the same way js/core/student-overview.js already
   does for the cards above it.

   One event type is added only via a live fetch, since it isn't exposed
   by any module already loaded on the teacher dashboard: "Section
   assigned", read from GET /api/teacher/notifications (the same feed
   js/teacher/teacher-notifications.js renders in full below), filtered
   to the ones src/routes/sections.js creates with a title starting
   "Section assigned: ".

   Guarded by element presence (#recentActivityList) — no-op on any page
   without that card, so this one file can be included everywhere.
   ========================================================================= */
(function () {
  if (!window.TCCApi) return;
  var api = window.TCCApi;

  var listEl = document.getElementById('recentActivityList');
  if (!listEl) return; // not on this page
  var emptyEl = document.getElementById('recentActivityEmpty');

  var MAX_ITEMS = 8;

  var siteEl = document.querySelector('.site[data-role]');
  var role = siteEl ? siteEl.getAttribute('data-role') : '';

  var session = null;
  try { session = JSON.parse(sessionStorage.getItem('tccSession') || 'null'); } catch (e) { session = null; }
  var myEmail = String((session && session.email) || '').trim().toLowerCase();
  var myName = (session && session.name) || (function () {
    var el = document.getElementById('personName');
    return el ? el.textContent.trim() : '';
  })();

  var mySection = null;              // student only — filled from /profiles/me below
  var teacherSectionEvents = [];     // teacher only — filled from /teacher/notifications below

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function cap(str) {
    str = String(str || '');
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
  function timeAgo(iso) {
    if (!iso) return '\u2014';
    var then = new Date(iso).getTime();
    if (isNaN(then)) return '\u2014';
    var diff = Math.max(0, Date.now() - then);
    var mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + ' minute' + (mins === 1 ? '' : 's') + ' ago';
    var hours = Math.floor(mins / 60);
    if (hours < 24) return hours + ' hour' + (hours === 1 ? '' : 's') + ' ago';
    var days = Math.floor(hours / 24);
    if (days < 7) return days + ' day' + (days === 1 ? '' : 's') + ' ago';
    return new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  }
  function fmtWhen(iso) {
    var d = new Date(iso);
    if (isNaN(d)) return '';
    return d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  }

  var ICONS = {
    enrollment: '\u2611',   // ☑
    grade: '\u25A4',        // ▤
    section: '\u25A5',      // ▥
    schedule: '\u25A6',     // ▦
    announcement: '\u25A3', // ▣
    attendance: '\u25D1'    // ◑
  };

  function collect() {
    var items = [];

    // ---- Enrollment submitted (student: own · admin: everyone's) ----
    if (window.TCCEnrollments) {
      var enrollments = role === 'admin' ? window.TCCEnrollments.all()
        : role === 'student' ? window.TCCEnrollments.forStudent(myEmail)
        : [];
      enrollments.forEach(function (e) {
        var cls = e.status === 'approved' ? 'good' : e.status === 'rejected' ? 'bad' : 'warn';
        var who = role === 'admin' ? e.studentName + ' \u2014 ' : '';
        var units = e.totalUnits ? e.totalUnits + ' unit' + (e.totalUnits === 1 ? '' : 's') : (e.subjects || []).length + ' subject(s)';
        items.push({
          icon: ICONS.enrollment,
          title: 'Enrollment submitted',
          detail: who + (e.term || 'No term set') + ' \u00b7 ' + units,
          date: e.submittedAt,
          badgeLabel: cap(e.status),
          badgeClass: cls
        });
      });
    }

    // ---- Grade submitted (student: own · teacher: entered by them ·
    //      admin: everyone's) — GET /api/grades is already scoped for
    //      teacher/student, so all() below is already the right set. ----
    if (window.TCCGrades) {
      window.TCCGrades.all().forEach(function (r) {
        var cls = r.adminStatus === 'verified' ? 'good' : 'warn';
        var who = role !== 'student' ? r.studentName + ' \u2014 ' : '';
        items.push({
          icon: ICONS.grade,
          title: 'Grade submitted',
          detail: who + r.subject + (r.term ? ' (' + r.term + ')' : ''),
          date: r.enteredAt,
          badgeLabel: r.adminStatus === 'verified' ? 'Verified' : 'Pending review',
          badgeClass: cls
        });
      });
    }

    // ---- Section assigned (admin: every section it has sent · teacher:
    //      the notifications sections.js posts them, added async below) ----
    if (role === 'admin' && window.TCCSections) {
      window.TCCSections.all().filter(function (s) { return s.isSent && s.sentAt; }).forEach(function (s) {
        items.push({
          icon: ICONS.section,
          title: 'Section assigned',
          detail: s.sectionCode + ' \u2192 ' + (s.teacherName || 'Unassigned'),
          date: s.sentAt,
          badgeLabel: 'Sent',
          badgeClass: 'good'
        });
      });
    }
    if (role === 'teacher') {
      teacherSectionEvents.forEach(function (evt) { items.push(evt); });
    }

    // ---- Schedule updated (student: own section · teacher: own classes ·
    //      admin: everything) ----
    if (window.TCCSchedules) {
      var schedules = [];
      if (role === 'admin') schedules = window.TCCSchedules.all();
      else if (role === 'teacher') schedules = window.TCCSchedules.byTeacherName(myName);
      else if (role === 'student' && mySection) {
        var target = mySection.trim().toLowerCase();
        schedules = window.TCCSchedules.all().filter(function (s) {
          return String(s.section || '').trim().toLowerCase() === target;
        });
      }
      schedules.forEach(function (s) {
        var when = s.updatedAt || s.createdAt;
        if (!when) return;
        items.push({
          icon: ICONS.schedule,
          title: 'Schedule updated',
          detail: s.subject + ' \u00b7 ' + s.section + (s.room ? ' \u00b7 Rm ' + s.room : ''),
          date: when,
          badgeLabel: s.day || '\u2014',
          badgeClass: 'muted'
        });
      });
    }

    // ---- Announcement posted (student: audience-scoped feed · teacher:
    //      their own posts · admin: everything) ----
    if (window.TCCAnnouncements) {
      var announcements;
      if (role === 'admin') announcements = window.TCCAnnouncements.all();
      else if (role === 'teacher') {
        announcements = window.TCCAnnouncements.all().filter(function (a) {
          return String(a.postedByEmail || '').trim().toLowerCase() === myEmail;
        });
      } else {
        announcements = window.TCCAnnouncements.forAudience('student');
      }
      announcements.forEach(function (a) {
        items.push({
          icon: ICONS.announcement,
          title: 'Announcement posted',
          detail: a.title + (role === 'student' ? ' \u00b7 ' + a.postedByName : ''),
          date: a.postedAt,
          badgeLabel: cap(a.audience),
          badgeClass: 'muted'
        });
      });
    }

    // ---- Attendance recorded (student: own · teacher/admin: their
    //      students' / everyone's) ----
    if (window.TCCAttendance) {
      var attendance = role === 'student' ? window.TCCAttendance.forStudent(myEmail) : window.TCCAttendance.all();
      attendance.forEach(function (r) {
        var cls = r.status === 'Present' ? 'good' : r.status === 'Late' ? 'warn' : 'bad';
        var who = role !== 'student' ? r.studentName + ' \u2014 ' : '';
        items.push({
          icon: ICONS.attendance,
          title: 'Attendance recorded',
          detail: who + r.subject,
          date: r.recordedAt,
          badgeLabel: r.status,
          badgeClass: cls
        });
      });
    }

    render(items);
  }

  function render(items) {
    var sorted = items
      .filter(function (i) { return !!i.date; })
      .sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); })
      .slice(0, MAX_ITEMS);

    if (!sorted.length) {
      listEl.innerHTML = '';
      if (emptyEl) emptyEl.hidden = false;
      return;
    }
    if (emptyEl) emptyEl.hidden = true;
    listEl.innerHTML = sorted.map(function (i) {
      return '<div class="portal-row portal-row--activity">' +
        '<span class="activity-icon" aria-hidden="true">' + i.icon + '</span>' +
        '<div class="portal-row-main"><b>' + escapeHtml(i.title) + '</b><span>' + escapeHtml(i.detail) + '</span></div>' +
        '<div class="portal-row-meta" title="' + escapeHtml(fmtWhen(i.date)) + '">' +
          '<span class="badge badge--' + i.badgeClass + '">' + escapeHtml(i.badgeLabel) + '</span>' +
          '<span class="activity-when">' + escapeHtml(timeAgo(i.date)) + '</span>' +
        '</div>' +
        '</div>';
    }).join('');
  }

  // Re-collect whenever any source module's cache changes, and once each
  // one's initial load resolves (same wiring student-overview.js uses).
  ['TCCEnrollments', 'TCCGrades', 'TCCSections', 'TCCSchedules', 'TCCAnnouncements', 'TCCAttendance'].forEach(function (name) {
    if (window[name]) {
      window[name].onChange(collect);
      window[name].ready.then(collect);
    }
  });

  if (role === 'student' && api.getToken()) {
    api.get('/profiles/me').then(function (p) {
      mySection = p && p.section ? p.section : null;
      collect();
    }).catch(function () { /* no section on file — schedule events just won't match */ });
  }

  if (role === 'teacher' && api.getToken()) {
    api.get('/teacher/notifications').then(function (data) {
      teacherSectionEvents = (data.notifications || [])
        .filter(function (n) { return /^Section assigned:/.test(n.title || ''); })
        .map(function (n) {
          return {
            icon: ICONS.section,
            title: 'Section assigned',
            detail: n.title.replace(/^Section assigned:\s*/, ''),
            date: n.sentAt || n.createdAt,
            badgeLabel: 'Assigned',
            badgeClass: 'good'
          };
        });
      collect();
    }).catch(function () { /* notifications just won't include section-assigned events */ });
  }

  collect();
})();
