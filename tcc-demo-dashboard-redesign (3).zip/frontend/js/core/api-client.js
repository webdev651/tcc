/* =========================================================================
   Shared backend API client — thin fetch wrapper + JWT storage used by
   every js/modules/*.js data layer (profiles, grades, announcements,
   feedback, registrations, enrollments, schedules, attendance,
   notifications) and by js/core/accounts.js.

   One token is stored for whoever is currently signed in (student,
   teacher, or admin) — the backend scopes every response to that user's
   role automatically, so the frontend never needs to send role/email
   query params, just the bearer token.

   Load this before accounts.js and before any js/modules/*.js file.

   Used by:
   - js/core/accounts.js
   - js/modules/*.js (all nine Phase 2 data layers)
   ========================================================================= */
(function (global) {
  'use strict';

  // Point this at your deployed API in production. Defaults to the local
  // dev server started with `npm start` inside /backend.
  // Auto-detects the backend host from whatever host served this page, so
  // it works both on localhost (desktop dev) and over the LAN (phone/
  // another device hitting your PC's IP, e.g. 192.168.1.8:8000) without
  // any manual configuration. Override by setting window.TCC_API_BASE
  // before this script loads if the backend lives somewhere else entirely
  // (a different machine, a deployed URL, etc).
  //
  // BACKEND_PORT must match backend/.env's PORT (default 4000). This is a
  // static multi-page site with no build step, so there's no way to read
  // the backend's actual .env from here — if you change PORT on the
  // backend, update this one line to match (or set window.TCC_API_BASE
  // instead, which skips this entirely).
  var BACKEND_PORT = 4000;
  var API_BASE = global.TCC_API_BASE || (
    // file:// (opening an .html file directly by double-clicking it,
    // instead of via `npm run dev`) has no hostname, so the auto-detected
    // URL below would come out as "file://:4000/api" — silently breaking
    // every request. Fall back to the standard local dev address instead.
    global.location.protocol === 'file:'
      ? 'http://localhost:' + BACKEND_PORT + '/api'
      : global.location.protocol + '//' + global.location.hostname + ':' + BACKEND_PORT + '/api'
  );
  // One token is stored *per browser tab* (sessionStorage, not
  // localStorage) so that being signed in as admin in one tab and as a
  // teacher in another tab — e.g. testing both dashboards side by side —
  // doesn't clobber each other's login. localStorage is shared across
  // every tab of the same site, so it used to let a second-tab login
  // silently steal the first tab's session; sessionStorage is scoped to
  // one tab and matches how js/core/script.js already stores `tccSession`
  // (the display name/role cache) — see js/core/auth-guard.js, which
  // relies on both living in the same per-tab scope.
  var TOKEN_KEY = 'tcc-token';

  function getToken() {
    try { return global.sessionStorage ? global.sessionStorage.getItem(TOKEN_KEY) : null; }
    catch (e) { return null; }
  }
  function setToken(token) {
    try {
      if (!global.sessionStorage) return;
      if (token) global.sessionStorage.setItem(TOKEN_KEY, token);
      else global.sessionStorage.removeItem(TOKEN_KEY);
    } catch (e) { /* storage disabled — session just won't persist across reloads */ }
  }

  function authHeaders() {
    var headers = { 'Content-Type': 'application/json' };
    var token = getToken();
    if (token) headers['Authorization'] = 'Bearer ' + token;
    return headers;
  }

  function errorMessage(err) {
    return (err && err.message) || 'Something went wrong. Please try again.';
  }

  /* Thin fetch wrapper: JSON in, JSON out, rejects with a friendly message
     on non-2xx (or when the network request itself fails) so callers
     don't each need their own error parsing. */
  function request(path, options) {
    options = options || {};
    options.headers = Object.assign({}, authHeaders(), options.headers || {});
    return fetch(API_BASE + path, options)
      .catch(function () {
        var offline = new Error('Could not reach the server. Please try again.');
        offline.offline = true;
        throw offline;
      })
      .then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          if (!res.ok) {
            var err = new Error(data.message || 'Request failed.');
            err.status = res.status;
            err.data = data;
            throw err;
          }
          return data;
        });
      });
  }

  global.TCCApi = {
    API_BASE: API_BASE,
    getToken: getToken,
    setToken: setToken,
    errorMessage: errorMessage,
    get: function (path) { return request(path, { method: 'GET' }); },
    post: function (path, body) { return request(path, { method: 'POST', body: JSON.stringify(body || {}) }); },
    put: function (path, body) { return request(path, { method: 'PUT', body: JSON.stringify(body || {}) }); },
    del: function (path) { return request(path, { method: 'DELETE' }); }
  };
})(window);