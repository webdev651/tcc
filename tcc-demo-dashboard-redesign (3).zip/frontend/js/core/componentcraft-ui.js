/* ComponentCraft UI — ported interaction layer for the public pages
   (sticky header, mobile drawer, scroll reveal + stagger, count-up stats,
   background parallax, tilt/magnetic hover, scroll-to-top, footer year).
   Purely presentational: it never touches form/session logic — that
   stays in script.js / accounts.js. */
(function () {
  "use strict";

  // Custom eased scroll — more visible / consistent than the native
  // scrollIntoView("smooth"), which browsers render at very different
  // speeds. Respects prefers-reduced-motion (jumps instantly instead).
  function easeInOutCubic(t) {
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  }

  function smoothScrollTo(target) {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const headerOffset = parseFloat(getComputedStyle(target).scrollMarginTop) || 0;
    const startY = window.scrollY;
    const targetY = target.getBoundingClientRect().top + startY - headerOffset;
    const distance = targetY - startY;

    if (reduceMotion || Math.abs(distance) < 1) {
      window.scrollTo(0, targetY);
      return;
    }

    const duration = Math.min(1200, Math.max(500, Math.abs(distance) * 0.6));
    let startTime = null;

    function step(now) {
      if (startTime === null) startTime = now;
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      window.scrollTo(0, startY + distance * easeInOutCubic(progress));
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  // #page-fade plays a transform-based load animation with
  // animation-fill-mode:"both" so it holds its end keyframe forever.
  // Even though that end keyframe is transform:none, while the animation
  // is actively holding it the *computed* transform is an identity matrix,
  // not the literal keyword "none" — and any non-"none" transform makes
  // the element a containing block for position:fixed descendants. Since
  // #site-header lives inside #page-fade, that silently turned "fixed"
  // into "fixed relative to #page-fade", so the header scrolled away
  // instead of staying pinned to the viewport. Clearing the animation
  // once it finishes drops the computed transform back to a real "none".
  function initPageFadeCleanup() {
    const pf = document.getElementById("page-fade");
    if (!pf) return;
    pf.addEventListener(
      "animationend",
      () => {
        pf.style.animation = "none";
      },
      { once: true }
    );
  }

  function initHeader() {
    const header = document.getElementById("site-header");
    if (!header) return;
    const onScroll = () => header.classList.toggle("scrolled", window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    document.querySelectorAll('a[href^="#"]').forEach((link) => {
      link.addEventListener("click", (e) => {
        const id = link.getAttribute("href");
        if (id.length < 2) return;
        const target = document.querySelector(id);
        if (!target) return;
        e.preventDefault();
        closeMobileMenu();
        smoothScrollTo(target);
      });
    });
  }

  function openMobileMenu() {
    document.getElementById("mobile-menu-overlay")?.classList.add("open");
    document.getElementById("mobile-menu-open")?.setAttribute("aria-expanded", "true");
    document.body.style.overflow = "hidden";
    document.getElementById("mobile-menu-close")?.focus();
  }
  function closeMobileMenu() {
    document.getElementById("mobile-menu-overlay")?.classList.remove("open");
    document.getElementById("mobile-menu-open")?.setAttribute("aria-expanded", "false");
    document.body.style.overflow = "";
  }
  function initMobileMenu() {
    const openBtn = document.getElementById("mobile-menu-open");
    const closeBtn = document.getElementById("mobile-menu-close");
    const overlay = document.getElementById("mobile-menu-overlay");
    if (!openBtn || !overlay) return;
    openBtn.addEventListener("click", openMobileMenu);
    closeBtn?.addEventListener("click", closeMobileMenu);
    overlay.addEventListener("click", (e) => { if (e.target === overlay) closeMobileMenu(); });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && overlay.classList.contains("open")) closeMobileMenu();
    });
  }

  function initScrollReveal() {
    // Auto-stagger direct children of card grids that haven't been
    // hand-annotated with .reveal in the markup, so new cards added later
    // get the same entrance animation for free.
    document.querySelectorAll(
      ".about-grid, .features-grid, .college-info-grid, .contact-info-list"
    ).forEach((grid) => {
      Array.from(grid.children).forEach((child, i) => {
        if (!child.classList.contains("reveal")) {
          child.classList.add("reveal");
          child.setAttribute("data-delay", (Math.min(i, 6) * 0.08).toFixed(2));
        }
      });
    });

    const els = document.querySelectorAll(".reveal");
    if (!els.length) return;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const delay = entry.target.getAttribute("data-delay") || "0";
          entry.target.style.transitionDelay = `${delay}s`;
          entry.target.classList.add("in-view");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    els.forEach((el) => io.observe(el));
  }

  function initCountUp() {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const targets = document.querySelectorAll(".hero-stats b, .college-stat b");
    if (!targets.length) return;

    targets.forEach((el) => {
      const raw = el.textContent.trim();
      if (!/^\d+$/.test(raw)) return; // leave non-numeric stats ("Free", "Public") alone
      const target = parseInt(raw, 10);
      if (reduceMotion) return; // final value is already correct in the markup

      el.textContent = "0";
      let started = false;
      const io = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !started) {
            started = true;
            io.unobserve(entry.target);
            const duration = 900;
            const start = performance.now();
            function tick(now) {
              const p = Math.min((now - start) / duration, 1);
              const eased = 1 - Math.pow(1 - p, 3); // ease-out-cubic
              el.textContent = Math.round(target * eased).toString();
              if (p < 1) requestAnimationFrame(tick);
              else el.textContent = target.toString();
            }
            requestAnimationFrame(tick);
          }
        });
      }, { threshold: 0.4 });
      io.observe(el);
    });
  }

  function initParallaxBg() {
    // Parallax shift disabled: it translated the fixed liquid-bg down as
    // the page scrolled, which revealed the near-black tail end of its
    // radial gradient and made the page look progressively darker the
    // further you scrolled. The background now stays fixed in place.
  }

  function initHeroScrollCue() {
    const cue = document.getElementById("hero-scroll-cue");
    if (!cue) return;
    const toggle = () => cue.classList.toggle("faded", window.scrollY > 80);
    toggle();
    window.addEventListener("scroll", toggle, { passive: true });
  }

  function initMagneticButtons() {
    // The "magnetic" cursor-follow effect was removed — it made the
    // sign-in/submit buttons visibly drift and shift position as the
    // mouse approached, which made them fiddly to click. The button now
    // stays fixed in place at all times. Press feedback is handled purely
    // by the CSS ".uc-btn:active" rule (00-componentcraft.css), which has
    // its own smooth transition — no JS transform here, so there's
    // nothing to fight or snap abruptly.
  }

  function initTiltCards() {
    if (window.matchMedia("(pointer: coarse)").matches) return;
    document.querySelectorAll(".tilt-card").forEach((card) => {
      card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;
        card.style.transform = `perspective(800px) rotateY(${x * 5}deg) rotateX(${-y * 5}deg) translateY(-3px)`;
      });
      card.addEventListener("mouseleave", () => (card.style.transform = ""));
    });
  }

  function initScrollTop() {
    const btn = document.getElementById("scroll-top-btn");
    if (!btn) return;
    const toggle = () => btn.classList.toggle("visible", window.scrollY > 500);
    toggle();
    window.addEventListener("scroll", toggle, { passive: true });
    btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  }

  function initFooterYear() {
    const el = document.getElementById("footer-year");
    if (el) el.textContent = new Date().getFullYear();
  }

  // Press ripple — a small circle expanding from the exact click point
  // on any .uc-btn, cleaned up after its animation finishes. Respects
  // reduced-motion by simply not spawning the element (CSS also hides
  // it as a belt-and-braces fallback for injected buttons).
  function initButtonRipple() {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    document.addEventListener("pointerdown", (e) => {
      const btn = e.target.closest(".uc-btn");
      if (!btn || btn.disabled) return;
      const rect = btn.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height) * 1.1;
      const ripple = document.createElement("span");
      ripple.className = "btn-ripple";
      ripple.style.width = ripple.style.height = `${size}px`;
      ripple.style.left = `${(e.clientX ?? rect.left + rect.width / 2) - rect.left - size / 2}px`;
      ripple.style.top = `${(e.clientY ?? rect.top + rect.height / 2) - rect.top - size / 2}px`;
      btn.appendChild(ripple);
      ripple.addEventListener("animationend", () => ripple.remove());
    });
  }

  // Scroll-spy — highlights the nav link for whichever section is
  // currently in view, sliding the underline to it automatically
  // instead of only showing on hover.
  function initScrollSpy() {
    const sections = Array.from(document.querySelectorAll("main section[id]"));
    const navLinks = Array.from(document.querySelectorAll(".nav-link, .mobile-panel-link"));
    if (!sections.length || !navLinks.length) return;

    const linkFor = (id) =>
      navLinks.filter((l) => l.getAttribute("href") === `#${id}`);

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const id = entry.target.id;
          const links = linkFor(id);
          if (!links.length) return;
          if (entry.isIntersecting) {
            navLinks.forEach((l) => l.classList.remove("active"));
            links.forEach((l) => l.classList.add("active"));
          }
        });
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 }
    );
    sections.forEach((s) => io.observe(s));
  }

  // Hero headline typewriter — cycles the last word of "One portal for
  // the ___" through student/teacher/admin. Classic typewriter effect:
  // each character appears instantly, one after another, then holds,
  // then backspaces one character at a time before the next word types
  // in. Falls back to the static first word for reduced-motion users
  // (no typing/deleting motion involved).
  function initHeroTypewriter() {
    const el = document.getElementById("hero-typewriter");
    if (!el) return;
    const words = (el.getAttribute("data-words") || "")
      .split(",")
      .map((w) => w.trim())
      .filter(Boolean);
    if (words.length < 2) return;

    // Reduced-motion: still cycle the words (that's the actual content,
    // not decoration), just swap instantly on a timer instead of
    // typing/deleting one character at a time.
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      let i = 0;
      el.textContent = words[0];
      setInterval(() => {
        i = (i + 1) % words.length;
        el.textContent = words[i];
      }, 2200);
      return;
    }

    const TYPE_MS = 90; // delay between each character typed
    const DELETE_MS = 45; // delay between each character deleted (faster)
    const HOLD_MS = 1300; // pause once a word is fully typed
    let wordIndex = 0;

    // Setting textContent to a real empty string ("") between words made
    // the browser compute a shorter line-box height for the empty inline
    // element than the height it has once it holds text — a couple px
    // shorter (the height : normal empty-box metrics undershoot the
    // custom line-height). That momentary shrink, twice per word cycle
    // (fully deleted, then first char retyped), pushed the paragraph and
    // stats below it up and back down — the "jump". Writing a non-
    // breaking space instead of "" keeps the element non-empty at all
    // times, so its line-box height never collapses.
    function setText(str) {
      el.textContent = str.length ? str : "\u00A0";
    }

    function typeWord(word, i, done) {
      setText(word.slice(0, i));
      if (i < word.length) {
        setTimeout(() => typeWord(word, i + 1, done), TYPE_MS);
      } else {
        setTimeout(done, HOLD_MS);
      }
    }

    function deleteWord(word, i, done) {
      setText(word.slice(0, i));
      if (i > 0) {
        setTimeout(() => deleteWord(word, i - 1, done), DELETE_MS);
      } else {
        done();
      }
    }

    function cycle() {
      const word = words[wordIndex];
      typeWord(word, 0, () => {
        deleteWord(word, word.length, () => {
          wordIndex = (wordIndex + 1) % words.length;
          cycle();
        });
      });
    }

    el.classList.add("typewriter-active");
    setText("");
    setTimeout(cycle, 400);
  }

  function init() {
    [
      initPageFadeCleanup,
      initHeader,
      initMobileMenu,
      initScrollReveal,
      initCountUp,
      initParallaxBg,
      initHeroScrollCue,
      initMagneticButtons,
      initTiltCards,
      initScrollTop,
      initFooterYear,
      initButtonRipple,
      initScrollSpy,
      initHeroTypewriter,
    ].forEach((fn) => {
      try {
        fn();
      } catch (err) {
        console.error(`[componentcraft-ui] ${fn.name} failed:`, err);
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
