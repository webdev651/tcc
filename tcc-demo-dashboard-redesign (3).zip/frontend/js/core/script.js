/* Login page behaviour — no framework.
   Replace the fake auth call in `signInWithPassword` with a real request
   to your backend. */
(function () {
  // ---- Animated background -------------------------------------------------
  const canvas = document.getElementById('darkveil');
  if (canvas && window.initDarkVeil) {
    window.initDarkVeil(canvas, {
      // Dashboards set data-hue-shift="…" on the canvas to swing this
      // ambient veil off the login page's brand green without touching
      // this shared init (still used by the login page itself, where the
      // attribute is absent and the green default below applies as before).
      hueShift: canvas.dataset.hueShift ? parseFloat(canvas.dataset.hueShift) : 140, // brand green
      noiseIntensity: 0,
      scanlineIntensity: 0,
      speed: 0.4,
      scanlineFrequency: 0,
      warpAmount: 0,
      resolutionScale: 1
    });
  }

  // ---- Toasts --------------------------------------------------------------
  const toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    const el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }

  // ---- Real auth layer (backend: /api/auth/login, see /backend) -----------
  function signInWithPassword(email, password) {
    if (!email || !password) {
      return Promise.resolve({ error: { message: 'Email and password are required' } });
    }
    if (!window.TCCAccounts) {
      return Promise.resolve({ error: { message: 'Auth service unavailable — please reload the page.' } });
    }
    // Real credential check against the backend (bcrypt-hashed password,
    // pending/rejected status gate). See js/core/accounts.js.
    return window.TCCAccounts.login(email, password);
  }

  // No backend/session yet, so the dashboards can't look a signed-in person
  // up on their own — the name (and role/detail, when known) is captured
  // here at sign-in time and handed off via sessionStorage so
  // student-dashboard.html / teacher-dashboard.html can greet the actual
  // person instead of the built-in placeholder name.
  const SESSION_KEY = 'tccSession';
  function deriveNameFromEmail(email) {
    const local = String(email || '').split('@')[0] || '';
    const words = local.replace(/[._-]+/g, ' ').trim().split(/\s+/).filter(Boolean);
    if (!words.length) return 'there';
    return words.map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  }
  function saveSession(email, role, name, detail) {
    try {
      sessionStorage.setItem(SESSION_KEY, JSON.stringify({
        email: email,
        role: role,
        name: name || deriveNameFromEmail(email),
        detail: detail || ''
      }));
    } catch (e) { /* sessionStorage unavailable — dashboards fall back to their placeholder */ }
  }

  // ---- Email + password form ----------------------------------------------
  // (guarded with `if (form)` so this file can be shared by pages — like the
  // Home page — that don't include the login form; behaviour on the actual
  // login pages is unchanged)
  const form = document.getElementById('login-form');
  const submitBtn = document.getElementById('submit-btn');
  const submitLabel = submitBtn ? submitBtn.querySelector('.label') : null;

  if (form && submitBtn && submitLabel) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (submitBtn.disabled) return;
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;

      submitBtn.disabled = true;
      submitLabel.textContent = 'Signing in…';

      const { error, role: accountRole, name: accountName, detail: accountDetail, token } = await signInWithPassword(email, password);

      submitBtn.disabled = false;
      submitLabel.textContent = 'Sign in';

      if (error) {
        toast(error.message, 'error');
        return;
      }

      // Two ways a login form can say where to send someone after sign-in:
      // - data-dashboard="some.html" sends everyone there (admin/index.html
      //   uses this — only an account whose real role (from the backend)
      //   is 'admin' is let through).
      // - data-auto-role="true" sends students/teachers to their dashboard,
      //   using the real role the backend returned.
      if (form.dataset.dashboard) {
        if (accountRole !== 'admin') {
          toast('This account is not an admin account.', 'error');
          return;
        }
        // Persists the JWT (js/core/api-client.js) so every js/modules/*.js
        // data-layer call on the admin dashboard is authenticated.
        if (window.TCCApi) window.TCCApi.setToken(token);
        toast('Signed in — redirecting…', 'success');
        saveSession(email, accountRole, accountName, accountDetail);
        setTimeout(() => { window.location.href = form.dataset.dashboard; }, 900);
      } else if (form.dataset.autoRole === 'true') {
        const role = accountRole === 'teacher' ? 'teacher' : 'student';
        const DASHBOARDS = { student: 'student-dashboard.html', teacher: 'teacher-dashboard.html' };
        // Same JWT persistence as above, for the student/teacher dashboards.
        if (window.TCCApi) window.TCCApi.setToken(token);
        toast('Signed in — redirecting…', 'success');
        saveSession(email, role, accountName, accountDetail);
        setTimeout(() => { window.location.href = DASHBOARDS[role]; }, 900);
      }
    });
  }

})();

/* =========================================================================
   MODULE 1 & 2 additions — Home page nav, contact form, forgot/change
   password (UI only), logout confirmation, dashboard redirect above.
   ========================================================================= */
(function () {
  const toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    const el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }

  // ---- Responsive nav toggle (Home page) -----------------------------------
  // Superseded by the mobile-menu-open/mobile-menu-panel drawer handled in
  // componentcraft-ui.js's initMobileMenu(); the old navbar-toggle/navbar-links
  // markup this used to target no longer exists on the page.

  // ---- Contact form (Home page) --------------------------------------------
  // No backend endpoint exists for this form, so rather than pretending to
  // "send" and silently discarding the message, open the visitor's mail
  // client with a pre-filled message to the college's published address.
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    const btn = document.getElementById('contact-submit');
    const label = btn.querySelector('.label');
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (btn.disabled) return;
      const name = contactForm.elements['name'].value.trim();
      const email = contactForm.elements['email'].value.trim();
      const message = contactForm.elements['message'].value.trim();
      if (!name || !email || !message) {
        toast('Please fill in every field before sending', 'error');
        return;
      }
      btn.disabled = true;
      label.textContent = 'Opening mail app…';
      const subject = encodeURIComponent(`Website inquiry from ${name}`);
      const body = encodeURIComponent(`${message}\n\n— ${name} (${email})`);
      window.location.href = `mailto:tcc_04@yahoo.com.ph?subject=${subject}&body=${body}`;
      setTimeout(() => {
        btn.disabled = false;
        label.textContent = 'Send message';
        toast("Your mail app should now have this message ready to send", 'success');
      }, 500);
    });
  }

  // ---- Sign up (student/teacher account request) ---------------------------
  // Creates a "pending" account request via accounts.js. It can't be used to
  // sign in until an admin approves it from admin/dashboard.html → Approvals.
  const signupForm = document.getElementById('signup-form');
  if (signupForm) {
    const btn = document.getElementById('submit-btn');
    const label = btn.querySelector('.label');
    const pendingPanel = document.getElementById('signup-pending');
    const roleFields = signupForm.querySelectorAll('[data-role-field]');

    function syncRoleFields() {
      const role = signupForm.querySelector('input[name="role"]:checked').value;
      roleFields.forEach((field) => {
        const match = field.dataset.roleField === role;
        field.hidden = !match;
        field.querySelectorAll('select').forEach((sel) => { sel.disabled = !match; });
      });
    }
    signupForm.querySelectorAll('input[name="role"]').forEach((input) => {
      input.addEventListener('change', syncRoleFields);
    });
    syncRoleFields();

    signupForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (btn.disabled || !window.TCCAccounts) return;

      const role = signupForm.querySelector('input[name="role"]:checked').value;
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirm-password').value;
      const detailField = signupForm.querySelector(`[data-role-field="${role}"] select`);
      const detail = detailField ? detailField.value : '';
      // Students only — teachers never have a Student ID Number.
      const studentIdField = document.getElementById('student-id');
      const studentId = role === 'student' && studentIdField ? studentIdField.value.trim().toUpperCase() : '';
      const studentIdPattern = /^[A-Z0-9-]{4,20}$/;

      if (!name || !email || !password || !confirmPassword) { toast('Fill in every field', 'error'); return; }
      if (role === 'student' && !studentId) { toast('Student ID Number is required', 'error'); return; }
      if (role === 'student' && !studentIdPattern.test(studentId)) {
        toast('Student ID Number must be 4–20 characters: letters, numbers, and hyphens only', 'error');
        return;
      }
      if (password.length < 6) { toast('Password must be at least 6 characters', 'error'); return; }
      if (password !== confirmPassword) { toast('Passwords don\u2019t match', 'error'); return; }

      btn.disabled = true;
      label.textContent = 'Submitting…';

      window.TCCAccounts.createRequest({ name, email, password, role, detail, studentId }).then(({ error, warning, downloaded }) => {
        btn.disabled = false;
        label.textContent = 'Request account';

        if (error) {
          toast(error, 'error');
          return;
        }

        if (warning) {
          toast(`Account request submitted, but ${warning}`, 'warn');
        } else if (downloaded) {
          toast('Account request submitted — a tcc-accounts.json backup just downloaded', 'success');
        } else {
          toast('Account request submitted', 'success');
        }
        signupForm.hidden = true;
        if (pendingPanel) pendingPanel.hidden = false;
      });
    });
  }

  // ---- Forgot password (UI only) --------------------------------------------
  const forgotForm = document.getElementById('forgot-form');
  if (forgotForm) {
    const btn = document.getElementById('submit-btn');
    const label = btn.querySelector('.label');
    forgotForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (btn.disabled) return;
      const email = document.getElementById('email').value.trim();
      if (!email) { toast('Enter your email first', 'error'); return; }
      btn.disabled = true;
      label.textContent = 'Sending…';
      setTimeout(() => {
        btn.disabled = false;
        label.textContent = 'Send reset link';
        toast('Reset link sent — check your inbox', 'success');
      }, 700);
    });
  }

  // ---- Change password (UI only) --------------------------------------------
  const changeForm = document.getElementById('change-form');
  if (changeForm) {
    const btn = document.getElementById('submit-btn');
    const label = btn.querySelector('.label');
    const newPw = document.getElementById('new-password');
    const bars = document.querySelectorAll('.pw-hint i');

    if (newPw && bars.length) {
      newPw.addEventListener('input', () => {
        const v = newPw.value;
        let score = 0;
        if (v.length >= 8) score++;
        if (/[A-Z]/.test(v)) score++;
        if (/[0-9]/.test(v)) score++;
        if (/[^A-Za-z0-9]/.test(v)) score++;
        bars.forEach((bar, i) => bar.classList.toggle('on', i < score));
      });
    }

    changeForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (btn.disabled) return;
      const current = document.getElementById('current-password').value;
      const next = newPw.value;
      const confirm = document.getElementById('confirm-password').value;
      if (!current || !next || !confirm) { toast('Fill in every field', 'error'); return; }
      if (next.length < 6) { toast('New password must be at least 6 characters', 'error'); return; }
      if (next !== confirm) { toast('New passwords don\u2019t match', 'error'); return; }

      btn.disabled = true;
      label.textContent = 'Updating…';
      setTimeout(() => {
        btn.disabled = false;
        label.textContent = 'Update password';
        changeForm.reset();
        bars.forEach((bar) => bar.classList.remove('on'));
        toast('Password updated', 'success');
      }, 700);
    });
  }

  // ---- Direct "Log out" links (sidebar / footer — skip the confirm page) ----
  // These navigate straight to index.html, so the session has to be cleared
  // here rather than in the logout.html confirm-page handler below.
  document.addEventListener('click', (e) => {
    const link = e.target.closest && e.target.closest('[data-tcc-logout]');
    if (!link) return;
    try { sessionStorage.removeItem('tccSession'); } catch (err) { /* no-op */ }
    if (window.TCCApi) window.TCCApi.setToken(null);
  });

  // ---- Logout confirmation (UI only) -----------------------------------------
  const logoutBtn = document.getElementById('logout-btn');
  const cancelBtn = document.getElementById('cancel-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      const label = logoutBtn.querySelector('.label');
      logoutBtn.disabled = true;
      if (label) label.textContent = 'Logging out…';
      setTimeout(() => {
        try { sessionStorage.removeItem('tccSession'); } catch (e) { /* no-op */ }
        if (window.TCCApi) window.TCCApi.setToken(null);
        toast('Signed out', 'success');
        window.location.href = 'index.html';
      }, 600);
    });
  }
  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      if (window.history.length > 1) window.history.back();
      else window.location.href = 'index.html';
    });
  }
})();
