/* =========================================================================
   Account requests — student & teacher sign-up, pending admin approval.

   Backend integration: talks to a real Node.js + Express + MySQL API (see
   /backend) instead of localStorage / File System Access. Passwords are
   hashed server-side (bcrypt) and never touch this file.

   Data model (one object per request, same shape the rest of the app
   already expects):
   {
     id, name, email, role: 'student' | 'teacher',
     detail:      program (students) or department (teachers),
     status:      'pending' | 'approved' | 'rejected',
     requestedAt, decidedAt
   }

   Public interface is unchanged from the old localStorage version, so
   nothing else (script.js, admin-approvals.js) needed to change its
   calling convention — `all()` / `pending()` / `findByEmail()` stay
   synchronous reads of a local cache; `createRequest()` / `approve()` /
   `reject()` stay Promise-returning. One addition: `login()`, used by
   script.js to authenticate against the real backend for every role.

   The local cache (`requests`) is only populated for a signed-in admin
   (GET /api/admin/requests requires an admin JWT) — on login.html /
   signup.html it just stays empty, which is fine since those pages only
   call createRequest()/login().

   The session token itself (used by every js/modules/*.js file too, not
   just this one) is stored and read through js/core/api-client.js —
   requires that file to be loaded first.

   Used by:
   - signup.html          → createRequest()
   - login.html            → login() (via script.js's signInWithPassword)
   - admin/index.html      → login()
   - admin/dashboard.html → pending() / all() / approve() / reject()
   ========================================================================= */
(function (global) {
  'use strict';

  if (!global.TCCApi) { console.error('accounts.js requires js/core/api-client.js to be loaded first.'); return; }
  var api = global.TCCApi;

  var requests = [];    // in-memory cache of account requests (admin only)
  var listeners = [];
  // Tracks the *last* refresh() outcome so the UI can tell apart three
  // different "the table looks empty" causes that used to all render
  // identically:
  //   null  = no attempt yet (or no token, so nothing to attempt)
  //   true  = last attempt reached the server and was authorized
  //   false = last attempt failed to even reach/complete against the
  //           server (offline, wrong port, 5xx, etc.)
  // authError is set separately (see below) for the case where the
  // server WAS reached but rejected the request as unauthorized (401/403)
  // — e.g. signed in as a non-admin role, most commonly because a
  // different role was logged into in another tab. Not the same thing as
  // "can't reach the backend" and shouldn't be reported as such.
  var backendReachable = null;
  var authError = false;
  var lastError = null;

  function status() {
    return { connected: !!api.getToken(), backendReachable: backendReachable, authError: authError, error: lastError, count: requests.length };
  }

  function notify() {
    var s = status();
    listeners.forEach(function (fn) { try { fn(s); } catch (e) { /* ignore listener errors */ } });
    try { global.dispatchEvent(new CustomEvent('tcc-accounts:changed', { detail: s })); } catch (e) { /* no-op */ }
    return s;
  }

  /* ---- Data helpers ---- */
  function normalizeEmail(email) { return String(email || '').trim().toLowerCase(); }

  function findByEmail(email) {
    var target = normalizeEmail(email);
    if (!target) return null;
    var match = requests.filter(function (a) { return a.email === target; });
    return match.length ? match[match.length - 1] : null;
  }
  function all() {
    return requests.slice().sort(function (a, b) { return (b.requestedAt || '').localeCompare(a.requestedAt || ''); });
  }
  function pending() {
    return all().filter(function (a) { return a.status === 'pending'; });
  }

  /* Populates the local cache from the backend. Only succeeds when a
     signed-in admin's token is present — silently no-ops (empty cache)
     otherwise, which is correct on login.html/signup.html. */
  function refresh() {
    if (!api.getToken()) { requests = []; backendReachable = null; authError = false; lastError = null; notify(); return Promise.resolve(requests); }
    return api.get('/admin/requests')
      .then(function (data) {
        requests = data.requests || [];
        backendReachable = true;
        authError = false;
        lastError = null;
        notify();
        return requests;
      })
      .catch(function (err) {
        requests = [];
        // 401/403 means the server was reached fine, just rejected this
        // token — different problem (and different fix) than a genuine
        // connection failure, so keep it out of backendReachable.
        var isAuthError = err && (err.status === 401 || err.status === 403);
        backendReachable = isAuthError ? true : false;
        authError = !!isAuthError;
        lastError = api.errorMessage(err);
        notify();
        return requests;
      });
  }

  function createRequest(data) {
    var payload = {
      name: String(data.name || '').trim(),
      email: normalizeEmail(data.email),
      password: data.password,
      role: data.role === 'teacher' ? 'teacher' : 'student',
      detail: String(data.detail || '').trim(),
      // Students only — teachers never have a Student ID Number. Normalized
      // (trimmed, upper-cased) to match the backend's canonical form.
      studentId: data.role === 'teacher' ? '' : String(data.studentId || '').trim().toUpperCase()
    };
    if (!payload.name || !payload.email || !payload.password) {
      return Promise.resolve({ error: 'Fill in every field.' });
    }
    if (payload.role === 'student' && !payload.studentId) {
      return Promise.resolve({ error: 'Student ID Number is required.' });
    }
    if (payload.password.length < 6) {
      return Promise.resolve({ error: 'Password must be at least 6 characters.' });
    }
    return api.post('/auth/signup', payload)
      .then(function (data) { return { account: data.request }; })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  /* Real credential check against the backend. Returns the same shape
     script.js's old fake `signInWithPassword` returned, plus `token`.
     Works for every role — script.js is responsible for persisting the
     returned token via api.setToken() once it decides where to send the
     person. */
  function login(email, password) {
    return api.post('/auth/login', { email: normalizeEmail(email), password: password })
      .then(function (data) {
        return { error: null, role: data.role, name: data.name, detail: data.detail, token: data.token };
      })
      .catch(function (err) {
        return { error: { message: api.errorMessage(err) } };
      });
  }

  /* Admin-only: replaces a user's password with one the admin typed in
     (never stored here beyond this call, never re-fetchable afterwards).
     See js/admin/admin-approvals.js for the inline form that collects it. */
  function resetPassword(id, newPassword) {
    return api.post('/admin/users/' + id + '/reset-password', { newPassword: newPassword })
      .then(function (data) {
        return { name: data.name, email: data.email, newPassword: data.newPassword };
      })
      .catch(function (err) { return { error: api.errorMessage(err) }; });
  }

  function setStatus(id, action) {
    return api.post('/admin/requests/' + id + '/' + action, {})
      .then(function (data) {
        var updated = data.request;
        var found = false;
        requests = requests.map(function (r) {
          if (r.id === updated.id) { found = true; return updated; }
          return r;
        });
        if (!found) requests.push(updated);
        notify();
        return updated;
      })
      .catch(function () { return null; });
  }

  var ready = refresh();

  global.TCCAccounts = {
    ready: ready,
    all: all,
    pending: pending,
    findByEmail: findByEmail,
    createRequest: createRequest,
    login: login,
    approve: function (id) { return setStatus(id, 'approve'); },
    reject: function (id) { return setStatus(id, 'reject'); },
    resetPassword: resetPassword,
    // Kept as aliases for the shared session token — used for any signed-in
    // role, not just admin, despite the name (unchanged so nothing else
    // calling these two needs to change).
    setAdminToken: function (token) { api.setToken(token); refresh(); },
    getAdminToken: function () { return api.getToken(); },
    getStatus: status,
    onChange: function (fn) { listeners.push(fn); },
    refresh: refresh
  };

  /* =======================================================================
     Small status widget — progressive enhancement, admin dashboard only.
     Reports backend connectivity. Stays hidden on login.html/signup.html
     (no #approvalsBody there), same as it was hidden by default before
     any JS ran.
     ======================================================================= */
  function renderWidget(el) {
    var s = status();
    var pieces = [];
    var ok = s.connected && s.backendReachable !== false && !s.authError;
    pieces.push('<span class="file-status-dot' + (ok ? ' is-on' : '') + '" aria-hidden="true"></span>');
    var text;
    if (!s.connected) {
      text = 'Not connected — sign in again if requests aren\u2019t loading.';
    } else if (s.authError) {
      text = 'Signed in, but not authorized as admin in this tab — log out and sign back in as admin.';
    } else if (s.backendReachable === false) {
      text = 'Can\u2019t reach the backend server' + (s.error ? ' (' + s.error + ')' : '') + ' — make sure it\u2019s running.';
    } else {
      text = 'Connected to the backend API (' + s.count + ' request' + (s.count === 1 ? '' : 's') + ')';
    }
    pieces.push('<span class="file-status-text">' + text + '</span>');
    el.innerHTML = pieces.join('');
  }

  function initWidgets() {
    var widgets = document.querySelectorAll('[data-tcc-file-status]');
    if (!widgets.length) return;
    // Only meaningful on the admin dashboard (only page with real requests
    // to report on); leave it hidden everywhere else.
    if (!document.getElementById('approvalsBody')) return;

    widgets.forEach(function (el) { el.hidden = false; renderWidget(el); });
    global.TCCAccounts.onChange(function () { widgets.forEach(renderWidget); });
    ready.then(function () { widgets.forEach(renderWidget); });
  }

  /* =======================================================================
     Live updates for the Approvals tab — new sign-ups happen from a
     different tab/device (signup.html hitting the backend directly), so
     the admin's in-memory `requests` cache has no way to know about them
     on its own. The regular interval poll lives in js/core/live-poll.js
     (calls refresh() on every TCCXxx module, this one included); this part
     just fires an *immediate* refresh the moment the tab regains focus or
     visibility, so switching back doesn't sit waiting for the next tick.
     ======================================================================= */
  function initLiveUpdates() {
    if (!document.getElementById('approvalsBody')) return;
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'visible') refresh();
    });
    global.addEventListener('focus', function () { refresh(); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initWidgets);
    document.addEventListener('DOMContentLoaded', initLiveUpdates);
  } else {
    initWidgets();
    initLiveUpdates();
  }
})(window);
