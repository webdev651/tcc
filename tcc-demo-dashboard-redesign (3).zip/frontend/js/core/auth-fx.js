/* =========================================================================
   AUTH FX — progressive-enhancement animation for the .modern-auth pages
   (login.html, signup.html, admin/index.html).

   Everything here is additive and defensive: if an element isn't on the
   page, the relevant bit just no-ops. None of this touches form
   submission, validation, or auth logic — that stays in script.js.

   Respects prefers-reduced-motion (skips pointer-driven motion entirely)
   and only wires pointer/tilt effects on fine-pointer (mouse) devices.
   ========================================================================= */
(function () {
  'use strict';

  var root = document.querySelector('.modern-auth');
  if (!root) return;

  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer = window.matchMedia && window.matchMedia('(pointer: fine)').matches;

  root.classList.add('is-live');

  // ---- Shell entrance handoff -----------------------------------------
  // The glow no longer follows the cursor (--mx/--my stay fixed at their
  // CSS defaults) and the card no longer tilts toward the pointer. We
  // still need to hand the shell's `transform` over from the entrance
  // keyframe (held via fill:forwards) to plain CSS once it finishes, so
  // nothing else that touches shell.style.transform later gets fought by
  // a lingering animation.
  if (!reduceMotion && finePointer) {
    var shell = root.querySelector('.modern-auth-shell');
    if (shell) {
      shell.addEventListener('animationend', function onEnd(e) {
        if (e.target !== shell || e.animationName !== 'modernAuthIn') return;
        shell.style.animation = 'none';
        shell.style.opacity = '1';
        shell.style.filter = 'none';
        shell.classList.add('is-settled');
        shell.removeEventListener('animationend', onEnd);
      });
    }
  }

  // ---- Submit button: ripple + loading spinner ------------------------------
  var buttons = root.querySelectorAll('.modern-auth-submit');
  buttons.forEach(function (btn) {
    var spinner = document.createElement('span');
    spinner.className = 'btn-spinner';
    spinner.setAttribute('aria-hidden', 'true');
    btn.appendChild(spinner);

    var ripple = document.createElement('span');
    ripple.className = 'btn-ripple';
    ripple.setAttribute('aria-hidden', 'true');
    btn.appendChild(ripple);

    btn.addEventListener('click', function (e) {
      if (btn.disabled) return;
      var rect = btn.getBoundingClientRect();
      var x = (e.clientX != null ? e.clientX - rect.left : rect.width / 2);
      var y = (e.clientY != null ? e.clientY - rect.top : rect.height / 2);
      btn.style.setProperty('--rx', x + 'px');
      btn.style.setProperty('--ry', y + 'px');
      ripple.classList.remove('is-active');
      // Force reflow so re-adding the class restarts the animation on
      // repeated clicks (e.g. after a validation error).
      void ripple.offsetWidth;
      ripple.classList.add('is-active');
    });
  });

  // ---- Shake the card on a failed submit ------------------------------------
  var toastRoot = document.getElementById('toast-root');
  if (toastRoot && !reduceMotion) {
    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        m.addedNodes.forEach(function (node) {
          if (node.nodeType === 1 && node.classList && node.classList.contains('toast--error')) {
            var target = root.querySelector('.modern-auth-shell');
            if (!target) return;
            target.style.animation = 'modernAuthShake .45s ease';
            var onShakeEnd = function (e) {
              if (e.animationName !== 'modernAuthShake') return;
              target.style.animation = 'none';
              target.removeEventListener('animationend', onShakeEnd);
            };
            target.addEventListener('animationend', onShakeEnd);
          }
        });
      });
    });
    observer.observe(toastRoot, { childList: true });
  }
})();
