/* =========================================================================
   Admin — Section Management (admin/dashboard.html only). Create/edit/
   delete sections via js/modules/sections.js, assign a teacher from the
   approved teacher accounts (js/core/accounts.js), and manage each
   section's student roster (add/remove from approved student accounts).
   Guarded by element presence, same convention as the rest of the
   admin-*.js files.
   ========================================================================= */
(function () {
  if (!window.TCCSections || !window.TCCAccounts) return;

  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  // Same convention as admin-notifications.js's fmtDateTime().
  function fmtDateTime(iso) {
    if (!iso) return '';
    var d = new Date(String(iso).replace(' ', 'T'));
    if (isNaN(d.getTime())) return '';
    return d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  }

  var form = document.getElementById('sectionForm');
  if (!form) return;

  var editIdInput = document.getElementById('secEditId');
  var formTitle = document.getElementById('sectionFormTitle');
  var submitBtn = document.getElementById('secSubmitBtn');
  var cancelBtn = document.getElementById('secCancelEdit');
  var teacherSelect = document.getElementById('secTeacher');
  var body = document.getElementById('sectionsBody');
  var empty = document.getElementById('sectionsEmpty');

  var fieldIds = { sectionCode: 'secName', program: 'secProgram', yearLevel: 'secYear', term: 'secTerm' };
  function fieldEl(key) { return document.getElementById(fieldIds[key]); }

  function approvedTeachers() {
    return window.TCCAccounts.all().filter(function (a) { return a.role === 'teacher' && a.status === 'approved'; });
  }
  function approvedStudents() {
    return window.TCCAccounts.all().filter(function (a) { return a.role === 'student' && a.status === 'approved'; });
  }

  function renderTeacherSelect() {
    if (!teacherSelect) return;
    var cur = teacherSelect.value;
    teacherSelect.innerHTML = '<option value="">No teacher assigned</option>' +
      approvedTeachers().map(function (t) {
        return '<option value="' + t.id + '">' + escapeHtml(t.name) + ' \u2014 ' + escapeHtml(t.email) + '</option>';
      }).join('');
    teacherSelect.value = cur;
  }

  function resetForm() {
    form.reset();
    editIdInput.value = '';
    formTitle.textContent = 'Create a section';
    submitBtn.textContent = 'Create section';
    cancelBtn.hidden = true;
    if (teacherSelect) teacherSelect.value = '';
  }

  function startEdit(id) {
    var record = window.TCCSections.all().filter(function (s) { return String(s.id) === String(id); })[0];
    if (!record) return;
    editIdInput.value = id;
    Object.keys(fieldIds).forEach(function (key) { var el = fieldEl(key); if (el) el.value = record[key] || ''; });
    if (teacherSelect) teacherSelect.value = record.teacherId || '';
    formTitle.textContent = 'Edit ' + record.sectionCode;
    submitBtn.textContent = 'Save changes';
    cancelBtn.hidden = false;
    form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function renderSections() {
    var items = window.TCCSections.all();
    if (!items.length) {
      body.innerHTML = '';
      if (empty) empty.hidden = false;
      return;
    }
    if (empty) empty.hidden = true;
    body.innerHTML = items.map(function (s) {
      var sendBtn = s.teacherId
        ? '<button type="button" class="btn-mini btn-mini--good" data-send-section="' + s.id + '">Send to teacher</button>'
        : '<button type="button" class="btn-mini btn-mini--muted" disabled title="Assign a teacher first">Send to teacher</button>';
      var statusCell;
      if (s.isSent) {
        statusCell = '<span class="badge badge--good" title="Sent ' + escapeHtml(fmtDateTime(s.sentAt)) + '">Sent</span>';
        if (s.changedSinceSent) {
          statusCell += ' <span class="badge badge--warn" title="Roster or section details changed after this was sent — resend to notify the teacher of the update.">Changed since sent</span>';
        }
      } else {
        statusCell = '<span class="badge badge--muted">Not sent</span>';
      }
      return '<tr>' +
        '<td>' + escapeHtml(s.sectionCode) + '</td>' +
        '<td>' + escapeHtml([s.program, s.yearLevel].filter(Boolean).join(' \u2014 ') || '\u2014') + '</td>' +
        '<td>' + escapeHtml(s.term) + '</td>' +
        '<td>' + (s.teacherName ? escapeHtml(s.teacherName) : '<span class="portal-row-meta">Unassigned</span>') + '</td>' +
        '<td>' + s.studentCount + '</td>' +
        '<td>' + statusCell + '</td>' +
        '<td class="portal-table-actions">' +
        sendBtn +
        '<button type="button" class="btn-mini" data-roster-section="' + s.id + '">Manage students</button>' +
        '<button type="button" class="btn-mini btn-mini--muted" data-edit-section="' + s.id + '">Edit</button>' +
        '<button type="button" class="btn-mini btn-mini--bad" data-remove-section="' + s.id + '">Delete</button>' +
        '</td></tr>';
    }).join('');
    renderBulkSendBtn(items);
  }

  // "Send all unsent" — reuses the exact same per-section send call the
  // single button uses (window.TCCSections.sendToTeacher), just looped
  // with one confirmation up front instead of one per section.
  var bulkSendBtn = document.getElementById('sectionsBulkSendBtn');
  function renderBulkSendBtn(items) {
    if (!bulkSendBtn) return;
    var pending = items.filter(function (s) { return s.teacherId && !s.isSent; });
    bulkSendBtn.hidden = pending.length === 0;
    bulkSendBtn.textContent = 'Send all unsent (' + pending.length + ')';
    bulkSendBtn.onclick = function () {
      if (!pending.length) return;
      var names = pending.map(function (s) { return s.sectionCode + ' \u2192 ' + s.teacherName; }).join('\n');
      if (!window.confirm('Send ' + pending.length + ' section(s) to their assigned teachers?\n\n' + names)) return;
      var sent = 0, failed = 0;
      var chain = pending.reduce(function (p, s) {
        return p.then(function () {
          return window.TCCSections.sendToTeacher(s.id).then(function (result) {
            if (result.error) failed++; else sent++;
          });
        });
      }, Promise.resolve());
      chain.then(function () {
        if (sent) toast('Sent ' + sent + ' section' + (sent === 1 ? '' : 's') + ' to their teachers.', 'success');
        if (failed) toast(failed + ' section' + (failed === 1 ? '' : 's') + ' could not be sent.', 'error');
      });
    };
  }

  function renderAll() { renderTeacherSelect(); renderSections(); if (openRosterId != null) loadRoster(openRosterId); }
  renderAll();
  window.TCCSections.onChange(renderSections);
  window.TCCSections.ready.then(renderAll);
  window.TCCAccounts.onChange(renderAll);
  window.TCCAccounts.ready.then(renderAll);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var data = {};
    Object.keys(fieldIds).forEach(function (key) { var el = fieldEl(key); if (el) data[key] = el.value; });
    data.teacherId = teacherSelect ? teacherSelect.value : '';
    var editId = editIdInput.value;
    var action = editId ? window.TCCSections.update(editId, data) : window.TCCSections.add(data);
    action.then(function (result) {
      if (result.error) { toast(result.error, 'error'); return; }
      toast(editId ? 'Section updated' : 'Section created', 'success');
      resetForm();
    });
  });

  cancelBtn.addEventListener('click', resetForm);

  /* ---- Roster panel (view / add / remove students for one section) ---- */
  var rosterCard = document.getElementById('sectionRosterCard');
  var rosterSectionName = document.getElementById('rosterSectionName');
  var rosterStudentSelect = document.getElementById('rosterStudentSelect');
  var addStudentForm = document.getElementById('addSectionStudentForm');
  var rosterBody = document.getElementById('rosterBody');
  var rosterEmpty = document.getElementById('rosterEmpty');
  var rosterCloseBtn = document.getElementById('rosterCloseBtn');
  var openRosterId = null;
  var currentRosterEmails = [];

  function renderStudentSelect() {
    if (!rosterStudentSelect) return;
    var already = {};
    currentRosterEmails.forEach(function (email) { already[email.toLowerCase()] = true; });
    var options = approvedStudents().filter(function (s) { return !already[s.email.toLowerCase()]; });
    rosterStudentSelect.innerHTML = '<option value="">Select a student\u2026</option>' +
      options.map(function (s) {
        return '<option value="' + s.id + '">' + escapeHtml(s.name) + ' \u2014 ' + escapeHtml(s.email) + '</option>';
      }).join('');
  }

  function loadRoster(sectionId) {
    return window.TCCSections.roster(sectionId).then(function (students) {
      currentRosterEmails = students.map(function (s) { return s.email; });
      renderStudentSelect();
      if (!students.length) {
        rosterBody.innerHTML = '';
        if (rosterEmpty) rosterEmpty.hidden = false;
        return;
      }
      if (rosterEmpty) rosterEmpty.hidden = true;
      rosterBody.innerHTML = students.map(function (s) {
        return '<tr>' +
          '<td>' + escapeHtml(s.studentId || '\u2014') + '</td>' +
          '<td>' + escapeHtml(s.name) + '</td>' +
          '<td class="portal-table-ellipsis portal-table-ellipsis--email" title="' + escapeHtml(s.email) + '">' + escapeHtml(s.email) + '</td>' +
          '<td class="portal-table-actions"><button type="button" class="btn-mini btn-mini--bad" data-remove-roster-student="' + s.id + '">Remove</button></td>' +
          '</tr>';
      }).join('');
    });
  }

  function openRoster(sectionId) {
    var record = window.TCCSections.all().filter(function (s) { return String(s.id) === String(sectionId); })[0];
    if (!record) return;
    openRosterId = sectionId;
    rosterCard.hidden = false;
    rosterSectionName.textContent = record.sectionCode;
    loadRoster(sectionId);
    rosterCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function closeRoster() {
    openRosterId = null;
    rosterCard.hidden = true;
  }

  if (rosterCloseBtn) rosterCloseBtn.addEventListener('click', closeRoster);

  if (addStudentForm) {
    addStudentForm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (openRosterId == null) return;
      var studentUserId = rosterStudentSelect.value;
      if (!studentUserId) { toast('Select a student to add.', 'error'); return; }
      window.TCCSections.addStudent(openRosterId, studentUserId).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast('Student added to section', 'success');
        addStudentForm.reset();
        loadRoster(openRosterId);
      });
    });
  }

  if (rosterBody) {
    rosterBody.addEventListener('click', function (e) {
      var studentUserId = e.target.getAttribute && e.target.getAttribute('data-remove-roster-student');
      if (!studentUserId || openRosterId == null) return;
      window.TCCSections.removeStudent(openRosterId, studentUserId).then(function (deleted) {
        if (!deleted) { toast('Could not remove that student.', 'error'); return; }
        toast('Student removed from section', 'success');
        loadRoster(openRosterId);
      });
    });
  }

  body.addEventListener('click', function (e) {
    var editId = e.target.getAttribute && e.target.getAttribute('data-edit-section');
    if (editId) { startEdit(editId); return; }
    var rosterId = e.target.getAttribute && e.target.getAttribute('data-roster-section');
    if (rosterId) { openRoster(rosterId); return; }
    var sendId = e.target.getAttribute && e.target.getAttribute('data-send-section');
    if (sendId) {
      var record = window.TCCSections.all().filter(function (s) { return String(s.id) === String(sendId); })[0];
      if (!record) return;
      var confirmMsg = 'Send "' + record.sectionCode + '" to ' + record.teacherName + '? ' +
        'They\u2019ll be notified with the current roster (' + record.studentCount +
        (record.studentCount === 1 ? ' student' : ' students') + ').';
      if (!window.confirm(confirmMsg)) return;
      window.TCCSections.sendToTeacher(sendId).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast('Section sent to ' + result.record.teacherName + '.', 'success');
      });
      return;
    }
    var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-section');
    if (removeId) {
      window.TCCSections.remove(removeId).then(function (deleted) {
        if (!deleted) { toast('Could not remove that section.', 'error'); return; }
        toast('Section removed', 'success');
        if (editIdInput.value === removeId) resetForm();
        if (String(openRosterId) === String(removeId)) closeRoster();
      });
    }
  });
})();
