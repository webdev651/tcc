/* =========================================================================
   Admin — Assign students to teachers (admin/dashboard.html only).
   Reads registered teacher/student accounts from js/core/accounts.js
   (real DB, GET /api/admin/requests), and talks to
   backend/src/routes/roster.js (GET/POST/DELETE /api/roster/assignments)
   for the explicit teacher<->student links. Guarded by element presence,
   same convention as the rest of the admin-*.js files.
   ========================================================================= */
(function () {
  if (!window.TCCApi || !window.TCCAccounts) return;
  var api = window.TCCApi;

  var accountsBody = document.getElementById('accountsStudentsBody');
  var assignForm = document.getElementById('assignStudentForm');
  if (!accountsBody && !assignForm) return;

  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDate(iso) {
    if (!iso) return '\u2014';
    var d = new Date(iso);
    if (isNaN(d)) return '\u2014';
    return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  function approvedStudents() {
    return window.TCCAccounts.all().filter(function (a) { return a.role === 'student' && a.status === 'approved'; });
  }
  function approvedTeachers() {
    return window.TCCAccounts.all().filter(function (a) { return a.role === 'teacher' && a.status === 'approved'; });
  }

  /* ---- Registered student accounts (real DB, read-only list) ---- */
  var accountsEmpty = document.getElementById('accountsStudentsEmpty');
  function renderAccounts() {
    if (!accountsBody) return;
    var items = approvedStudents();
    if (!items.length) {
      accountsBody.innerHTML = '';
      if (accountsEmpty) accountsEmpty.hidden = false;
      return;
    }
    if (accountsEmpty) accountsEmpty.hidden = true;
    accountsBody.innerHTML = items.map(function (s) {
      return '<tr>' +
        '<td>' + escapeHtml(s.name) + '</td>' +
        '<td class="portal-table-ellipsis portal-table-ellipsis--email" title="' + escapeHtml(s.email) + '">' + escapeHtml(s.email) + '</td>' +
        '<td>' + escapeHtml(s.detail || '\u2014') + '</td>' +
        '</tr>';
    }).join('');
  }

  /* ---- Assign form dropdowns ---- */
  var teacherSelect = document.getElementById('asgTeacher');
  var studentSelect = document.getElementById('asgStudent');
  function renderDropdowns() {
    if (teacherSelect) {
      var curT = teacherSelect.value;
      teacherSelect.innerHTML = '<option value="">Select a teacher\u2026</option>' +
        approvedTeachers().map(function (t) {
          return '<option value="' + escapeHtml(t.email) + '" data-name="' + escapeHtml(t.name) + '">' + escapeHtml(t.name) + ' \u2014 ' + escapeHtml(t.email) + '</option>';
        }).join('');
      teacherSelect.value = curT;
    }
    if (studentSelect) {
      var curS = studentSelect.value;
      studentSelect.innerHTML = '<option value="">Select a student\u2026</option>' +
        approvedStudents().map(function (s) {
          return '<option value="' + escapeHtml(s.email) + '" data-name="' + escapeHtml(s.name) + '">' + escapeHtml(s.name) + ' \u2014 ' + escapeHtml(s.email) + '</option>';
        }).join('');
      studentSelect.value = curS;
    }
  }

  /* ---- Current assignments table ---- */
  var assignmentsBody = document.getElementById('assignmentsBody');
  var assignmentsEmpty = document.getElementById('assignmentsEmpty');
  function loadAssignments() {
    if (!assignmentsBody) return Promise.resolve([]);
    return api.get('/roster/assignments')
      .then(function (data) { renderAssignments(data.assignments || []); return data.assignments || []; })
      .catch(function () { renderAssignments([]); return []; });
  }
  function renderAssignments(items) {
    if (!items.length) {
      assignmentsBody.innerHTML = '';
      if (assignmentsEmpty) assignmentsEmpty.hidden = false;
      return;
    }
    if (assignmentsEmpty) assignmentsEmpty.hidden = true;
    assignmentsBody.innerHTML = items.map(function (a) {
      return '<tr>' +
        '<td>' + escapeHtml(a.teacherName || a.teacherEmail) + '<br /><span class="portal-row-meta">' + escapeHtml(a.teacherEmail) + '</span></td>' +
        '<td>' + escapeHtml(a.studentName) + '<br /><span class="portal-row-meta">' + escapeHtml(a.studentEmail) + '</span></td>' +
        '<td>' + fmtDate(a.assignedAt) + '</td>' +
        '<td class="portal-table-actions"><button type="button" class="btn-mini btn-mini--bad" data-remove-assignment="' + a.id + '">Remove</button></td>' +
        '</tr>';
    }).join('');
  }

  if (assignForm) {
    assignForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var tOpt = teacherSelect.options[teacherSelect.selectedIndex];
      var sOpt = studentSelect.options[studentSelect.selectedIndex];
      if (!teacherSelect.value || !studentSelect.value) { toast('Select both a teacher and a student.', 'error'); return; }

      api.post('/roster/assignments', {
        teacherEmail: teacherSelect.value,
        teacherName: tOpt ? tOpt.getAttribute('data-name') : '',
        studentEmail: studentSelect.value,
        studentName: sOpt ? sOpt.getAttribute('data-name') : ''
      }).then(function () {
        toast('Student assigned to teacher', 'success');
        assignForm.reset();
        loadAssignments();
      }).catch(function (err) {
        toast(api.errorMessage(err), 'error');
      });
    });
  }

  if (assignmentsBody) {
    assignmentsBody.addEventListener('click', function (e) {
      var id = e.target.getAttribute && e.target.getAttribute('data-remove-assignment');
      if (!id) return;
      api.del('/roster/assignments/' + id)
        .then(function (res) {
          if (!res.deleted) { toast('Could not remove that assignment.', 'error'); return; }
          toast('Assignment removed', 'success');
          loadAssignments();
        })
        .catch(function (err) { toast(api.errorMessage(err), 'error'); });
    });
  }

  function renderAll() { renderAccounts(); renderDropdowns(); }
  renderAll();
  window.TCCAccounts.ready.then(renderAll);
  window.addEventListener('tcc-accounts:changed', renderAll);
  loadAssignments();

  // Note: the "Teacher Master List" search/preview/export UI used to live
  // here, keyed off a <select> of TCCAccounts-cached teachers. It's now in
  // js/admin/admin-master-list.js, backed by GET /api/admin/teachers and
  // GET /api/admin/master-list?teacher_id= (live name search + richer
  // student-profile columns) instead.
})();
