/* =========================================================================
   MODULE 5 — Admin portal additions (admin/dashboard.html only).
   Posting/managing college-wide announcements, and reviewing + responding
   to feedback & suggestions from students and teachers. Guarded by element
   presence, same convention as admin-approvals.js, so this file is a no-op
   if loaded anywhere else.
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function timeAgo(iso) {
    if (!iso) return '—';
    var then = new Date(iso).getTime();
    if (isNaN(then)) return '—';
    var diff = Math.max(0, Date.now() - then);
    var mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + ' minute' + (mins === 1 ? '' : 's') + ' ago';
    var hours = Math.floor(mins / 60);
    if (hours < 24) return hours + ' hour' + (hours === 1 ? '' : 's') + ' ago';
    var days = Math.floor(hours / 24);
    if (days < 7) return days + ' day' + (days === 1 ? '' : 's') + ' ago';
    var weeks = Math.floor(days / 7);
    if (weeks < 5) return weeks + ' week' + (weeks === 1 ? '' : 's') + ' ago';
    return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }
  function fmtDate(iso) {
    if (!iso) return '—';
    var d = new Date(iso);
    if (isNaN(d)) return '—';
    return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  /* ---- Announcement Center — post college-wide (or audience-targeted)
     announcements with a category/priority/status, then browse, search,
     filter, sort and manage every announcement across the site through
     the shared Announcement Center (search/filter/sort/read-unread/detail
     view + edit/delete from the detail modal). ---- */
  var annForm = document.getElementById('adminAnnouncementForm');
  if (annForm && window.TCCAnnouncements) {
    var aaEditIdInput = document.getElementById('aaEditId');
    var aaFormTitle = document.getElementById('announcementFormTitle');
    var aaSubmitBtn = document.getElementById('aaSubmitBtn');
    var aaCancelBtn = document.getElementById('aaCancelEdit');
    var aaCategorySelect = document.getElementById('aaCategory');
    var aaPrioritySelect = document.getElementById('aaPriority');
    var aaStatusSelect = document.getElementById('aaStatus');

    function resetAnnouncementForm() {
      annForm.reset();
      aaEditIdInput.value = '';
      aaFormTitle.textContent = 'Post an announcement';
      aaSubmitBtn.textContent = 'Post announcement';
      aaCancelBtn.hidden = true;
    }
    function startEditAnnouncement(record) {
      aaEditIdInput.value = record.id;
      document.getElementById('aaTitle').value = record.title;
      document.getElementById('aaBody').value = record.body;
      var radio = annForm.querySelector('input[name="aaAudience"][value="' + record.audience + '"]');
      if (radio) radio.checked = true;
      if (aaCategorySelect) aaCategorySelect.value = record.category;
      if (aaPrioritySelect) aaPrioritySelect.value = record.priority;
      if (aaStatusSelect) aaStatusSelect.value = record.status;
      aaFormTitle.textContent = 'Edit announcement';
      aaSubmitBtn.textContent = 'Save changes';
      aaCancelBtn.hidden = false;
      annForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    if (document.getElementById('adminAnnouncementCenter') && window.TCCAnnouncementCenter) {
      window.TCCAnnouncementCenter.mount({
        containerId: 'adminAnnouncementCenter',
        getItems: function () { return window.TCCAnnouncements.all(); },
        role: 'admin',
        canManageAll: true,
        onEdit: startEditAnnouncement,
        emptyMessage: 'No announcements yet.'
      });
    }

    annForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var audienceInput = annForm.querySelector('input[name="aaAudience"]:checked');
      var editId = aaEditIdInput.value;
      var payload = {
        title: document.getElementById('aaTitle').value,
        body: document.getElementById('aaBody').value,
        audience: audienceInput ? audienceInput.value : 'all',
        category: aaCategorySelect ? aaCategorySelect.value : 'General',
        priority: aaPrioritySelect ? aaPrioritySelect.value : 'Normal',
        status: aaStatusSelect ? aaStatusSelect.value : 'Published'
      };
      var action = editId
        ? window.TCCAnnouncements.update(editId, payload)
        : window.TCCAnnouncements.add(Object.assign(payload, { postedByName: 'Admin office', postedByRole: 'admin' }));
      action.then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast(editId ? 'Announcement updated' : 'Announcement posted', 'success');
        resetAnnouncementForm();
      });
    });
    aaCancelBtn.addEventListener('click', resetAnnouncementForm);
  }

  /* ---- Feedback & suggestions — table of everything submitted, with an
     inline expand/respond row (a full-width table cell rather than a
     modal) so responding doesn't leave the Feedback view. ---- */
  var feedbackBody = document.getElementById('feedbackBody');
  if (feedbackBody && window.TCCFeedback) {
    var feedbackEmpty = document.getElementById('feedbackEmpty');
    var feedbackStatEl = document.getElementById('feedbackStatValue');
    var feedbackNavBadge = document.getElementById('feedbackBadge');
    var feedbackNavBadgeCount = document.getElementById('feedbackBadgeCount');

    function statusBadge(status) {
      return status === 'resolved' ? '<span class="badge badge--good">Resolved</span>' : '<span class="badge badge--warn">New</span>';
    }

    // Tracks which row's respond panel is open, so an auto-refresh mid-render
    // (see js/core/live-poll.js) doesn't silently discard an unsent draft —
    // the panel and whatever the admin had typed are restored right after.
    var openRespondId = null;

    function render() {
      var draftId = openRespondId;
      var draftText = null;
      if (draftId) {
        var openTextarea = document.getElementById('respondText-' + draftId);
        if (openTextarea) draftText = openTextarea.value;
      }

      var items = window.TCCFeedback.all();
      var pending = window.TCCFeedback.pendingCount();

      if (feedbackStatEl) feedbackStatEl.textContent = String(pending);
      if (feedbackNavBadgeCount) feedbackNavBadgeCount.textContent = String(pending);
      if (feedbackNavBadge) feedbackNavBadge.hidden = pending === 0;

      if (!items.length) {
        feedbackBody.innerHTML = '';
        if (feedbackEmpty) feedbackEmpty.hidden = false;
        return;
      }
      if (feedbackEmpty) feedbackEmpty.hidden = true;

      feedbackBody.innerHTML = items.map(function (f) {
        var actionBtn = f.status === 'resolved'
          ? '<button type="button" class="btn-mini btn-mini--muted" data-toggle-feedback="' + f.id + '">View</button>'
          : '<button type="button" class="btn-mini btn-mini--good" data-toggle-feedback="' + f.id + '">Respond</button>';
        var deleteBtn = '<button type="button" class="btn-mini btn-mini--bad" data-remove-feedback="' + f.id + '">Delete</button>';
        return '<tr data-feedback-row="' + f.id + '">' +
          '<td>' + escapeHtml(f.name) + '</td>' +
          '<td>' + (f.role === 'teacher' ? 'Teacher' : 'Student') + '</td>' +
          '<td>' + escapeHtml(f.category) + '</td>' +
          '<td class="portal-table-ellipsis" title="' + escapeHtml(f.subject || '') + '">' + escapeHtml(f.subject || '\u2014') + '</td>' +
          '<td>' + fmtDate(f.submittedAt) + '</td>' +
          '<td>' + statusBadge(f.status) + '</td>' +
          '<td class="portal-table-actions">' + actionBtn + deleteBtn + '</td>' +
          '</tr>';
      }).join('');

      // Re-open the respond panel this render just wiped out, restoring
      // any text the admin hadn't sent yet.
      if (draftId && items.some(function (f) { return f.id === draftId && f.status !== 'resolved'; })) {
        openRespondRow(draftId, true);
        var restored = document.getElementById('respondText-' + draftId);
        if (restored && draftText != null) restored.value = draftText;
      }
    }

    function closeAllRespondRows() {
      Array.prototype.slice.call(document.querySelectorAll('.feedback-respond-row')).forEach(function (tr) { tr.remove(); });
    }

    function openRespondRow(id, skipToggleClose) {
      var alreadyOpen = document.getElementById('respond-' + id);
      closeAllRespondRows();
      if (alreadyOpen && !skipToggleClose) { openRespondId = null; return; } // toggle: clicking again just closes it
      openRespondId = id;

      var item = window.TCCFeedback.all().filter(function (f) { return f.id === id; })[0];
      var mainRow = feedbackBody.querySelector('tr[data-feedback-row="' + id + '"]');
      if (!item || !mainRow) return;

      var tr = document.createElement('tr');
      tr.className = 'feedback-respond-row';
      tr.id = 'respond-' + id;
      var td = document.createElement('td');
      td.colSpan = 7;

      var html = '<div class="portal-row-response portal-row-full"><b>Message:</b> ' + escapeHtml(item.message) + '</div>';
      if (item.status === 'resolved') {
        html += '<div class="portal-row-response portal-row-full" style="margin-top:0.5rem;"><b>Your response:</b> ' + escapeHtml(item.response) + '</div>';
      } else {
        html += '<textarea placeholder="Write a response…" id="respondText-' + id + '" style="margin-top:0.75rem;"></textarea>' +
          '<div class="feedback-respond-actions">' +
          '<button type="button" class="btn-mini btn-mini--good" data-send-response="' + id + '">Send response</button>' +
          '<button type="button" class="btn-mini btn-mini--muted" data-cancel-respond="' + id + '">Cancel</button>' +
          '</div>';
      }
      td.innerHTML = html;
      tr.appendChild(td);
      mainRow.parentNode.insertBefore(tr, mainRow.nextSibling);
    }

    render();
    window.TCCFeedback.onChange(render);
    window.TCCFeedback.ready.then(render);

    feedbackBody.addEventListener('click', function (e) {
      var toggleId = e.target.getAttribute && e.target.getAttribute('data-toggle-feedback');
      if (toggleId) { openRespondRow(toggleId); return; }

      var cancelId = e.target.getAttribute && e.target.getAttribute('data-cancel-respond');
      if (cancelId) { openRespondId = null; closeAllRespondRows(); return; }

      var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-feedback');
      if (removeId) {
        window.TCCFeedback.remove(removeId).then(function (deleted) {
          if (!deleted) { toast('Could not remove that feedback item.', 'error'); return; }
          toast('Feedback removed', 'success');
        });
        return;
      }

      var sendId = e.target.getAttribute && e.target.getAttribute('data-send-response');
      if (sendId) {
        var textarea = document.getElementById('respondText-' + sendId);
        var text = textarea ? textarea.value.trim() : '';
        if (!text) { toast('Write a response before sending', 'error'); return; }
        window.TCCFeedback.respond(sendId, text).then(function (updated) {
          if (!updated) { toast('Could not send the response.', 'error'); return; }
          toast('Response sent', 'success');
        });
      }
    });
  }
})();
