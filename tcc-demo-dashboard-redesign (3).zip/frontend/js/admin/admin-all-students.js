/* =========================================================================
   Admin — All Student Accounts (admin/dashboard.html only).
   Every approved student account, enriched with student_profiles detail
   and assigned teacher(s), via GET /api/admin/students (admin-only,
   backend/src/routes/admin.js). Fetched once, then filtered client-side
   (search text + year level + section + teacher) — same pattern as the
   rest of the admin dashboard's portal-search boxes, just with a few
   extra structured filters on top of the free-text one.

   Guarded by element presence, so it's a no-op on any page without this
   card.
   ========================================================================= */
(function () {
  if (!window.TCCApi) return;
  var api = window.TCCApi;

  var searchInput = document.getElementById('allStudentsSearch');
  var yearFilter = document.getElementById('allStudentsYearFilter');
  var sectionFilter = document.getElementById('allStudentsSectionFilter');
  var teacherFilter = document.getElementById('allStudentsTeacherFilter');
  var body = document.getElementById('allStudentsBody');
  var empty = document.getElementById('allStudentsEmpty');
  var pager = document.getElementById('allStudentsPager');
  var pagerLabel = document.getElementById('allStudentsPagerLabel');
  var prevBtn = document.getElementById('allStudentsPrevBtn');
  var nextBtn = document.getElementById('allStudentsNextBtn');
  var PAGE_SIZE = 25;
  var currentPage = 1;

  if (!body) return;

  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDate(iso) {
    if (!iso) return '\u2014';
    var d = new Date(iso);
    if (isNaN(d)) return '\u2014';
    return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  var allStudents = [];
  var editingId = null;   // account id of the row currently showing the section editor, if any
  var knownSections = []; // for the section input's <datalist> suggestions

  function uniqueSorted(values) {
    var seen = {};
    var out = [];
    values.forEach(function (v) {
      var t = String(v || '').trim();
      if (!t || seen[t]) return;
      seen[t] = true;
      out.push(t);
    });
    return out.sort(function (a, b) { return a.localeCompare(b); });
  }

  function populateFilterOptions() {
    if (yearFilter) {
      var curY = yearFilter.value;
      yearFilter.innerHTML = '<option value="">All year levels</option>' +
        uniqueSorted(allStudents.map(function (s) { return s.yearLevel; })).map(function (v) {
          return '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>';
        }).join('');
      yearFilter.value = curY;
    }
    if (sectionFilter) {
      var curS = sectionFilter.value;
      sectionFilter.innerHTML = '<option value="">All sections</option>' +
        uniqueSorted(allStudents.map(function (s) { return s.section; })).map(function (v) {
          return '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>';
        }).join('');
      sectionFilter.value = curS;
    }
    if (teacherFilter) {
      var curT = teacherFilter.value;
      var names = uniqueSorted(Array.prototype.concat.apply([], allStudents.map(function (s) { return s.assignedTeachers || []; })));
      teacherFilter.innerHTML = '<option value="">All teachers</option>' +
        names.map(function (v) {
          return '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>';
        }).join('');
      teacherFilter.value = curT;
    }
  }

  function applyFiltersAndRender() {
    var q = (searchInput && searchInput.value || '').trim().toLowerCase();
    var year = yearFilter && yearFilter.value || '';
    var section = sectionFilter && sectionFilter.value || '';
    var teacherName = teacherFilter && teacherFilter.value || '';

    var items = allStudents.filter(function (s) {
      if (q && s.name.toLowerCase().indexOf(q) === -1 && s.email.toLowerCase().indexOf(q) === -1 && (s.studentId || '').toLowerCase().indexOf(q) === -1) return false;
      if (year && s.yearLevel !== year) return false;
      if (section && s.section !== section) return false;
      if (teacherName && (s.assignedTeachers || []).indexOf(teacherName) === -1) return false;
      return true;
    });

    var totalPages = Math.max(1, Math.ceil(items.length / PAGE_SIZE));
    if (currentPage > totalPages) currentPage = totalPages;
    if (currentPage < 1) currentPage = 1;
    var start = (currentPage - 1) * PAGE_SIZE;
    var pageItems = items.slice(start, start + PAGE_SIZE);

    renderTable(pageItems);
    renderPager(items.length, totalPages);
  }

  function renderPager(totalCount, totalPages) {
    if (!pager) return;
    if (!totalCount || totalPages <= 1) { pager.hidden = totalCount === 0; if (pagerLabel && totalCount) pagerLabel.textContent = totalCount + (totalCount === 1 ? ' student' : ' students'); if (prevBtn) prevBtn.disabled = true; if (nextBtn) nextBtn.disabled = true; return; }
    pager.hidden = false;
    if (pagerLabel) {
      var start = (currentPage - 1) * PAGE_SIZE + 1;
      var end = Math.min(currentPage * PAGE_SIZE, totalCount);
      pagerLabel.textContent = start + '\u2013' + end + ' of ' + totalCount + ' students \u00b7 page ' + currentPage + ' of ' + totalPages;
    }
    if (prevBtn) prevBtn.disabled = currentPage <= 1;
    if (nextBtn) nextBtn.disabled = currentPage >= totalPages;
  }

  if (prevBtn) prevBtn.addEventListener('click', function () { currentPage--; applyFiltersAndRender(); });
  if (nextBtn) nextBtn.addEventListener('click', function () { currentPage++; applyFiltersAndRender(); });

  function renderTable(items) {
    if (!items.length) {
      body.innerHTML = '';
      if (empty) empty.hidden = false;
      return;
    }
    if (empty) empty.hidden = true;
    body.innerHTML = items.map(function (s) {
      var teachers = (s.assignedTeachers || []).length ? s.assignedTeachers.map(escapeHtml).join(', ') : '\u2014';
      var isEditing = editingId != null && String(editingId) === String(s.id);
      var sectionCell = isEditing
        ? '<div class="section-edit" style="display:flex; align-items:center; gap:.4rem; flex-wrap:wrap;">' +
            '<input type="text" list="knownSectionsList" data-section-input="' + s.id + '" value="' + escapeHtml(s.section || '') + '" placeholder="e.g. BSCS-2A" maxlength="30" style="width:9rem;" />' +
            '<button type="button" class="btn-mini btn-mini--good" data-save-section="' + s.id + '">Save</button>' +
            '<button type="button" class="btn-mini btn-mini--muted" data-cancel-section="' + s.id + '">Cancel</button>' +
          '</div>'
        : '<div class="section-view" style="display:flex; align-items:center; gap:.5rem;">' +
            '<span>' + escapeHtml(s.section || '\u2014') + '</span>' +
            '<button type="button" class="btn-mini" data-edit-section="' + s.id + '">' + (s.section ? 'Change' : 'Assign') + '</button>' +
          '</div>';
      return '<tr>' +
        '<td>' + escapeHtml(s.studentId || '\u2014') + '</td>' +
        '<td>' + escapeHtml(s.name) + '</td>' +
        '<td class="portal-table-ellipsis portal-table-ellipsis--email" title="' + escapeHtml(s.email) + '">' + escapeHtml(s.email) + '</td>' +
        '<td>' + escapeHtml(s.program || '\u2014') + '</td>' +
        '<td>' + escapeHtml(s.yearLevel || '\u2014') + '</td>' +
        '<td>' + sectionCell + '</td>' +
        '<td>' + teachers + '</td>' +
        '<td>' + escapeHtml(s.status || '\u2014') + '</td>' +
        '<td>' + fmtDate(s.createdAt) + '</td>' +
        '</tr>';
    }).join('');
  }

  function loadSections() {
    return api.get('/admin/sections')
      .then(function (data) {
        knownSections = data.sections || [];
        var dl = document.getElementById('knownSectionsList');
        if (dl) dl.innerHTML = knownSections.map(function (v) { return '<option value="' + escapeHtml(v) + '"></option>'; }).join('');
      })
      .catch(function () { /* datalist suggestions are a nicety, not required */ });
  }

  function saveSection(id, rawValue) {
    var value = String(rawValue || '').trim().replace(/\s+/g, ' ');
    if (!value) { toast('Enter a section before saving.', 'error'); return; }

    api.put('/admin/students/' + id + '/section', { section: value })
      .then(function (res) {
        allStudents = allStudents.map(function (s) {
          if (String(s.id) !== String(id)) return s;
          var updated = {};
          for (var k in s) { updated[k] = s[k]; }
          updated.section = res.section;
          return updated;
        });
        editingId = null;
        toast('Section updated \u2014 the student will see it on their Profile.', 'success');
        populateFilterOptions();
        applyFiltersAndRender();
        loadSections();
      })
      .catch(function (err) { toast(api.errorMessage(err), 'error'); });
  }

  body.addEventListener('click', function (e) {
    var target = e.target;
    var editId = target.getAttribute && target.getAttribute('data-edit-section');
    if (editId) { editingId = editId; applyFiltersAndRender(); return; }

    var cancelId = target.getAttribute && target.getAttribute('data-cancel-section');
    if (cancelId) { editingId = null; applyFiltersAndRender(); return; }

    var saveId = target.getAttribute && target.getAttribute('data-save-section');
    if (saveId) {
      var input = body.querySelector('[data-section-input="' + saveId + '"]');
      saveSection(saveId, input ? input.value : '');
      return;
    }
  });

  body.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter') return;
    var input = e.target;
    var saveId = input.getAttribute && input.getAttribute('data-section-input');
    if (!saveId) return;
    e.preventDefault();
    saveSection(saveId, input.value);
  });

  function load() {
    api.get('/admin/students')
      .then(function (data) {
        allStudents = data.students || [];
        populateFilterOptions();
        applyFiltersAndRender();
      })
      .catch(function (err) { toast(api.errorMessage(err), 'error'); });
  }

  [searchInput, yearFilter, sectionFilter, teacherFilter].forEach(function (el) {
    if (!el) return;
    var evt = el.tagName === 'SELECT' ? 'change' : 'input';
    el.addEventListener(evt, function () { currentPage = 1; applyFiltersAndRender(); });
  });

  load();
  loadSections();

  // This table is a bespoke /admin/students fetch, not one of the shared
  // js/modules/*.js caches, so js/core/live-poll.js can't refresh it on its
  // own. Reload on the same cadence directly: a fresh account approval or
  // profile edit elsewhere in the system should show up here too, without
  // the admin having to refresh the page.
  // Skip a reload while a row's section field is mid-edit — rebuilding the
  // table would wipe out whatever the admin has typed but not saved yet.
  function loadUnlessEditing() { if (editingId == null) load(); }
  window.addEventListener('tcc-accounts:changed', loadUnlessEditing);
  window.addEventListener('tcc-profiles:changed', loadUnlessEditing);
  setInterval(function () {
    if (document.visibilityState !== 'hidden') loadUnlessEditing();
  }, 3000);
})();
