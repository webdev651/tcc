/* =========================================================================
   Admin — Teacher Master List (admin/dashboard.html only).
   Search teacher accounts by (partial) name via GET /api/admin/teachers,
   select one, and load their complete student master list via
   GET /api/admin/master-list?teacher_id= — both admin-only endpoints in
   backend/src/routes/admin.js. Preview here, export as Excel/PDF.

   Guarded by element presence, same convention as the other admin-*.js
   files, so it's a no-op on any page that doesn't have this card.
   ========================================================================= */
(function () {
  if (!window.TCCApi) return;
  var api = window.TCCApi;

  var searchInput = document.getElementById('tmlSearchInput');
  var resultsBox = document.getElementById('tmlResults');
  var resultsEmpty = document.getElementById('tmlResultsEmpty');
  var selectedBox = document.getElementById('tmlSelected');
  var selectedName = document.getElementById('tmlSelectedName');
  var selectedEmail = document.getElementById('tmlSelectedEmail');
  var selectedCount = document.getElementById('tmlSelectedCount');
  var selectedMeta = document.getElementById('tmlSelectedMeta');
  var clearBtn = document.getElementById('tmlClearBtn');
  var masterListBody = document.getElementById('masterListBody');
  var masterListEmpty = document.getElementById('masterListEmpty');
  var exportExcelBtn = document.getElementById('masterListExportExcel');
  var exportPdfBtn = document.getElementById('masterListExportPdf');
  var sendRow = document.getElementById('tmlSendRow');
  var sectionSelect = document.getElementById('tmlSectionSelect');
  var sendBtn = document.getElementById('tmlSendBtn');

  if (!searchInput || !masterListBody) return;

  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  var exportColumns = [
    { label: 'Student ID', value: function (s) { return s.studentId; }, width: 16 },
    { label: 'Name', value: function (s) { return s.name; }, width: 26 },
    { label: 'Email', value: function (s) { return s.email; }, width: 30 },
    { label: 'Grade / Year level', value: function (s) { return s.gradeLevel; }, width: 18 },
    { label: 'Section', value: function (s) { return s.section; }, width: 16 },
    { label: 'Status', value: function (s) { return s.status; }, width: 14 }
  ];

  var current = { teacher: null, students: [] };
  var searchDebounce = null;

  /* ---- Teacher search (live, partial-name) ---- */
  function runSearch(q) {
    api.get('/admin/teachers?q=' + encodeURIComponent(q))
      .then(function (data) { renderResults(data.teachers || []); })
      .catch(function (err) { toast(api.errorMessage(err), 'error'); });
  }

  function renderResults(teachers) {
    if (!teachers.length) {
      resultsBox.innerHTML = '';
      resultsBox.hidden = true;
      if (resultsEmpty) resultsEmpty.hidden = false;
      return;
    }
    if (resultsEmpty) resultsEmpty.hidden = true;
    resultsBox.hidden = false;
    resultsBox.innerHTML = teachers.map(function (t) {
      return '<button type="button" class="tml-result" data-teacher-id="' + t.id + '">' +
        '<span class="tml-result-name">' + escapeHtml(t.name) + '</span>' +
        '<span class="tml-result-meta">' + escapeHtml(t.email) + (t.department ? ' \u00b7 ' + escapeHtml(t.department) : '') + '</span>' +
        '</button>';
    }).join('');
  }

  searchInput.addEventListener('input', function () {
    var q = searchInput.value.trim();
    clearTimeout(searchDebounce);
    if (!q) {
      resultsBox.innerHTML = '';
      resultsBox.hidden = true;
      if (resultsEmpty) resultsEmpty.hidden = true;
      return;
    }
    searchDebounce = setTimeout(function () { runSearch(q); }, 250);
  });

  if (resultsBox) {
    resultsBox.addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('[data-teacher-id]') : null;
      if (!btn) return;
      loadMasterList(Number(btn.getAttribute('data-teacher-id')));
    });
  }

  /* ---- Load & render a selected teacher's master list ---- */
  function loadMasterList(teacherId) {
    if (!teacherId) return;
    api.get('/admin/master-list?teacher_id=' + encodeURIComponent(teacherId))
      .then(function (data) {
        current = { teacher: data.teacher, students: data.students || [] };
        renderSelected();
        renderTable(current.students);
        resultsBox.hidden = true;
        resultsBox.innerHTML = '';
        searchInput.value = '';
      })
      .catch(function (err) { toast(api.errorMessage(err), 'error'); });
  }

  function renderSelected() {
    if (!current.teacher || !selectedBox) return;
    selectedBox.hidden = false;
    selectedName.textContent = current.teacher.name;
    selectedEmail.textContent = current.teacher.email;
    selectedCount.textContent = current.students.length + (current.students.length === 1 ? ' student' : ' students');
    if (selectedMeta) {
      var t = current.teacher;
      var parts = [
        'Teacher ID ' + t.id,
        t.department ? t.department : 'No department on file',
        (t.subjects && t.subjects.length) ? t.subjects.join(', ') : 'No subjects on file',
        t.status ? (t.status.charAt(0).toUpperCase() + t.status.slice(1)) : ''
      ].filter(Boolean);
      selectedMeta.textContent = parts.join(' \u00b7 ');
    }
    populateSectionOptions();
    if (sendRow) sendRow.hidden = current.students.length === 0;
  }

  /* Distinct, sorted sections among this teacher's loaded students — lets
     admin send just one section at a time for a teacher who has several,
     or leave "All sections" selected to send the whole list. */
  function populateSectionOptions() {
    if (!sectionSelect) return;
    var seen = {};
    var sections = [];
    current.students.forEach(function (s) {
      var sec = (s.section || '').trim();
      if (!sec || seen[sec]) return;
      seen[sec] = true;
      sections.push(sec);
    });
    sections.sort();
    sectionSelect.innerHTML = '<option value="">All sections</option>' +
      sections.map(function (sec) { return '<option value="' + escapeHtml(sec) + '">' + escapeHtml(sec) + '</option>'; }).join('');
  }

  if (clearBtn) {
    clearBtn.addEventListener('click', function () {
      current = { teacher: null, students: [] };
      if (selectedBox) selectedBox.hidden = true;
      if (sendRow) sendRow.hidden = true;
      renderTable([]);
      searchInput.focus();
    });
  }

  if (sendBtn) {
    sendBtn.addEventListener('click', function () {
      if (!current.teacher) return;
      var section = sectionSelect ? sectionSelect.value : '';
      sendBtn.disabled = true;
      var originalLabel = sendBtn.textContent;
      sendBtn.textContent = 'Sending…';
      api.post('/admin/master-list/send', { teacherId: current.teacher.id, section: section })
        .then(function (res) {
          var count = res.share ? res.share.totalStudents : 0;
          toast('Master list sent to ' + current.teacher.name + ' (' + count + (count === 1 ? ' student' : ' students') + ').', 'success');
        })
        .catch(function (err) { toast(api.errorMessage(err), 'error'); })
        .then(function () {
          sendBtn.disabled = false;
          sendBtn.textContent = originalLabel;
        });
    });
  }

  function renderTable(items) {
    if (!items.length) {
      masterListBody.innerHTML = '';
      if (masterListEmpty) {
        masterListEmpty.hidden = false;
        masterListEmpty.textContent = current.teacher ? 'This teacher has no linked students yet.' : 'Search for a teacher above and select them to load their master list.';
      }
      if (exportExcelBtn) exportExcelBtn.disabled = true;
      if (exportPdfBtn) exportPdfBtn.disabled = true;
      return;
    }
    if (masterListEmpty) masterListEmpty.hidden = true;
    if (exportExcelBtn) exportExcelBtn.disabled = false;
    if (exportPdfBtn) exportPdfBtn.disabled = false;
    masterListBody.innerHTML = items.map(function (s) {
      return '<tr>' +
        '<td>' + escapeHtml(s.studentId || '\u2014') + '</td>' +
        '<td>' + escapeHtml(s.name) + '<br /><span class="portal-row-meta">' + escapeHtml(s.email) + '</span></td>' +
        '<td>' + escapeHtml(s.gradeLevel || '\u2014') + '</td>' +
        '<td>' + escapeHtml(s.section || '\u2014') + '</td>' +
        '<td>' + escapeHtml(s.status || '\u2014') + '</td>' +
        '</tr>';
    }).join('');
  }

  function fileSlug() { return String((current.teacher && current.teacher.name) || 'teacher').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'teacher'; }

  if (exportExcelBtn) {
    exportExcelBtn.addEventListener('click', function () {
      if (!current.students.length) return;
      var ok = window.TCCExport && window.TCCExport.toExcel('master-list-' + fileSlug() + '.xlsx', 'Master List', exportColumns, current.students);
      if (ok === false) toast('Could not build the Excel file \u2014 check your connection and try again.', 'error');
    });
  }
  if (exportPdfBtn) {
    exportPdfBtn.addEventListener('click', function () {
      if (!current.students.length) return;
      var subtitle = 'Talisay City College \u00b7 ' + current.teacher.name + ' \u00b7 ' + new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
      var ok = window.TCCExport && window.TCCExport.toPDF('master-list-' + fileSlug() + '.pdf', 'Master List', subtitle, exportColumns, current.students);
      if (ok === false) toast('Could not build the PDF \u2014 check your connection and try again.', 'error');
    });
  }

  renderTable([]);
})();
