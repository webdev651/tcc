/* =========================================================================
   Admin — Staff Management (admin/dashboard.html only). Add/edit/delete
   teaching staff directory entries via staff.js. Same convention as
   admin-students.js: guarded by element presence, so this file is a
   no-op if loaded anywhere else.
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  var form = document.getElementById('staffForm');
  if (!form || !window.TCCStaff) return;

  var editIdInput = document.getElementById('staffEditId');
  var formTitle = document.getElementById('staffFormTitle');
  var submitBtn = document.getElementById('staffSubmitBtn');
  var cancelBtn = document.getElementById('staffCancelEdit');
  var body = document.getElementById('staffBody');
  var empty = document.getElementById('staffEmpty');

  var fieldIds = { name: 'staffName', email: 'staffEmail', department: 'staffDepartment', subjects: 'staffSubjects', load: 'staffLoad' };
  function fieldEl(key) { return document.getElementById(fieldIds[key]); }

  function resetForm() {
    form.reset();
    editIdInput.value = '';
    formTitle.textContent = 'Add a staff member';
    submitBtn.textContent = 'Add staff member';
    cancelBtn.hidden = true;
  }

  function startEdit(id) {
    var record = window.TCCStaff.all().filter(function (s) { return s.id === id; })[0];
    if (!record) return;
    editIdInput.value = id;
    Object.keys(fieldIds).forEach(function (key) { var el = fieldEl(key); if (el) el.value = record[key] || ''; });
    formTitle.textContent = 'Edit ' + record.name;
    submitBtn.textContent = 'Save changes';
    cancelBtn.hidden = false;
    form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function render() {
    var items = window.TCCStaff.all();
    if (!items.length) {
      body.innerHTML = '';
      if (empty) empty.hidden = false;
      return;
    }
    if (empty) empty.hidden = true;
    body.innerHTML = items.map(function (s) {
      return '<tr>' +
        '<td>' + escapeHtml(s.name) + '</td>' +
        '<td>' + escapeHtml(s.department || '\u2014') + '</td>' +
        '<td class="portal-table-ellipsis" title="' + escapeHtml(s.subjects || '') + '">' + escapeHtml(s.subjects || '\u2014') + '</td>' +
        '<td>' + escapeHtml(s.load || '\u2014') + '</td>' +
        '<td class="portal-table-actions">' +
        '<button type="button" class="btn-mini btn-mini--muted" data-edit-staff="' + s.id + '">Edit</button>' +
        '<button type="button" class="btn-mini btn-mini--bad" data-remove-staff="' + s.id + '">Delete</button>' +
        '</td></tr>';
    }).join('');
  }
  render();
  window.TCCStaff.onChange(render);
  window.TCCStaff.ready.then(render);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var data = {};
    Object.keys(fieldIds).forEach(function (key) { var el = fieldEl(key); if (el) data[key] = el.value; });
    var editId = editIdInput.value;
    var action = editId ? window.TCCStaff.update(editId, data) : window.TCCStaff.add(data);
    action.then(function (result) {
      if (result.error) { toast(result.error, 'error'); return; }
      toast(editId ? 'Staff member updated' : 'Staff member added', 'success');
      resetForm();
      render();
    });
  });

  cancelBtn.addEventListener('click', resetForm);

  body.addEventListener('click', function (e) {
    var editId = e.target.getAttribute && e.target.getAttribute('data-edit-staff');
    if (editId) { startEdit(editId); return; }
    var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-staff');
    if (removeId) {
      window.TCCStaff.remove(removeId).then(function (deleted) {
        if (!deleted) { toast('Could not remove that staff member.', 'error'); return; }
        toast('Staff member removed', 'success');
        if (editIdInput.value === removeId) resetForm();
      });
    }
  });
})();
