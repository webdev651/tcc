/* =========================================================================
   Admin — Notification Management (admin/dashboard.html only). Create a
   notification for everyone, one role, or one specific person; send it
   now or schedule it for later; cancel a scheduled one or delete any
   record. A scheduled notification is promoted to "sent" automatically
   once its time arrives (checked on load and every 30s while this page
   is open — good enough for a demo with no server-side scheduler).
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDateTime(iso) {
    if (!iso) return '\u2014';
    var d = new Date(iso);
    if (isNaN(d)) return '\u2014';
    return d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  }
  function recipientLabel(n) {
    if (n.recipientType === 'all') return 'Everyone';
    if (n.recipientType === 'student') return 'All students';
    if (n.recipientType === 'teacher') return 'All staff';
    return n.recipientEmail || 'Specific person';
  }

  var form = document.getElementById('notificationForm');
  if (!form || !window.TCCNotifications) return;

  var body = document.getElementById('notificationsBody');
  var empty = document.getElementById('notificationsEmpty');
  var recipientType = document.getElementById('ntfRecipientType');
  var specificField = document.getElementById('ntfSpecificEmailField');
  var navBadge = document.getElementById('ntfBadge');
  var navBadgeCount = document.getElementById('ntfBadgeCount');

  recipientType.addEventListener('change', function () {
    specificField.hidden = recipientType.value !== 'specific';
  });

  function render() {
    var items = window.TCCNotifications.all();
    var scheduled = window.TCCNotifications.scheduledCount();
    if (navBadgeCount) navBadgeCount.textContent = String(scheduled);
    if (navBadge) navBadge.hidden = scheduled === 0;

    if (!items.length) {
      body.innerHTML = '';
      if (empty) empty.hidden = false;
      return;
    }
    if (empty) empty.hidden = true;
    body.innerHTML = items.map(function (n) {
      var statusBadge = n.status === 'sent' ? '<span class="badge badge--good">Sent</span>' : '<span class="badge badge--warn">Scheduled</span>';
      var actions = n.status === 'scheduled'
        ? '<button type="button" class="btn-mini btn-mini--bad" data-cancel-ntf="' + n.id + '">Cancel</button>'
        : '<button type="button" class="btn-mini btn-mini--muted" data-remove-ntf="' + n.id + '">Delete</button>';
      return '<tr>' +
        '<td class="portal-table-ellipsis" title="' + escapeHtml(n.title) + '">' + escapeHtml(n.title) + '</td>' +
        '<td>' + escapeHtml(recipientLabel(n)) + '</td>' +
        '<td>' + (n.scheduledFor ? fmtDateTime(n.scheduledFor) : 'Immediately') + '</td>' +
        '<td>' + statusBadge + '</td>' +
        '<td class="portal-table-actions">' + actions + '</td>' +
        '</tr>';
    }).join('');
  }

  window.TCCNotifications.ready.then(render);
  render();
  window.TCCNotifications.onChange(render);
  setInterval(function () { window.TCCNotifications.checkScheduled(); }, 30000);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    window.TCCNotifications.add({
      title: document.getElementById('ntfTitle').value,
      message: document.getElementById('ntfMessage').value,
      recipientType: recipientType.value,
      recipientEmail: document.getElementById('ntfRecipientEmail').value,
      scheduledFor: document.getElementById('ntfSchedule').value
    }).then(function (result) {
      if (result.error) { toast(result.error, 'error'); return; }
      toast(result.record.status === 'sent' ? 'Notification sent' : 'Notification scheduled', 'success');
      form.reset();
      specificField.hidden = true;
    });
  });

  body.addEventListener('click', function (e) {
    var cancelId = e.target.getAttribute && e.target.getAttribute('data-cancel-ntf');
    if (cancelId) {
      window.TCCNotifications.cancel(cancelId).then(function (r) {
        toast(r ? 'Scheduled notification canceled' : 'Could not cancel that notification.', r ? 'success' : 'error');
      });
      return;
    }
    var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-ntf');
    if (removeId) {
      window.TCCNotifications.remove(removeId).then(function (deleted) {
        toast(deleted ? 'Notification removed' : 'Could not remove that notification.', deleted ? 'success' : 'error');
      });
    }
  });
})();
