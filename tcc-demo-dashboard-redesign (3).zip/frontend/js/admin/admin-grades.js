/* =========================================================================
   Admin — Grade Management (admin/dashboard.html only). Every grade a
   teacher has entered from their Gradebook (grades.js), with a Verify
   action and the ability to edit or remove any record.
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  var body = document.getElementById('gradesMgmtBody');
  if (!body || !window.TCCGrades) return;

  var empty = document.getElementById('gradesMgmtEmpty');
  var statValue = document.getElementById('gradesStatValue');
  var navBadge = document.getElementById('gradesBadge');
  var navBadgeCount = document.getElementById('gradesBadgeCount');

  // Which record (if any) is currently showing inline edit inputs instead
  // of static text — mirrors the Attendance/Feedback inline-edit pattern
  // already used elsewhere in this dashboard.
  var editingId = null;

  function standingBadge(status) {
    if (status === 'passing') return '<span class="badge badge--good">Passing</span>';
    if (status === 'failing') return '<span class="badge badge--bad">Failing</span>';
    return '<span class="badge badge--warn">Pending</span>';
  }
  function verifyBadge(adminStatus) {
    return adminStatus === 'verified'
      ? '<span class="badge badge--good">Verified</span>'
      : '<span class="badge badge--warn">Needs review</span>';
  }

  function renderRow(g) {
    var status = window.TCCGrades.computeStatus(g.midterm, g.final);

    if (editingId === g.id) {
      return '<tr data-grade-row="' + g.id + '">' +
        '<td>' + escapeHtml(g.studentName) + '</td>' +
        '<td>' + escapeHtml(g.subject) + '</td>' +
        '<td>' + escapeHtml(g.teacherName || '\u2014') + '</td>' +
        '<td><input type="text" class="portal-table-input" data-edit-field="term" value="' + escapeHtml(g.term) + '" /></td>' +
        '<td><input type="number" min="0" max="100" class="portal-table-input" data-edit-field="midterm" value="' + (g.midterm == null ? '' : g.midterm) + '" /></td>' +
        '<td><input type="number" min="0" max="100" class="portal-table-input" data-edit-field="final" value="' + (g.final == null ? '' : g.final) + '" /></td>' +
        '<td>' + standingBadge(status) + '</td>' +
        '<td>' + verifyBadge(g.adminStatus) + '</td>' +
        '<td class="portal-table-actions">' +
        '<button type="button" class="btn-mini btn-mini--good" data-save-grade="' + g.id + '">Save</button>' +
        '<button type="button" class="btn-mini btn-mini--muted" data-cancel-grade-edit="' + g.id + '">Cancel</button>' +
        '</td></tr>';
    }

    var verifyAction = g.adminStatus === 'verified'
      ? ''
      : '<button type="button" class="btn-mini btn-mini--good" data-verify-grade="' + g.id + '">Verify</button>';
    return '<tr data-grade-row="' + g.id + '">' +
      '<td>' + escapeHtml(g.studentName) + '</td>' +
      '<td>' + escapeHtml(g.subject) + '</td>' +
      '<td>' + escapeHtml(g.teacherName || '\u2014') + '</td>' +
      '<td>' + escapeHtml(g.term) + '</td>' +
      '<td>' + (g.midterm == null ? '\u2014' : g.midterm) + '</td>' +
      '<td>' + (g.final == null ? '\u2014' : g.final) + '</td>' +
      '<td>' + standingBadge(status) + '</td>' +
      '<td>' + verifyBadge(g.adminStatus) + '</td>' +
      '<td class="portal-table-actions">' + verifyAction +
      '<button type="button" class="btn-mini btn-mini--muted" data-edit-grade="' + g.id + '">Edit</button>' +
      '<button type="button" class="btn-mini btn-mini--bad" data-remove-grade-admin="' + g.id + '">Remove</button>' +
      '</td></tr>';
  }

  function render() {
    var items = window.TCCGrades.all();
    var pending = items.filter(function (g) { return g.adminStatus !== 'verified'; }).length;
    if (statValue) statValue.textContent = String(pending);
    if (navBadgeCount) navBadgeCount.textContent = String(pending);
    if (navBadge) navBadge.hidden = pending === 0;

    // A record that was deleted elsewhere (or by this admin, in another
    // tab) shouldn't leave the UI stuck in edit mode for a row that no
    // longer exists.
    if (editingId && !items.some(function (g) { return g.id === editingId; })) editingId = null;

    if (!items.length) {
      body.innerHTML = '';
      if (empty) empty.hidden = false;
      return;
    }
    if (empty) empty.hidden = true;
    body.innerHTML = items.map(renderRow).join('');
  }
  // Auto-refresh (js/core/live-poll.js) fires this on a timer; skip
  // rebuilding the table while a row is mid-edit so it doesn't wipe out
  // scores the admin has typed but not saved yet. Counts still update.
  function renderUnlessEditing() {
    if (editingId != null) return;
    render();
  }
  render();
  window.TCCGrades.onChange(renderUnlessEditing);
  window.TCCGrades.ready.then(render);

  body.addEventListener('click', function (e) {
    var editId = e.target.getAttribute && e.target.getAttribute('data-edit-grade');
    if (editId) { editingId = editId; render(); return; }

    var cancelId = e.target.getAttribute && e.target.getAttribute('data-cancel-grade-edit');
    if (cancelId) { editingId = null; render(); return; }

    var saveId = e.target.getAttribute && e.target.getAttribute('data-save-grade');
    if (saveId) {
      var row = body.querySelector('tr[data-grade-row="' + saveId + '"]');
      var termEl = row ? row.querySelector('[data-edit-field="term"]') : null;
      var midtermEl = row ? row.querySelector('[data-edit-field="midterm"]') : null;
      var finalEl = row ? row.querySelector('[data-edit-field="final"]') : null;
      var result = window.TCCGrades.update(saveId, {
        term: termEl ? termEl.value : undefined,
        midterm: midtermEl ? midtermEl.value : undefined,
        final: finalEl ? finalEl.value : undefined
      });
      result.then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        editingId = null;
        toast('Grade updated \u2014 verification reset to needs review', 'success');
        render();
      });
      return;
    }

    var verifyId = e.target.getAttribute && e.target.getAttribute('data-verify-grade');
    if (verifyId) {
      window.TCCGrades.verify(verifyId).then(function (result) {
        if (result && result.error) { toast(result.error, 'error'); return; }
        toast('Grade verified', 'success');
      });
      return;
    }

    var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-grade-admin');
    if (removeId) {
      if (editingId === removeId) editingId = null;
      window.TCCGrades.remove(removeId).then(function (deleted) {
        if (!deleted) { toast('Could not remove that grade record.', 'error'); return; }
        toast('Grade record removed', 'success');
      });
    }
  });
})();
