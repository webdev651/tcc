/* =========================================================================
   Admin — Class Schedule Management + Attendance Management
   (admin/dashboard.html only). Two related record-keeping workflows in one
   file: schedule entries (schedules.js, full CRUD) and attendance records
   (attendance.js, view/edit/generate).
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDate(ymd) {
    if (!ymd) return '\u2014';
    var d = new Date(ymd + 'T00:00:00');
    if (isNaN(d)) return ymd;
    return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  /* ---- Class schedule ---- */
  var schForm = document.getElementById('scheduleForm');
  if (schForm && window.TCCSchedules) {
    var schEditIdInput = document.getElementById('schEditId');
    var schFormTitle = document.getElementById('scheduleFormTitle');
    var schSubmitBtn = document.getElementById('schSubmitBtn');
    var schCancelBtn = document.getElementById('schCancelEdit');
    var schBody = document.getElementById('scheduleMgmtBody');
    var schEmpty = document.getElementById('scheduleMgmtEmpty');

    var schFieldIds = { subject: 'schSubject', section: 'schSection', day: 'schDay', time: 'schTime', room: 'schRoom', teacherName: 'schTeacher', term: 'schTerm' };
    function schFieldEl(key) { return document.getElementById(schFieldIds[key]); }

    function resetScheduleForm() {
      schForm.reset();
      schEditIdInput.value = '';
      schFormTitle.textContent = 'Add a schedule entry';
      schSubmitBtn.textContent = 'Add entry';
      schCancelBtn.hidden = true;
    }
    function startEditSchedule(id) {
      var record = window.TCCSchedules.all().filter(function (s) { return s.id === id; })[0];
      if (!record) return;
      schEditIdInput.value = id;
      Object.keys(schFieldIds).forEach(function (key) { var el = schFieldEl(key); if (el) el.value = record[key] || ''; });
      schFormTitle.textContent = 'Edit ' + record.subject + ' \u2014 ' + record.section;
      schSubmitBtn.textContent = 'Save changes';
      schCancelBtn.hidden = false;
      schForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function renderSchedule() {
      var items = window.TCCSchedules.all();
      if (!items.length) {
        schBody.innerHTML = '';
        if (schEmpty) schEmpty.hidden = false;
        return;
      }
      if (schEmpty) schEmpty.hidden = true;
      schBody.innerHTML = items.map(function (s) {
        return '<tr>' +
          '<td>' + escapeHtml(s.subject) + '</td>' +
          '<td>' + escapeHtml(s.section) + '</td>' +
          '<td>' + escapeHtml(s.day) + '</td>' +
          '<td>' + escapeHtml(s.time) + '</td>' +
          '<td>' + escapeHtml(s.room || '\u2014') + '</td>' +
          '<td>' + escapeHtml(s.teacherName || '\u2014') + '</td>' +
          '<td class="portal-table-actions">' +
          '<button type="button" class="btn-mini btn-mini--muted" data-edit-schedule="' + s.id + '">Edit</button>' +
          '<button type="button" class="btn-mini btn-mini--bad" data-remove-schedule="' + s.id + '">Delete</button>' +
          '</td></tr>';
      }).join('');
    }
    renderSchedule();
    window.TCCSchedules.onChange(renderSchedule);
    window.TCCSchedules.ready.then(renderSchedule);

    schForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var data = {};
      Object.keys(schFieldIds).forEach(function (key) { var el = schFieldEl(key); if (el) data[key] = el.value; });
      var editId = schEditIdInput.value;
      var action = editId ? window.TCCSchedules.update(editId, data) : window.TCCSchedules.add(data);
      action.then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast(editId ? 'Schedule entry updated' : 'Schedule entry added', 'success');
        resetScheduleForm();
        renderSchedule();
      });
    });
    schCancelBtn.addEventListener('click', resetScheduleForm);
    schBody.addEventListener('click', function (e) {
      var editId = e.target.getAttribute && e.target.getAttribute('data-edit-schedule');
      if (editId) { startEditSchedule(editId); return; }
      var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-schedule');
      if (removeId) {
        window.TCCSchedules.remove(removeId).then(function (deleted) {
          if (!deleted) { toast('Could not remove that schedule entry.', 'error'); return; }
          toast('Schedule entry removed', 'success');
          if (schEditIdInput.value === removeId) resetScheduleForm();
        });
      }
    });
  }

  /* ---- Attendance ---- */
  var genForm = document.getElementById('generateAttendanceForm');
  var attBody = document.getElementById('attendanceMgmtBody');
  if (attBody && window.TCCAttendance) {
    var attEmpty = document.getElementById('attendanceMgmtEmpty');

    function statusBadge(status) {
      if (status === 'Present') return '<span class="badge badge--good">Present</span>';
      if (status === 'Late') return '<span class="badge badge--warn">Late</span>';
      return '<span class="badge badge--bad">Absent</span>';
    }

    function renderAttendance() {
      var items = window.TCCAttendance.all();
      if (!items.length) {
        attBody.innerHTML = '';
        if (attEmpty) attEmpty.hidden = false;
        return;
      }
      if (attEmpty) attEmpty.hidden = true;
      attBody.innerHTML = items.map(function (a) {
        return '<tr data-attendance-row="' + a.id + '">' +
          '<td>' + escapeHtml(a.studentName) + '</td>' +
          '<td>' + escapeHtml(a.subject) + '</td>' +
          '<td>' + fmtDate(a.date) + '</td>' +
          '<td>' +
          '<select class="portal-table-select" data-attendance-status="' + a.id + '">' +
          ['Present', 'Late', 'Absent'].map(function (opt) { return '<option' + (a.status === opt ? ' selected' : '') + '>' + opt + '</option>'; }).join('') +
          '</select></td>' +
          '<td class="portal-table-ellipsis" title="' + escapeHtml(a.remarks || '') + '">' + escapeHtml(a.remarks || '\u2014') + '</td>' +
          '<td class="portal-table-actions"><button type="button" class="btn-mini btn-mini--bad" data-remove-attendance="' + a.id + '">Delete</button></td>' +
          '</tr>';
      }).join('');
    }
    renderAttendance();
    window.TCCAttendance.onChange(renderAttendance);
    window.TCCAttendance.ready.then(renderAttendance);

    attBody.addEventListener('change', function (e) {
      var id = e.target.getAttribute && e.target.getAttribute('data-attendance-status');
      if (!id) return;
      window.TCCAttendance.update(id, { status: e.target.value }).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast('Attendance status updated', 'success');
      });
    });
    attBody.addEventListener('click', function (e) {
      var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-attendance');
      if (removeId) {
        window.TCCAttendance.remove(removeId).then(function (deleted) {
          if (!deleted) { toast('Could not remove that attendance record.', 'error'); return; }
          toast('Attendance record removed', 'success');
        });
      }
    });
  }

  if (genForm && window.TCCAttendance) {
    genForm.addEventListener('submit', function (e) {
      e.preventDefault();
      window.TCCAttendance.generateForClass(
        document.getElementById('genSubject').value,
        document.getElementById('genDate').value,
        document.getElementById('genStatus').value,
        document.getElementById('genRemarks').value
      ).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast('Generated ' + result.created + ' attendance record' + (result.created === 1 ? '' : 's'), 'success');
        genForm.reset();
      });
    });
  }
})();
