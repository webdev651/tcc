/* =========================================================================
   Admin — Overview stats (admin/dashboard.html only). Replaces the
   hardcoded demo numbers (612 students, 34 staff, 4 programs…) with real
   counts pulled from GET /api/admin/students and GET /api/admin/teachers.

   "Degree programs" has no dedicated table in the schema — a student's
   program is free text (student_profiles.program, falling back to
   users.detail — see admin.js GET /students). So the program count and
   the "Enrollment by program" chart are both derived by grouping students
   on that free-text value. Students with no program on file are counted
   separately ("No program on file") rather than silently dropped, so the
   total always adds up to the real enrolled count.

   Guarded by element presence — no-op on any page without these cards.
   ========================================================================= */
(function () {
  if (!window.TCCApi) return;
  var api = window.TCCApi;

  var enrolledValue = document.getElementById('ovEnrolledValue');
  if (!enrolledValue) return; // not on this page

  var enrolledDetail = document.getElementById('ovEnrolledDetail');
  var staffValue = document.getElementById('ovStaffValue');
  var staffDetail = document.getElementById('ovStaffDetail');
  var programsValue = document.getElementById('ovProgramsValue');
  var chartCaption = document.getElementById('ovChartCaption');
  var chartEl = document.getElementById('ovProgramChart');
  var chartEmpty = document.getElementById('ovProgramChartEmpty');

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function renderChart(students) {
    if (!chartEl) return;
    var counts = {}; // normalized(lowercase, trimmed) -> { label, count }
    var noProgram = 0;
    students.forEach(function (s) {
      var raw = String(s.program || '').trim();
      if (!raw) { noProgram++; return; }
      var key = raw.toLowerCase();
      if (!counts[key]) counts[key] = { label: raw, count: 0 };
      counts[key].count++;
    });

    var bars = Object.keys(counts).map(function (k) { return counts[k]; })
      .sort(function (a, b) { return b.count - a.count; });

    if (chartCaption) chartCaption.textContent = students.length + ' student' + (students.length === 1 ? '' : 's');

    if (!bars.length) {
      chartEl.innerHTML = '';
      chartEl.setAttribute('aria-label', 'Enrollment by degree program — no data');
      if (chartEmpty) chartEmpty.hidden = false;
      return;
    }
    if (chartEmpty) chartEmpty.hidden = true;

    var max = bars[0].count || 1;
    var ariaLabel = 'Enrollment by degree program — ' + bars.map(function (b) { return b.label + ' ' + b.count; }).join(', ');
    if (noProgram) ariaLabel += ', No program on file ' + noProgram;
    chartEl.setAttribute('aria-label', ariaLabel);

    var html = bars.map(function (b) {
      var pct = Math.round((b.count / max) * 100);
      return '<div class="portal-chart-col">' +
        '<span class="portal-chart-value">' + b.count + '</span>' +
        '<div class="portal-chart-track"><div class="portal-chart-fill" style="height:' + pct + '%;"></div></div>' +
        '<span class="portal-chart-label">' + escapeHtml(b.label) + '</span>' +
        '</div>';
    }).join('');
    if (noProgram) {
      var noPct = Math.round((noProgram / max) * 100);
      html += '<div class="portal-chart-col">' +
        '<span class="portal-chart-value">' + noProgram + '</span>' +
        '<div class="portal-chart-track"><div class="portal-chart-fill" style="height:' + noPct + '%;"></div></div>' +
        '<span class="portal-chart-label">No program</span>' +
        '</div>';
    }
    chartEl.innerHTML = html;

    if (programsValue) programsValue.textContent = String(bars.length);
  }

  function load() {
    if (!api.getToken()) return;
    api.get('/admin/students')
      .then(function (data) {
        var students = data.students || [];
        enrolledValue.textContent = String(students.length);
        var distinctPrograms = {};
        students.forEach(function (s) {
          var p = String(s.program || '').trim().toLowerCase();
          if (p) distinctPrograms[p] = true;
        });
        var programCount = Object.keys(distinctPrograms).length;
        if (enrolledDetail) enrolledDetail.textContent = programCount ? ('Across ' + programCount + ' degree program' + (programCount === 1 ? '' : 's')) : 'No program data on file';
        renderChart(students);
      })
      .catch(function () {
        enrolledValue.textContent = '\u2014';
        if (enrolledDetail) enrolledDetail.textContent = 'Could not load';
      });

    api.get('/admin/teachers')
      .then(function (data) {
        var teachers = data.teachers || [];
        if (staffValue) staffValue.textContent = String(teachers.length);
        var distinctDepts = {};
        teachers.forEach(function (t) {
          var d = String(t.department || '').trim().toLowerCase();
          if (d) distinctDepts[d] = true;
        });
        var deptCount = Object.keys(distinctDepts).length;
        if (staffDetail) staffDetail.textContent = deptCount ? (deptCount + ' department' + (deptCount === 1 ? '' : 's')) : 'No department data on file';
      })
      .catch(function () {
        if (staffValue) staffValue.textContent = '\u2014';
        if (staffDetail) staffDetail.textContent = 'Could not load';
      });
  }

  load();
  // Same refresh triggers admin-all-students.js already uses — new
  // approvals/rejections or profile edits change these counts.
  window.addEventListener('tcc-accounts:changed', load);
  window.addEventListener('tcc-profiles:changed', load);

  /* =========================================================================
     Overview cards below the stat row — "Pending registrations", "Teaching
     staff" and "College-wide announcements" used to be static placeholder
     rows in the markup. Wired here to the same data layers the rest of the
     app already loads on this page (js/modules/registrations.js,
     js/modules/announcements.js, GET /admin/teachers — same endpoint the
     stat card above already calls), so nothing here is invented data.
     Each block is independently guarded by its own container id.
     ========================================================================= */
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function timeAgo(iso) {
    if (!iso) return '\u2014';
    var then = new Date(iso).getTime();
    if (isNaN(then)) return '\u2014';
    var diff = Math.max(0, Date.now() - then);
    var days = Math.floor(diff / 86400000);
    if (days < 1) return 'today';
    if (days === 1) return '1 day ago';
    if (days < 7) return days + ' days ago';
    var weeks = Math.floor(days / 7);
    if (weeks < 5) return weeks + ' week' + (weeks === 1 ? '' : 's') + ' ago';
    return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  // ---- Pending registrations (latest 4, most recent first) ----
  var regList = document.getElementById('ovPendingRegList');
  var regEmpty = document.getElementById('ovPendingRegEmpty');
  if (regList && window.TCCRegistrations) {
    var renderRegistrations = function () {
      var rows = window.TCCRegistrations.all().slice(0, 4);
      if (!rows.length) {
        regList.innerHTML = '';
        if (regEmpty) regEmpty.hidden = false;
        return;
      }
      if (regEmpty) regEmpty.hidden = true;
      regList.innerHTML = rows.map(function (r) {
        var cls = r.status === 'approved' ? 'good' : r.status === 'rejected' ? 'bad' : 'warn';
        var label = r.status === 'approved' ? 'Approved' : r.status === 'rejected' ? 'Rejected' : 'Review';
        return '<div class="portal-row">' +
          '<div class="portal-row-main"><b>' + escapeHtml(r.studentName || 'Unnamed student') + '</b><span>' + escapeHtml(r.term || 'No term set') + (r.type ? ' \u00b7 ' + escapeHtml(r.type) : '') + '</span></div>' +
          '<div class="portal-row-meta"><span class="badge badge--' + cls + '">' + label + '</span></div>' +
          '</div>';
      }).join('');
    };
    renderRegistrations();
    window.TCCRegistrations.onChange(renderRegistrations);
    window.TCCRegistrations.ready.then(renderRegistrations);
  }

  // ---- Teaching staff (latest 4, from the same /admin/teachers list the
  //      stat card above already fetches) ----
  var staffList = document.getElementById('ovTeachingStaffList');
  var staffEmpty = document.getElementById('ovTeachingStaffEmpty');
  if (staffList) {
    api.get('/admin/teachers').then(function (data) {
      var teachers = (data.teachers || []).slice(0, 4);
      if (!teachers.length) {
        staffList.innerHTML = '';
        if (staffEmpty) staffEmpty.hidden = false;
        return;
      }
      if (staffEmpty) staffEmpty.hidden = true;
      staffList.innerHTML = teachers.map(function (t) {
        var name = t.name || t.email || 'Unnamed';
        return '<div class="portal-row">' +
          '<div class="portal-row-main"><b>' + escapeHtml(name) + '</b><span>' + escapeHtml(t.department || 'No department on file') + '</span></div>' +
          '<div class="portal-row-meta"><a href="#staff">View</a></div>' +
          '</div>';
      }).join('');
    }).catch(function () {
      if (staffEmpty) { staffEmpty.hidden = false; staffEmpty.textContent = 'Could not load staff.'; }
    });
  }

  // ---- College-wide announcements (audience "all", posted by admin) ----
  var annList = document.getElementById('ovCollegeAnnList');
  var annEmpty = document.getElementById('ovCollegeAnnEmpty');
  if (annList && window.TCCAnnouncements) {
    var renderCollegeAnn = function () {
      var rows = window.TCCAnnouncements.all()
        .filter(function (a) { return a.audience === 'all'; })
        .slice(0, 3);
      if (!rows.length) {
        annList.innerHTML = '';
        if (annEmpty) annEmpty.hidden = false;
        return;
      }
      if (annEmpty) annEmpty.hidden = true;
      annList.innerHTML = rows.map(function (a) {
        return '<div class="portal-row">' +
          '<div class="portal-row-main"><b>' + escapeHtml(a.title) + '</b><span>All programs \u00b7 ' + escapeHtml(a.postedByName || 'Admin') + '</span></div>' +
          '<div class="portal-row-meta">' + timeAgo(a.postedAt) + '</div>' +
          '</div>';
      }).join('');
    };
    renderCollegeAnn();
    window.TCCAnnouncements.onChange(renderCollegeAnn);
    window.TCCAnnouncements.ready.then(renderCollegeAnn);
  }
})();
