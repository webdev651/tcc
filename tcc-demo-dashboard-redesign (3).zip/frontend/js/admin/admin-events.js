/* =========================================================================
   Feature 4 — Admin Events management (admin/dashboard.html only).
   Add/edit/delete the calendar entries that feed the Upcoming Events
   widget (js/core/upcoming-events.js) on every dashboard. Same
   add/edit/cancel form pattern as js/admin/admin-content.js's
   announcement manager — guarded by element presence, so this file is a
   no-op if loaded anywhere else.
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDateTime(iso) {
    var d = new Date(iso);
    if (isNaN(d)) return '\u2014';
    return d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  }
  // <input type="datetime-local"> wants "YYYY-MM-DDTHH:mm" in *local*
  // time with no timezone suffix — new Date(iso).toISOString() would
  // shift it to UTC and silently show the wrong time back to the admin
  // when editing, so this builds the local string by hand instead.
  function toLocalInputValue(iso) {
    var d = new Date(iso);
    if (isNaN(d)) return '';
    var pad = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  var TYPE_LABELS = {
    announcement: 'Important announcement',
    registration_deadline: 'Registration deadline',
    enrollment_deadline: 'Enrollment deadline',
    academic_deadline: 'Academic deadline',
    school_event: 'School event',
    activity: 'Scheduled activity',
    exam: 'Exam'
  };
  function audienceTag(audience) {
    if (audience === 'student') return 'Students only';
    if (audience === 'teacher') return 'Staff only';
    return 'Everyone';
  }

  var form = document.getElementById('eventForm');
  if (!form || !window.TCCEvents) return; // not on this page

  var listEl = document.getElementById('adminEventsList');
  var emptyEl = document.getElementById('adminEventsEmpty');
  var editIdInput = document.getElementById('evEditId');
  var formTitle = document.getElementById('eventFormTitle');
  var submitBtn = document.getElementById('evSubmitBtn');
  var cancelBtn = document.getElementById('evCancelEdit');
  var titleInput = document.getElementById('evTitle');
  var typeInput = document.getElementById('evType');
  var dateInput = document.getElementById('evDate');
  var descInput = document.getElementById('evDescription');

  function resetForm() {
    form.reset();
    editIdInput.value = '';
    formTitle.textContent = 'Add an event';
    submitBtn.textContent = 'Add event';
    cancelBtn.hidden = true;
  }
  function startEdit(id) {
    var record = window.TCCEvents.all().filter(function (e) { return e.id === id; })[0];
    if (!record) return;
    editIdInput.value = id;
    titleInput.value = record.title;
    typeInput.value = record.type;
    dateInput.value = toLocalInputValue(record.eventDate);
    descInput.value = record.description || '';
    var radio = form.querySelector('input[name="evAudience"][value="' + record.audience + '"]');
    if (radio) radio.checked = true;
    formTitle.textContent = 'Edit event';
    submitBtn.textContent = 'Save changes';
    cancelBtn.hidden = false;
    form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function render() {
    if (!listEl) return;
    var items = window.TCCEvents.all();
    if (!items.length) {
      listEl.innerHTML = '';
      if (emptyEl) emptyEl.hidden = false;
      return;
    }
    if (emptyEl) emptyEl.hidden = true;
    var now = new Date();
    listEl.innerHTML = items.map(function (e) {
      var isPast = new Date(e.eventDate) < now;
      var label = TYPE_LABELS[e.type] || e.type;
      return '<div class="portal-row">' +
        '<div class="portal-row-main"><b>' + escapeHtml(e.title) + (isPast ? ' <span class="badge badge--muted">Past</span>' : '') + '</b>' +
        '<span>' + escapeHtml(label) + ' \u00b7 ' + audienceTag(e.audience) + '</span>' +
        (e.description ? '<span>' + escapeHtml(e.description) + '</span>' : '') + '</div>' +
        '<div class="portal-row-meta">' + fmtDateTime(e.eventDate) +
        '<br /><a href="#" data-edit-event="' + e.id + '">Edit</a> &middot; <a href="#" data-remove-event="' + e.id + '">Delete</a></div>' +
        '</div>';
    }).join('');
  }
  render();
  window.TCCEvents.onChange(render);
  window.TCCEvents.ready.then(render);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var audienceInput = form.querySelector('input[name="evAudience"]:checked');
    var editId = editIdInput.value;
    var payload = {
      title: titleInput.value,
      type: typeInput.value,
      eventDate: dateInput.value, // "YYYY-MM-DDTHH:mm" local — new Date() on the backend parses this as local time
      description: descInput.value,
      audience: audienceInput ? audienceInput.value : 'all'
    };
    var action = editId ? window.TCCEvents.update(editId, payload) : window.TCCEvents.add(payload);
    action.then(function (result) {
      if (result.error) { toast(result.error, 'error'); return; }
      toast(editId ? 'Event updated' : 'Event added', 'success');
      resetForm();
    });
  });
  cancelBtn.addEventListener('click', resetForm);

  if (listEl) {
    listEl.addEventListener('click', function (e) {
      var editId = e.target.getAttribute && e.target.getAttribute('data-edit-event');
      if (editId) { e.preventDefault(); startEdit(editId); return; }
      var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-event');
      if (removeId) {
        e.preventDefault();
        window.TCCEvents.remove(removeId).then(function (deleted) {
          if (!deleted) { toast('Could not remove that event.', 'error'); return; }
          toast('Event removed', 'success');
          if (editIdInput.value === removeId) resetForm();
        });
      }
    });
  }
})();
