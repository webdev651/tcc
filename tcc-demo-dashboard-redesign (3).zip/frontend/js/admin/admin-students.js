/* =========================================================================
   Admin — Student Profile Management (admin/dashboard.html only).
   View/add/edit/delete records from profiles.js. Guarded by element
   presence, same convention as the rest of the admin-*.js files.
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  var form = document.getElementById('studentProfileForm');
  if (!form || !window.TCCProfiles) return;

  var editIdInput = document.getElementById('stuEditId');
  var formTitle = document.getElementById('studentFormTitle');
  var submitBtn = document.getElementById('stuSubmitBtn');
  var cancelBtn = document.getElementById('stuCancelEdit');
  var body = document.getElementById('studentsBody');
  var empty = document.getElementById('studentsEmpty');

  var fieldIds = { name: 'stuName', email: 'stuEmail', studentId: 'stuId', program: 'stuProgram', yearLevel: 'stuYear', section: 'stuSection', status: 'stuStatus', mobile: 'stuMobile', adviser: 'stuAdviser' };
  function fieldEl(key) { return document.getElementById(fieldIds[key]); }

  function resetForm() {
    form.reset();
    editIdInput.value = '';
    formTitle.textContent = 'Add a student';
    submitBtn.textContent = 'Add student';
    cancelBtn.hidden = true;
  }

  function startEdit(id) {
    var record = window.TCCProfiles.all().filter(function (s) { return s.id === id; })[0];
    if (!record) return;
    editIdInput.value = id;
    Object.keys(fieldIds).forEach(function (key) { var el = fieldEl(key); if (el) el.value = record[key] || ''; });
    formTitle.textContent = 'Edit ' + record.name;
    submitBtn.textContent = 'Save changes';
    cancelBtn.hidden = false;
    form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function render() {
    var items = window.TCCProfiles.all();
    if (!items.length) {
      body.innerHTML = '';
      if (empty) empty.hidden = false;
      return;
    }
    if (empty) empty.hidden = true;
    body.innerHTML = items.map(function (s) {
      var statusBadge = s.status === 'Regular' ? 'badge--good' : s.status === 'Inactive' ? 'badge--bad' : 'badge--warn';
      return '<tr>' +
        '<td>' + escapeHtml(s.name) + '</td>' +
        '<td class="portal-table-ellipsis portal-table-ellipsis--email" title="' + escapeHtml(s.email) + '">' + escapeHtml(s.email) + '</td>' +
        '<td>' + escapeHtml(s.program || '\u2014') + '</td>' +
        '<td>' + escapeHtml((s.yearLevel || '\u2014') + (s.section ? ' \u00b7 ' + s.section : '')) + '</td>' +
        '<td><span class="badge ' + statusBadge + '">' + escapeHtml(s.status || 'Regular') + '</span></td>' +
        '<td class="portal-table-actions">' +
        '<button type="button" class="btn-mini btn-mini--muted" data-edit-student="' + s.id + '">Edit</button>' +
        '<button type="button" class="btn-mini btn-mini--bad" data-remove-student="' + s.id + '">Delete</button>' +
        '</td></tr>';
    }).join('');
  }
  render();
  window.TCCProfiles.onChange(render);
  window.TCCProfiles.ready.then(render);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var data = {};
    Object.keys(fieldIds).forEach(function (key) { var el = fieldEl(key); if (el) data[key] = el.value; });
    var editId = editIdInput.value;
    var action = editId ? window.TCCProfiles.update(editId, data) : window.TCCProfiles.add(data);
    action.then(function (result) {
      if (result.error) { toast(result.error, 'error'); return; }
      toast(editId ? 'Student profile updated' : 'Student added', 'success');
      resetForm();
      render();
    });
  });

  cancelBtn.addEventListener('click', resetForm);

  body.addEventListener('click', function (e) {
    var editId = e.target.getAttribute && e.target.getAttribute('data-edit-student');
    if (editId) { startEdit(editId); return; }
    var removeId = e.target.getAttribute && e.target.getAttribute('data-remove-student');
    if (removeId) {
      window.TCCProfiles.remove(removeId).then(function (deleted) {
        if (!deleted) { toast('Could not remove that student profile.', 'error'); return; }
        toast('Student profile removed', 'success');
        if (editIdInput.value === removeId) resetForm();
      });
    }
  });
})();
