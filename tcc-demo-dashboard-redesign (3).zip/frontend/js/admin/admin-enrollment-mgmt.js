/* =========================================================================
   Admin — Student Registration Management + Subject Enrollment Management
   (admin/dashboard.html only). Two related review/approve workflows in one
   file: term registration requests (registrations.js) and subject
   enrollment requests + direct assignment (enrollments.js).
   ========================================================================= */
(function () {
  var toastRoot = document.getElementById('toast-root');
  function toast(message, variant) {
    if (!toastRoot) return;
    var el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 3500);
  }
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDate(iso) {
    if (!iso) return '—';
    var d = new Date(iso);
    if (isNaN(d)) return '—';
    return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }
  function statusBadge(status) {
    if (status === 'approved') return '<span class="badge badge--good">Approved</span>';
    if (status === 'rejected') return '<span class="badge badge--bad">Rejected</span>';
    return '<span class="badge badge--warn">Pending</span>';
  }

  /* ---- Registrations ---- */
  var regBody = document.getElementById('registrationsBody');
  if (regBody && window.TCCRegistrations) {
    var regEmpty = document.getElementById('registrationsEmpty');
    var regStatValue = document.getElementById('regStatValue');
    var regNavBadge = document.getElementById('regBadge');
    var regNavBadgeCount = document.getElementById('regBadgeCount');

    function renderRegistrations() {
      var items = window.TCCRegistrations.all();
      var pending = window.TCCRegistrations.pendingCount();
      if (regStatValue) regStatValue.textContent = String(pending);
      if (regNavBadgeCount) regNavBadgeCount.textContent = String(pending);
      if (regNavBadge) regNavBadge.hidden = pending === 0;

      if (!items.length) {
        regBody.innerHTML = '';
        if (regEmpty) regEmpty.hidden = false;
        return;
      }
      if (regEmpty) regEmpty.hidden = true;
      regBody.innerHTML = items.map(function (r) {
        var actions = r.status === 'pending'
          ? '<button type="button" class="btn-mini btn-mini--good" data-approve-reg="' + r.id + '">Approve</button>' +
            '<button type="button" class="btn-mini btn-mini--bad" data-reject-reg="' + r.id + '">Reject</button>'
          : '\u2014';
        return '<tr>' +
          '<td>' + escapeHtml(r.studentName) + '</td>' +
          '<td>' + escapeHtml(r.term) + '</td>' +
          '<td>' + escapeHtml(r.yearLevel || '\u2014') + '</td>' +
          '<td>' + escapeHtml(r.type) + '</td>' +
          '<td>' + fmtDate(r.submittedAt) + '</td>' +
          '<td>' + statusBadge(r.status) + '</td>' +
          '<td class="portal-table-actions">' + actions + '</td>' +
          '</tr>';
      }).join('');
    }
    renderRegistrations();
    window.TCCRegistrations.onChange(renderRegistrations);
    window.TCCRegistrations.ready.then(renderRegistrations);

    regBody.addEventListener('click', function (e) {
      var approveId = e.target.getAttribute && e.target.getAttribute('data-approve-reg');
      var rejectId = e.target.getAttribute && e.target.getAttribute('data-reject-reg');
      if (approveId) {
        window.TCCRegistrations.approve(approveId).then(function (r) {
          toast(r ? 'Registration approved' : 'Could not approve that registration.', r ? 'success' : 'error');
        });
      }
      if (rejectId) {
        window.TCCRegistrations.reject(rejectId).then(function (r) {
          toast(r ? 'Registration rejected' : 'Could not reject that registration.', r ? 'success' : 'error');
        });
      }
    });
  }

  /* ---- Subject enrollment ---- */
  var assignForm = document.getElementById('assignSubjectForm');
  var enrBody = document.getElementById('enrollmentsBody');
  if (enrBody && window.TCCEnrollments) {
    var enrEmpty = document.getElementById('enrollmentsEmpty');
    var enrStatValue = document.getElementById('enrStatValue');
    var enrNavBadge = document.getElementById('enrBadge');
    var enrNavBadgeCount = document.getElementById('enrBadgeCount');

    function subjectsLabel(subjects) {
      return (subjects || []).map(function (s) { return s.name + (s.code ? ' (' + s.code + ')' : ''); }).join(', ');
    }

    function renderEnrollments() {
      var items = window.TCCEnrollments.all();
      var pending = window.TCCEnrollments.pendingCount();
      if (enrStatValue) enrStatValue.textContent = String(pending);
      if (enrNavBadgeCount) enrNavBadgeCount.textContent = String(pending);
      if (enrNavBadge) enrNavBadge.hidden = pending === 0;

      if (!items.length) {
        enrBody.innerHTML = '';
        if (enrEmpty) enrEmpty.hidden = false;
        return;
      }
      if (enrEmpty) enrEmpty.hidden = true;
      enrBody.innerHTML = items.map(function (r) {
        var actions = r.status === 'pending'
          ? '<button type="button" class="btn-mini btn-mini--good" data-approve-enr="' + r.id + '">Approve</button>' +
            '<button type="button" class="btn-mini btn-mini--bad" data-reject-enr="' + r.id + '">Reject</button>'
          : '\u2014';
        return '<tr>' +
          '<td>' + escapeHtml(r.studentName) + '</td>' +
          '<td class="portal-table-ellipsis" title="' + escapeHtml(subjectsLabel(r.subjects)) + '">' + escapeHtml(subjectsLabel(r.subjects)) + '</td>' +
          '<td>' + (r.totalUnits || 0) + '</td>' +
          '<td>' + (r.source === 'assigned' ? 'Assigned by admin' : 'Student request') + '</td>' +
          '<td>' + statusBadge(r.status) + '</td>' +
          '<td class="portal-table-actions">' + actions + '</td>' +
          '</tr>';
      }).join('');
    }
    renderEnrollments();
    window.TCCEnrollments.onChange(renderEnrollments);
    window.TCCEnrollments.ready.then(renderEnrollments);

    enrBody.addEventListener('click', function (e) {
      var approveId = e.target.getAttribute && e.target.getAttribute('data-approve-enr');
      var rejectId = e.target.getAttribute && e.target.getAttribute('data-reject-enr');
      if (approveId) {
        window.TCCEnrollments.approve(approveId).then(function (r) {
          toast(r ? 'Enrollment approved' : 'Could not approve that enrollment.', r ? 'success' : 'error');
        });
      }
      if (rejectId) {
        window.TCCEnrollments.reject(rejectId).then(function (r) {
          toast(r ? 'Enrollment rejected' : 'Could not reject that enrollment.', r ? 'success' : 'error');
        });
      }
    });
  }

  if (assignForm && window.TCCEnrollments) {
    assignForm.addEventListener('submit', function (e) {
      e.preventDefault();
      window.TCCEnrollments.assign({
        studentName: document.getElementById('asStudentName').value,
        studentEmail: document.getElementById('asStudentEmail').value,
        code: document.getElementById('asCode').value,
        name: document.getElementById('asName').value,
        units: document.getElementById('asUnits').value,
        term: document.getElementById('asTerm').value
      }).then(function (result) {
        if (result.error) { toast(result.error, 'error'); return; }
        toast('Subject assigned to ' + result.record.studentName, 'success');
        assignForm.reset();
      });
    });
  }
})();
