/* =========================================================================
   Admin dashboard — Approvals tab.
   Renders self-registered student/teacher account requests (see
   ../accounts.js / ../signup.html) and lets the admin approve or reject
   them. Approving flips the account to "approved" so it can sign in on
   login.html; rejecting blocks it. Still backend-free — everything lives
   in localStorage until a real API replaces accounts.js.
   ========================================================================= */
(function () {
  if (!window.TCCAccounts) return;

  const tbody = document.getElementById('approvalsBody');
  const emptyState = document.getElementById('approvalsEmpty');
  const statEl = document.getElementById('pendingStatValue');
  const navBadge = document.getElementById('pendingBadge');
  const navBadgeCount = document.getElementById('pendingBadgeCount');
  const toastRoot = document.getElementById('toast-root');

  if (!tbody) return;

  // Two mutually-exclusive inline states, shown as an expanded row under
  // the account they belong to. Neither is ever persisted — both are
  // display-only and disappear on refresh.
  //   composerId   — "Reset password" was clicked; showing the New
  //                  password / Confirm fields, not yet submitted.
  //   revealedReset — submitted successfully; showing the password that
  //                  was just set so the admin can copy it before closing.
  let composerId = null; // string | null
  let revealedReset = null; // { id, name, email, newPassword } | null

  function toast(message, variant) {
    if (!toastRoot) return;
    const el = document.createElement('div');
    el.className = 'toast' + (variant ? ' toast--' + variant : '');
    el.textContent = message;
    toastRoot.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }

  function fmtDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d)) return '—';
    return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  function badge(status) {
    if (status === 'approved') return '<span class="badge badge--good">Approved</span>';
    if (status === 'rejected') return '<span class="badge badge--bad">Rejected</span>';
    return '<span class="badge badge--warn">Pending</span>';
  }

  function render() {
    const accounts = window.TCCAccounts.all();
    const pendingCount = accounts.filter((a) => a.status === 'pending').length;

    if (statEl) statEl.textContent = String(pendingCount);
    if (navBadgeCount) navBadgeCount.textContent = String(pendingCount);
    if (navBadge) navBadge.hidden = pendingCount === 0;

    // The table gets rebuilt from scratch on every render, including the
    // background poll that runs every few seconds (see live-poll.js) so
    // new sign-ups show up live. Without this, that poll would wipe out
    // whatever the admin is mid-typing into the reset-password composer.
    // Snapshot it here and put it back after the rebuild below.
    const composerSnapshot = captureComposerState();

    if (!accounts.length) {
      tbody.innerHTML = '';
      if (emptyState) {
        const s = window.TCCAccounts.getStatus();
        emptyState.textContent = s.authError
          ? 'Signed in, but not authorized as admin in this tab (often caused by logging into a different role in another tab). Log out and sign back in as admin.'
          : (s.connected && s.backendReachable === false)
            ? 'Couldn\u2019t reach the backend server' + (s.error ? ' (' + s.error + ')' : '') + '. Make sure it\u2019s running (npm start in /backend), then this will refresh on its own.'
            : 'No account requests yet. They\u2019ll show up here as soon as someone signs up.';
        emptyState.hidden = false;
      }
      return;
    }
    if (emptyState) emptyState.hidden = true;

    tbody.innerHTML = accounts.map((a) => {
      const row = `
      <tr>
        <td>${escapeHtml(a.name)}</td>
        <td class="portal-table-ellipsis portal-table-ellipsis--email" title="${escapeHtml(a.email)}">${escapeHtml(a.email)}</td>
        <td>${a.role === 'teacher' ? 'Teacher' : 'Student'}</td>
        <td>${a.role === 'teacher' ? '—' : escapeHtml(a.studentId || '—')}</td>
        <td class="portal-table-ellipsis" title="${escapeHtml(a.detail || '')}">${escapeHtml(a.detail || '—')}</td>
        <td>${fmtDate(a.requestedAt)}</td>
        <td>${badge(a.status)}</td>
        <td class="portal-table-actions">
          ${a.status === 'pending'
            ? `<button type="button" class="btn-mini btn-mini--good" data-approve="${a.id}">Approve</button>
               <button type="button" class="btn-mini btn-mini--bad" data-reject="${a.id}">Reject</button>`
            : a.status === 'approved'
              ? `<button type="button" class="btn-mini btn-mini--muted" data-reset="${a.id}">Reset password</button>`
              : '<span class="portal-row-meta">Decided ' + fmtDate(a.decidedAt) + '</span>'}
        </td>
      </tr>`;

      // Composer — "Reset password" was just clicked; let the admin type
      // the new password rather than having one generated for them.
      if (composerId && String(composerId) === String(a.id)) {
        return row + `
      <tr class="reset-password-row">
        <td colspan="8">
          <p>Set a new password for <b>${escapeHtml(a.name)}</b> (${escapeHtml(a.email)}). They'll need it to sign in, so send it to them yourself once it's set.</p>
          <div class="reset-password-value">
            <input type="text" placeholder="New password" data-reset-new autocomplete="new-password" />
            <input type="text" placeholder="Confirm password" data-reset-confirm autocomplete="new-password" />
          </div>
          <div class="reset-password-actions">
            <button type="button" class="btn-mini btn-mini--good" data-submit-reset="${a.id}">Set password</button>
            <button type="button" class="btn-mini btn-mini--muted" data-cancel-reset>Cancel</button>
          </div>
        </td>
      </tr>`;
      }

      if (!revealedReset || String(revealedReset.id) !== String(a.id)) return row;

      // Inline reveal — same "expand under the row" convention as the
      // Feedback respond panel, not a modal. Shown once; gone on the next
      // render triggered by Close, another action, or a page reload.
      const reset = revealedReset;
      return row + `
      <tr class="reset-password-row">
        <td colspan="8">
          <p>Password updated for <b>${escapeHtml(reset.name)}</b> (${escapeHtml(reset.email)}) — copy it now and send it to them. It won\u2019t be shown again; they should sign in and change it.</p>
          <div class="reset-password-value">
            <input type="text" readonly value="${escapeHtml(reset.newPassword)}" data-reset-value onclick="this.select()" />
            <button type="button" class="btn-mini btn-mini--good" data-copy-reset>Copy</button>
          </div>
          <div class="reset-password-actions">
            <button type="button" class="btn-mini btn-mini--muted" data-close-reset>Close</button>
          </div>
        </td>
      </tr>`;
    }).join('');

    restoreComposerState(composerSnapshot);
  }

  // ---- Reset-password composer state preservation across re-renders -------
  function captureComposerState() {
    if (!composerId) return null;
    const newInput = tbody.querySelector('[data-reset-new]');
    const confirmInput = tbody.querySelector('[data-reset-confirm]');
    if (!newInput && !confirmInput) return null;
    const active = document.activeElement;
    const focused = active === newInput ? 'new' : (active === confirmInput ? 'confirm' : null);
    return {
      newValue: newInput ? newInput.value : '',
      confirmValue: confirmInput ? confirmInput.value : '',
      focused: focused,
      selectionStart: focused && typeof active.selectionStart === 'number' ? active.selectionStart : null,
      selectionEnd: focused && typeof active.selectionEnd === 'number' ? active.selectionEnd : null
    };
  }

  function restoreComposerState(state) {
    if (!state) return;
    const newInput = tbody.querySelector('[data-reset-new]');
    const confirmInput = tbody.querySelector('[data-reset-confirm]');
    if (newInput) newInput.value = state.newValue;
    if (confirmInput) confirmInput.value = state.confirmValue;
    const toFocus = state.focused === 'new' ? newInput : (state.focused === 'confirm' ? confirmInput : null);
    if (!toFocus) return;
    toFocus.focus();
    if (state.selectionStart != null && state.selectionEnd != null) {
      try { toFocus.setSelectionRange(state.selectionStart, state.selectionEnd); } catch (e) { /* no-op */ }
    }
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  tbody.addEventListener('click', (e) => {
    const approveId = e.target.getAttribute && e.target.getAttribute('data-approve');
    const rejectId = e.target.getAttribute && e.target.getAttribute('data-reject');
    const resetId = e.target.getAttribute && e.target.getAttribute('data-reset');
    if (approveId) {
      window.TCCAccounts.approve(approveId).then((account) => {
        if (account) toast(account.name + '\u2019s account was approved', 'success');
        render();
      });
    } else if (rejectId) {
      window.TCCAccounts.reject(rejectId).then((account) => {
        if (account) toast(account.name + '\u2019s request was declined', 'error');
        render();
      });
    } else if (resetId) {
      revealedReset = null;
      composerId = resetId;
      render();
      const first = tbody.querySelector('[data-reset-new]');
      if (first) first.focus();
    } else if (e.target.closest && e.target.closest('[data-cancel-reset]')) {
      composerId = null;
      render();
    } else if (e.target.getAttribute && e.target.getAttribute('data-submit-reset')) {
      const id = e.target.getAttribute('data-submit-reset');
      const newInput = tbody.querySelector('[data-reset-new]');
      const confirmInput = tbody.querySelector('[data-reset-confirm]');
      const newPassword = newInput ? newInput.value : '';
      const confirmPassword = confirmInput ? confirmInput.value : '';
      if (!newPassword || !confirmPassword) { toast('Fill in both password fields', 'error'); return; }
      if (newPassword.length < 6) { toast('Password must be at least 6 characters', 'error'); return; }
      if (newPassword !== confirmPassword) { toast('Passwords don\u2019t match', 'error'); return; }

      window.TCCAccounts.resetPassword(id, newPassword).then((result) => {
        if (result.error) { toast(result.error, 'error'); return; }
        composerId = null;
        revealedReset = { id: id, name: result.name, email: result.email, newPassword: result.newPassword };
        render();
      });
    } else if (e.target.closest && e.target.closest('[data-copy-reset]')) {
      const input = tbody.querySelector('[data-reset-value]');
      if (!input) return;
      const finish = () => toast('Password copied', 'success');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(input.value).then(finish).catch(() => {
          input.select();
          document.execCommand('copy');
          finish();
        });
      } else {
        input.select();
        document.execCommand('copy');
        finish();
      }
    } else if (e.target.closest && e.target.closest('[data-close-reset]')) {
      revealedReset = null;
      render();
    }
  });

  // Enter submits the reset-password composer (from either field), Escape
  // cancels it — same as a normal form, even though this isn't a <form>.
  tbody.addEventListener('keydown', (e) => {
    if (!composerId) return;
    const inField = e.target && (e.target.hasAttribute('data-reset-new') || e.target.hasAttribute('data-reset-confirm'));
    if (!inField) return;
    if (e.key === 'Enter') {
      e.preventDefault();
      const btn = tbody.querySelector('[data-submit-reset="' + composerId + '"]');
      if (btn) btn.click();
    } else if (e.key === 'Escape') {
      composerId = null;
      render();
    }
  });

  // Re-render once the silent auto-reconnect to the saved data file
  // finishes (see accounts.js), and again any time the connected file
  // changes (connect / disconnect / new data loaded).
  window.TCCAccounts.ready.then(render);
  window.addEventListener('tcc-accounts:changed', render);
  render();
})();
