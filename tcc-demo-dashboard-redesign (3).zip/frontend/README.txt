TALISAY CITY COLLEGE - MANAGEMENT SYSTEM (HTML / CSS / JS)
=============================================================

Framework-free site built on top of the original login page design.
Nothing in the original login markup, styling, or behaviour was
changed. Everything below was added alongside it.


PROJECT STRUCTURE
--------------------
Files are grouped by role so a bug in one area is easy to isolate.
Open the matching folder instead of hunting through one flat list.

  index.html                 home page
  login.html                 student/teacher sign in
  signup.html                account request
  forgot-password.html
  change-password.html
  logout.html
  login-admin.html           redirect stub -> admin/
  teacher-dashboard.html
  student-dashboard.html

  admin/
    index.html                admin sign in
    dashboard.html             admin dashboard shell

  css/  (split by concern, loaded in this order on every page -
         identical output to one file, just organized for faster
         debugging)
    01-base.css               tokens, reset, auth-page primitives
                               (veil bg, hero/panel, form, buttons, toasts)
    02-home.css               index.html: navbar, hero, about, features,
                               college info, offense tables, contact, footer
    03-auth.css               login/signup/forgot/change/logout extras
                               (back-home link, role tabs, ghost buttons)
    04-dashboard.css          shared sidebar/topbar shell, cards, tables,
                               badges - all three dashboards
    05-signup-approvals.css   signup.html role picker + admin Approvals
    06-modules-shared.css     Grades / Announcements / Feedback
                               (all three dashboards)
    07-modules-student.css    Profile / Registration / Enrollment /
                               Schedule / Attendance (student dashboard only)
    08-responsive.css         breakpoint overrides for everything above,
                               plus the sitewide keyboard focus ring -
                               loads last so it wins the cascade
    11-global-search.css      admin/dashboard.html ONLY (not every page,
                               unlike 01-08 above) - the Global Search
                               overlay and its sidebar/topbar entry
                               points, see MODULE 7 below
    13-dashboard-salesops.css Overview/dashboard visual re-skin (dark,
                               single violet/blue accent, no green
                               anywhere - flat cards) - all three
                               dashboards, loads after 01-12
    14-dashboard-performance.css  Overview tab only: KPI icon chips, the
                               secondary admin stats row, and the
                               Academic Performance chart + Academic
                               Overview panel two-column layout - all
                               three dashboards, loads last

  assets/
    logo.png                  Talisay City College seal (favicon + branding)

  js/
    core/                      shared by every page
      script.js                auth flow, nav, shared UI wiring
      accounts.js               account-request "database" (signup/approval)
      darkveil.js               animated background (auth pages)
      dashboard-portal.js       shared dashboard shell (sidebar, routing)
      global-search.js          admin-only: search Students / Teachers /
                                 Subjects / Sections / Announcements / Pages
                                 (see MODULE 7 below)
      academic-performance.js   Overview tab: renders the Academic
                                 Performance chart (avg grade per term,
                                 from TCCGrades, scoped per role) and the
                                 Academic Overview rate panel (attendance/
                                 pass/verification rates, from TCCGrades +
                                 TCCAttendance). No new API calls - reads
                                 the same data layers each dashboard
                                 already loads. Guarded by #perfChart /
                                 #opsRows presence.

    modules/                   data + UI shared across dashboards
      announcements.js
      attendance.js
      enrollments.js
      feedback.js
      grades.js
      notifications.js
      profiles.js
      registrations.js
      schedules.js

    teacher/
      teacher-portal.js         teacher-dashboard-only behaviour

    admin/                      admin-dashboard-only UI per module
      admin-approvals.js
      admin-content.js
      admin-enrollment-mgmt.js
      admin-grades.js
      admin-notifications.js
      admin-schedule.js
      admin-students.js


TO DEBUG SOMETHING
----------------------
- Wrong data / logic on any dashboard -> check js/modules/<name>.js
  first (that's the shared "database" + core behaviour).
- Something only wrong on the ADMIN view of a module -> check
  js/admin/admin-<name>.js (UI wiring only, loaded on
  admin/dashboard.html).
- Something only wrong on the TEACHER dashboard ->
  js/teacher/teacher-portal.js.
- Sidebar, routing between sections, or the mobile drawer ->
  js/core/dashboard-portal.js.
- Login/signup/session/redirects -> js/core/script.js and
  js/core/accounts.js.
- Layout, spacing, or colors -> find the matching file in css/ above
  (e.g. dashboard sidebar looks wrong -> css/04-dashboard.css;
  something's off on the home page -> css/02-home.css). Each file's
  own header comment says exactly which pages use it.
- A style change isn't showing up? Check you edited the right
  numbered file - css/08-responsive.css loads last and can override
  earlier files at the breakpoint you're viewing.

File paths in HTML are relative - root pages use js/... and css/...,
while admin/index.html and admin/dashboard.html use ../js/... and
../css/... since they sit one folder deeper.


PAGES
--------

MODULE 1 - Home Page (index.html)
Responsive nav bar (with mobile drawer), hero, About the System,
System Features, College Information, Contact section (with working
demo form), and footer.

MODULE 2 - Authentication
- login.html - one plain sign in form shared by students and teachers
  (no role picker in the UI). Includes a small "Looking for the admin
  portal?" link to admin/, plus a link to signup.html for people who
  don't have an account yet. On a successful sign-in it has to guess
  the role from the email typed in (see note below), then sends the
  user to student-dashboard.html or teacher-dashboard.html.
- signup.html - account request form for students and teachers (role
  picker, name, email, program/department, password). Submitting it
  doesn't create a usable account - it creates a PENDING request that
  an admin has to approve first (see "Account approvals" below).
  Until then, signing in with that email on login.html is blocked
  with an "awaiting admin approval" message.
- student-dashboard.html / teacher-dashboard.html - role-specific
  dashboards, each with a collapsible sidebar (drawer on mobile,
  fixed on desktop from "lg" up) and its own nav - Overview / Profile
  / Registration / Enrollment / Class schedule / Attendance / Grades
  / Announcements / Feedback for students, Overview / Classes /
  Gradebook / Timetable / Announcements / Feedback for teachers. Nav
  items switch sections client-side via the URL hash (#grades,
  #classes, etc.) using dashboard-portal.js. Most data on them is
  placeholder/demo content - see "Wire up real auth" below. GRADES,
  ANNOUNCEMENTS, FEEDBACK, REGISTRATION, ENROLLMENT AND ATTENDANCE
  ARE THE EXCEPTION - see Modules 5 and 6 below.
- admin/index.html - a separate, standalone admin portal (same
  design, intentionally not merged with the student/teacher tabs).
  This page is NOT LINKED from the main nav or footer - it's reached
  only by going directly to /admin. Serve the folder (see "Run"
  below) so /admin resolves to admin/index.html automatically. On a
  successful sign-in it sends every admin straight to
  admin/dashboard.html - there's only one admin role, so there's
  nothing to guess.
- admin/dashboard.html - the admin console. Sidebar nav: Overview /
  Approvals / Students / Registrations / Enrollments / Class Schedule
  / Attendance / Grades / Staff / Announcements / Feedback /
  Notifications. STAFF IS THE ONLY SECTION STILL PLACEHOLDER DEMO
  DATA - everything else is wired to real records; see Modules 5 and
  6 below for what each one does. Several nav items carry a live
  badge with a pending/scheduled count (Approvals, Registrations,
  Enrollments, Grades, Notifications). Also has a Global Search (search
  icon on mobile / "Search…" button at the top of the sidebar on
  desktop, or Ctrl K) covering Students, Teachers, Subjects, Sections,
  Announcements and Pages - see Module 7 below.
- login-admin.html - kept only as a redirect to admin/, in case the
  old URL is bookmarked anywhere. Safe to delete once nothing links
  to it.
- forgot-password.html - UI only
- change-password.html - UI only (includes a simple strength meter)
- logout.html - logout confirmation UI (no longer linked from the
  dashboards - see note below; kept here in case you want to bring
  the confirmation step back)

MODULE 5 - Grades, Announcements & Feedback (all three dashboards)
Unlike the rest of each dashboard, these three sections are wired to
real, shared records instead of hardcoded demo rows:
- GRADES - teachers enter a grade (student name + email, subject,
  term, midterm/final scores, remarks) from the Gradebook section on
  teacher-dashboard.html. It shows up automatically on that student's
  Grades section on student-dashboard.html, matched by email - the
  student needs to be signed in with the same email the teacher
  entered (see data-tcc-session / login.html). If nothing matches
  yet, the Grades table falls back to its placeholder rows instead of
  looking empty.
- ANNOUNCEMENTS - teachers can post to their own students; admin can
  post to everyone, students only, or staff only. Every dashboard's
  Announcements section reads from the same shared list, filtered to
  what that role should see. A handful of seed announcements ship
  built in so the section never looks empty out of the box.
- FEEDBACK & SUGGESTIONS - students and teachers can submit a comment
  or suggestion (with a category) from a Feedback section on their
  dashboard, and see their own submissions with admin's response once
  it's answered. Admin's Feedback section lists everything submitted,
  with a Respond action (an inline expand row, not a page navigation)
  that records the reply and marks the item resolved; the sidebar and
  Overview show a live count of how many are still awaiting a
  response.

MODULE 6 - Admin management interfaces
The rest of the admin console - each backed by its own data layer
file, same "no real backend yet, mirrored to localStorage" approach
as Module 5:
- APPROVALS (accounts.js) - account sign-up requests. Unchanged from
  before; the only one of these that also saves a JSON snapshot to
  disk.
- STUDENTS (profiles.js) - the full student roster: add a profile,
  edit one (click Edit - it re-populates the form above the table),
  or delete one. Seeds with a handful of demo students on first run,
  fully editable/deletable from there (unlike Announcements'
  protected seed).
- REGISTRATIONS (registrations.js) - term registration requests
  submitted from a student's Registration tab (school year/semester,
  regular/irregular). Approve or reject each one; the student's
  status badge and registration history update to match.
- ENROLLMENTS (enrollments.js) - subject-enrollment requests
  submitted from a student's Enrollment tab ("Available subjects"),
  approve/reject each one, PLUS a direct "assign a subject" form that
  creates an already-approved record without waiting for a request.
- CLASS SCHEDULE (schedules.js) - create/edit/delete schedule entries
  (subject, section, day, time, room, teacher). Seeds with the
  classes already shown elsewhere on first run, fully editable from
  there. A teacher's Timetable tab reads their own entries from this
  list.
- ATTENDANCE (attendance.js) - view, search, and edit attendance
  records inline (a status dropdown right in the table), or GENERATE
  a day's records for the whole student roster in one click (skips
  anyone who already has one for that subject/date). A student's
  Attendance tab shows their real records here once any exist.
- GRADES (grades.js, extended) - every grade a teacher has entered
  from their Gradebook, with a Verify action (adds an adminStatus
  separate from the passing/failing academic status) and the ability
  to edit or remove any record. Any edit - by teacher or admin -
  resets a verified grade back to "needs review".
- ANNOUNCEMENTS (announcements.js, extended) - now supports Edit in
  addition to post/delete, for any non-seed announcement regardless
  of who posted it (the admin console is the full management view).
- FEEDBACK (feedback.js, extended) - now also supports Delete,
  alongside the existing Respond flow from Module 5.
- NOTIFICATIONS (notifications.js) - distinct from Announcements:
  create a notification for everyone / all students / all staff / one
  specific person, send it immediately or SCHEDULE it for later. A
  scheduled notification flips to "Sent" automatically once its time
  arrives (checked on load and every 30s while the admin dashboard is
  open) - there's no recipient-facing inbox yet, so sent
  notifications currently only show up in this admin list.

MODULE 7 - Global search (admin/dashboard.html only)
Search across Students, Teachers, Subjects, Sections, Announcements and
Pages (the sidebar nav itself) from one place instead of hunting through
each section individually:
- Opened via the search icon in the mobile topbar, the "Search…" button
  at the top of the sidebar (desktop, where the topbar is hidden), or the
  Ctrl K / Cmd K keyboard shortcut from anywhere on the page.
- Results are grouped by category as you type, each showing a title plus
  a short subtitle (e.g. a student's program/section, a subject's
  teacher(s) and class count). A "No results found" message shows once
  there's a query with nothing matching it, and a clear (✕) button
  appears next to the search box once there's something to clear.
- No new backend calls or search endpoint - it filters whatever
  js/modules/*.js has already loaded for that dashboard (profiles.js,
  staff.js, sections.js, announcements.js, schedules.js), the same
  "database" every other admin screen renders from. SUBJECTS ISN'T ITS
  OWN TABLE - those results are the distinct subject names found across
  Class Schedule entries.
- Clicking a result closes the search panel, jumps to that record's
  existing page (via the URL hash, same routing as the sidebar nav), and
  either reuses that page's own [data-filter] table search to narrow
  straight to it (Students, Teachers, Subjects → Class Schedule,
  Sections) or, for Announcements which has no search box of its own,
  scrolls to and briefly highlights the matching row instead.
- See js/core/global-search.js and css/11-global-search.css.


FILES
--------
- styles.css - mobile-first responsive breakpoints throughout,
  defined once at the top of the file and used consistently
  everywhere:
    xs  - default, below 576px
    sm  - min-width: 576px
    md  - min-width: 768px
    lg  - min-width: 992px
    xl  - min-width: 1200px
    xxl - min-width: 1400px
- script.js - original login logic untouched (now guarded so it
  doesn't error on pages without a login form); new page behaviour is
  appended below a clearly marked divider
- dashboard-portal.js - shared behaviour for the three sidebar
  dashboards: opens/closes the mobile drawer, switches .portal-view
  sections via the URL hash, and wires up any
  input[data-filter="#id"] to live-filter that table's rows. Also
  holds the student-dashboard-only additions (Profile, and the
  student side of Modules 5 & 6 - Grades, Announcements, Feedback,
  Registration, Subject enrollment, Attendance), each guarded by
  checking the relevant elements exist first.
- accounts.js - the account-request "database" behind sign-up +
  approval. window.TCCAccounts exposes createRequest, findByEmail,
  all, pending, approve, reject. Every request starts
  status: 'pending'. This is a placeholder for a real backend, same
  spirit as signInWithPassword in script.js - swap it for real API
  calls (create request / list pending / approve / reject) when you
  have one. Loaded by login.html, signup.html, and
  admin/dashboard.html.

  STORAGE: fully automatic, no setup required. Every create/approve/
  reject is saved two ways at once, with no prompts and no manual
  step:
    1. Mirrored into localStorage immediately - silent, always-on,
       and shared by every page in the same browser, so signup ->
       admin approval -> sign-in works end to end with zero setup.
    2. A real tcc-accounts.json snapshot (every account, all fields)
       is downloaded to the device automatically after every change -
       an actual file on disk, with no "connect a file" click needed
       first.
  Each page that uses accounts (login.html, signup.html,
  admin/dashboard.html) also shows a small "Data file" banner
  ([data-tcc-file-status] in the markup, wired up automatically by
  accounts.js). It's optional: clicking Create data file / Open
  existing file there connects one specific file via the browser's
  File System Access API, so future changes are written straight
  into that one file (silently, no repeat prompts) instead of
  triggering a fresh download each time. The picked file's handle is
  remembered (via IndexedDB) so it reconnects silently next time, as
  long as the browser still trusts the permission.
    - The File System Access connect option is only supported in
      Chromium browsers (Chrome, Edge, Opera). In Firefox/Safari the
      banner instead offers Download a snapshot now / Load file
      buttons - the automatic per-change download above already
      works everywhere, including Firefox/Safari.
    - Passwords are stored in plain text in all of this (localStorage
      AND the downloaded JSON) - fine for this demo, replace with a
      real backend that hashes them before this goes anywhere real.
- admin/admin-approvals.js - renders the Approvals table from
  accounts.js and wires up its Approve/Reject buttons. Loaded only on
  admin/dashboard.html. Every APPROVED row also gets a Reset password
  button (POST /api/admin/users/:id/reset-password - see
  backend/src/routes/admin.js): the backend generates a new random
  password, hashes it, and returns the plaintext exactly once. It's
  shown in an inline row under the account (same expand-under-the-row
  pattern as the Feedback respond panel - no modal) with a Copy
  button, so the admin can hand it to the user. Nothing decrypts an
  existing password - bcrypt hashes aren't reversible by design -
  this only ever issues a brand-new one.
- grades.js - the Gradebook/Grades "database" behind Module 5.
  Simpler than accounts.js: mirrored to localStorage only (no JSON
  download - grades don't need a portable snapshot the way account
  requests do). window.TCCGrades exposes all, forStudent(email),
  byTeacher(email), add, update, remove, computeStatus. Loaded by
  student-dashboard.html and teacher-dashboard.html.
- announcements.js - the Announcements "database" behind Module 5.
  Same localStorage-only approach as grades.js, plus a small in-code
  SEED list (not persisted, so it can't duplicate itself) supplying
  the starting demo announcements. window.TCCAnnouncements exposes
  all, forAudience(role), byPoster(name), add, remove. Loaded by all
  three dashboards.
- feedback.js - the Feedback & suggestions "database" behind Module
  5. Same localStorage-only approach, starts empty like accounts.js's
  request list. window.TCCFeedback exposes all, forUser(email),
  pendingCount, add, respond(id, text). Loaded by all three
  dashboards.
- teacher-portal.js - teacher-dashboard-only behaviour for Module 5:
  the Gradebook form + table, posting/managing class announcements,
  and submitting feedback. Guarded by element presence, same
  convention as admin/admin-approvals.js. Loaded only on
  teacher-dashboard.html.
- admin/admin-content.js - admin-dashboard-only behaviour for Module
  5, extended for Module 6: posting/editing/managing college-wide
  announcements, and the Feedback review/respond/delete table. Loaded
  only on admin/dashboard.html.
- darkveil.js - animated WebGL background, unchanged

MODULE 6 FILES
------------------
- profiles.js - the Student Profile Management "database". Fully
  admin-editable (unlike announcements.js's protected seed): seeds a
  handful of demo students into localStorage once on first run, then
  they're freely add/edit/delete-able from there. window.TCCProfiles
  exposes all, findByEmail, add, update, remove.
- registrations.js - term registration requests. Starts empty, same
  as accounts.js. window.TCCRegistrations exposes all, forStudent,
  pendingCount, add, approve, reject.
- enrollments.js - subject-enrollment requests, plus direct admin
  assignment. Starts empty. window.TCCEnrollments exposes all,
  forStudent, pendingCount, add, assign, approve, reject.
- schedules.js - class schedule entries. Same admin-editable seed
  pattern as profiles.js. window.TCCSchedules exposes all,
  byTeacherName, add, update, remove.
- attendance.js - attendance records. Same admin-editable seed
  pattern as profiles.js/schedules.js. window.TCCAttendance exposes
  all, forStudent, add, update, remove, generateForClass
  (bulk-creates one record per current student profile for a
  subject/date).
- notifications.js - admin notifications, distinct from
  announcements. Starts empty. window.TCCNotifications exposes all,
  forRecipient, scheduledCount, add, checkScheduled, cancel, remove.
- admin/admin-students.js - Student Profile Management UI (add/edit/
  delete form + roster table). Loaded only on admin/dashboard.html.
- admin/admin-enrollment-mgmt.js - Registration Management (approve/
  reject) and Subject Enrollment Management (approve/reject/assign)
  UI in one file, since both are the same review-queue pattern.
  Loaded only on admin/dashboard.html.
- admin/admin-schedule.js - Class Schedule Management (add/edit/
  delete form + table) and Attendance Management (generate + inline
  edit + table) UI in one file. Loaded only on admin/dashboard.html.
- admin/admin-grades.js - Grade Management UI: every teacher-entered
  grade, with Verify and Remove actions. Loaded only on
  admin/dashboard.html.
- admin/admin-notifications.js - Notification Management UI: create/
  send/schedule form + table, with Cancel (for scheduled) and Delete.
  Loaded only on admin/dashboard.html.
- Placeholder content: college name, stats, and contact details are
  all placeholders - search-and-replace "Northbridge College" and the
  numbers in index.html with your real details.


RUN
------
Open index.html directly, or serve the folder:
  python3 -m http.server 8000


ACCOUNT REQUESTS & APPROVAL
-------------------------------
login.html's signInWithPassword() now checks accounts.js first: if
the typed email matches a request, it's blocked while status is
'pending' or 'rejected', and only signs in once an admin has approved
it from admin/dashboard.html -> Approvals. Emails that were never
submitted through signup.html fall back to the old placeholder
behaviour (any 6+ character password succeeds), so the rest of the
demo still works without creating accounts first - remove that
fallback once every account goes through sign-up for real.


BACKEND INTEGRATION (Phase 1 - done)
-----------------------------------------
Auth now runs against a real Node.js + Express + MySQL API in
/backend (sibling folder to this one) instead of localStorage:
- js/core/accounts.js was rewritten to call the backend
  (createRequest, approve, reject, and a new login()), keeping the
  exact same public interface so admin-approvals.js needed NO
  CHANGES.
- js/core/script.js's signInWithPassword() now calls
  TCCAccounts.login() for a real bcrypt-checked password instead of
  the old placeholder ("any 6+ char password works" is gone). The
  admin login form (admin/index.html) now also loads accounts.js and
  rejects sign-in if the backend says the account's role isn't admin.
- The admin dashboard stores its JWT in localStorage (key
  tcc-admin-token) and sends it as Authorization: Bearer <token> on
  every Approvals request; it's cleared on logout.
- js/core/accounts.js points at http://localhost:4000/api by default
  - set window.TCC_API_BASE before it loads (or edit the constant) to
  point at a different backend URL in production.
- The old "Data file" (File System Access / auto-download JSON)
  machinery is gone - the database is the source of truth now. The
  same on-page widget is reused to show backend connection status on
  the admin dashboard only.

See backend/README.md for setup (install, .env, MySQL schema,
creating the first admin account, running the server).

Everything else - Grades, Announcements, Feedback, Students,
Registrations, Enrollments, Schedule, Attendance, Notifications - is
NOT part of this phase and still runs on the original localStorage
"database" files described above (grades.js, profiles.js, etc.).


WIRE UP REAL AUTH
---------------------
Each login page still uses the same placeholder signInWithPassword()
/ signInWithGoogle() functions in script.js - replace those with real
requests to your backend, and replace accounts.js with real
create-request / list-pending / approve / reject API calls. The
forgot-password, change-password, and logout pages are UI only and
don't call any backend yet.

login.html has no Student/Teacher picker, so with no backend to say
which one someone is, the redirect to student-dashboard.html /
teacher-dashboard.html is guessed from the email typed in: anything
containing "teacher@" goes to the teacher dashboard, everything else
goes to the student one (see data-auto-role in login.html /
script.js). THIS IS A PLACEHOLDER, NOT REAL ACCESS CONTROL - replace
it with the role your backend returns for the authenticated user.
Admin sign-in (admin/index.html) doesn't need this guess - it always
sends the user to admin/dashboard.html via
data-dashboard="dashboard.html" on its form, so once real auth is
wired up that part needs no changes.

Every dashboard's "Log out" links go straight out - there's no
confirmation step (see logout.html above if you want one back).
Student and teacher land on the home page (index.html); admin lands
back on the admin sign-in page (admin/index.html), since that portal
is kept separate from the rest of the site.
