const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET;
const EXPIRES_IN = process.env.JWT_EXPIRES_IN || '12h';

if (!SECRET || SECRET === 'change_this_to_a_long_random_string') {
  // Loud on purpose — a default/missing secret would make every issued
  // token forgeable. Fail fast rather than run insecurely.
  // (Skip the throw only for quick local smoke-testing if you must.)
  console.warn('[auth] WARNING: JWT_SECRET is missing or still set to the placeholder value. ' +
    'Set a real secret in backend/.env before using this outside local dev.');
}

function signToken(payload) {
  return jwt.sign(payload, SECRET || 'insecure-dev-only-secret', { expiresIn: EXPIRES_IN });
}

function verifyToken(token) {
  return jwt.verify(token, SECRET || 'insecure-dev-only-secret');
}

module.exports = { signToken, verifyToken };
