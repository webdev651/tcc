const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

function serialize(row) {
  return {
    id: String(row.id),
    studentEmail: row.student_email,
    studentName: row.student_name,
    subject: row.subject,
    term: row.term,
    teacherEmail: row.teacher_email || '',
    teacherName: row.teacher_name || '',
    midterm: row.midterm === null ? null : Number(row.midterm),
    final: row.final === null ? null : Number(row.final),
    remarks: row.remarks || '',
    adminStatus: row.admin_status,
    enteredAt: row.entered_at,
    updatedAt: row.updated_at
  };
}

router.use(requireAuth);

// GET /api/grades — admin=all, teacher=own, student=own
router.get('/', async (req, res) => {
  try {
    const { role, email } = req.user;
    let rows;
    if (role === 'admin') {
      [rows] = await pool.query('SELECT * FROM grades ORDER BY updated_at DESC');
    } else if (role === 'teacher') {
      [rows] = await pool.query('SELECT * FROM grades WHERE teacher_email = ? ORDER BY updated_at DESC', [email]);
    } else {
      [rows] = await pool.query('SELECT * FROM grades WHERE student_email = ? ORDER BY updated_at DESC', [email]);
    }
    return res.json({ grades: rows.map(serialize) });
  } catch (err) {
    console.error('GET /api/grades failed:', err);
    return res.status(500).json({ message: 'Could not load grades.' });
  }
});

// POST /api/grades — teacher or admin
router.post('/', requireRole('teacher', 'admin'), async (req, res) => {
  try {
    const b = req.body || {};
    const studentEmail = String(b.studentEmail || '').trim().toLowerCase();
    const studentName = String(b.studentName || '').trim();
    const subject = String(b.subject || '').trim();
    if (!studentEmail || !studentName || !subject) {
      return res.status(400).json({ message: 'Student, and subject are required.' });
    }

    const teacherEmail = req.user.role === 'teacher' ? req.user.email : (b.teacherEmail || null);
    const teacherName = req.user.role === 'teacher' ? req.user.name : (b.teacherName || null);

    const [result] = await pool.query(
      `INSERT INTO grades
        (student_email, student_name, subject, term, teacher_email, teacher_name, midterm, final, remarks, admin_status)
       VALUES (?,?,?,?,?,?,?,?,?, 'pending')`,
      [
        studentEmail, studentName, subject, b.term || 'Midterm',
        teacherEmail, teacherName,
        b.midterm ?? null, b.final ?? null, b.remarks || null
      ]
    );
    const [rows] = await pool.query('SELECT * FROM grades WHERE id = ?', [result.insertId]);
    return res.status(201).json({ grade: serialize(rows[0]) });
  } catch (err) {
    console.error('POST /api/grades failed:', err);
    return res.status(500).json({ message: 'Could not create the grade record.' });
  }
});

// PUT /api/grades/:id — teacher (own) or admin
router.put('/:id', requireRole('teacher', 'admin'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ message: 'Invalid grade id.' });

    const [existing] = await pool.query('SELECT * FROM grades WHERE id = ?', [id]);
    if (!existing.length) return res.status(404).json({ message: 'Grade record not found.' });
    const cur = existing[0];
    if (req.user.role === 'teacher' && cur.teacher_email !== req.user.email) {
      return res.status(403).json({ message: 'You can only edit grades you entered.' });
    }

    const b = req.body || {};
    await pool.query(
      `UPDATE grades SET subject=?, term=?, midterm=?, final=?, remarks=? WHERE id=?`,
      [
        b.subject ?? cur.subject, b.term ?? cur.term,
        b.midterm !== undefined ? b.midterm : cur.midterm,
        b.final !== undefined ? b.final : cur.final,
        b.remarks !== undefined ? b.remarks : cur.remarks,
        id
      ]
    );
    const [rows] = await pool.query('SELECT * FROM grades WHERE id = ?', [id]);
    return res.json({ grade: serialize(rows[0]) });
  } catch (err) {
    console.error('PUT /api/grades/:id failed:', err);
    return res.status(500).json({ message: 'Could not update the grade record.' });
  }
});

// POST /api/grades/:id/verify — admin only
router.post('/:id/verify', requireRole('admin'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ message: 'Invalid grade id.' });
    const [existing] = await pool.query('SELECT * FROM grades WHERE id = ?', [id]);
    if (!existing.length) return res.status(404).json({ message: 'Grade record not found.' });

    await pool.query(`UPDATE grades SET admin_status = 'verified' WHERE id = ?`, [id]);
    const [rows] = await pool.query('SELECT * FROM grades WHERE id = ?', [id]);
    return res.json({ grade: serialize(rows[0]) });
  } catch (err) {
    console.error('POST /api/grades/:id/verify failed:', err);
    return res.status(500).json({ message: 'Could not verify the grade record.' });
  }
});

// DELETE /api/grades/:id — teacher (own) or admin
router.delete('/:id', requireRole('teacher', 'admin'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ message: 'Invalid grade id.' });

    const [existing] = await pool.query('SELECT * FROM grades WHERE id = ?', [id]);
    if (!existing.length) return res.json({ deleted: false });
    if (req.user.role === 'teacher' && existing[0].teacher_email !== req.user.email) {
      return res.status(403).json({ message: 'You can only delete grades you entered.' });
    }

    const [result] = await pool.query('DELETE FROM grades WHERE id = ?', [id]);
    return res.json({ deleted: result.affectedRows > 0 });
  } catch (err) {
    console.error('DELETE /api/grades/:id failed:', err);
    return res.status(500).json({ message: 'Could not delete the grade record.' });
  }
});

module.exports = router;
