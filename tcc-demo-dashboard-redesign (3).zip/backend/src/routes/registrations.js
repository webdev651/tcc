const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

function serialize(row) {
  return {
    id: String(row.id),
    studentEmail: row.student_email,
    studentName: row.student_name,
    term: row.term,
    yearLevel: row.year_level || '',
    type: row.type,
    status: row.status,
    submittedAt: row.submitted_at,
    decidedAt: row.decided_at
  };
}

router.use(requireAuth);

// GET /api/registrations — admin=all, student=own
router.get('/', async (req, res) => {
  try {
    const { role, email } = req.user;
    let rows;
    if (role === 'admin') {
      [rows] = await pool.query('SELECT * FROM registrations ORDER BY submitted_at DESC');
    } else {
      [rows] = await pool.query('SELECT * FROM registrations WHERE student_email = ? ORDER BY submitted_at DESC', [email]);
    }
    return res.json({ registrations: rows.map(serialize) });
  } catch (err) {
    console.error('GET /api/registrations failed:', err);
    return res.status(500).json({ message: 'Could not load registrations.' });
  }
});

// POST /api/registrations — student
router.post('/', requireRole('student'), async (req, res) => {
  try {
    const b = req.body || {};
    const term = String(b.term || '').trim();
    if (!term) return res.status(400).json({ message: 'Term is required.' });

    const [result] = await pool.query(
      `INSERT INTO registrations (student_email, student_name, term, year_level, type, status)
       VALUES (?,?,?,?,?, 'pending')`,
      [req.user.email, req.user.name, term, b.yearLevel || null, b.type || 'Regular']
    );
    const [rows] = await pool.query('SELECT * FROM registrations WHERE id = ?', [result.insertId]);
    return res.status(201).json({ registration: serialize(rows[0]) });
  } catch (err) {
    console.error('POST /api/registrations failed:', err);
    return res.status(500).json({ message: 'Could not submit the registration.' });
  }
});

async function decide(req, res, newStatus) {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ message: 'Invalid registration id.' });
    const [existing] = await pool.query('SELECT * FROM registrations WHERE id = ?', [id]);
    if (!existing.length) return res.status(404).json({ message: 'Registration not found.' });

    await pool.query('UPDATE registrations SET status=?, decided_at=NOW() WHERE id=?', [newStatus, id]);
    const [rows] = await pool.query('SELECT * FROM registrations WHERE id = ?', [id]);
    return res.json({ registration: serialize(rows[0]) });
  } catch (err) {
    console.error('POST /api/registrations/:id/' + newStatus + ' failed:', err);
    return res.status(500).json({ message: 'Could not update the registration.' });
  }
}

// POST /api/registrations/:id/approve — admin only
router.post('/:id/approve', requireRole('admin'), (req, res) => decide(req, res, 'approved'));
// POST /api/registrations/:id/reject — admin only
router.post('/:id/reject', requireRole('admin'), (req, res) => decide(req, res, 'rejected'));

module.exports = router;
