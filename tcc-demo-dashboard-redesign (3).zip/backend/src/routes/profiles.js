const express = require('express');
const pool = require('../db');
const { requireAuth, requireAdmin, requireRole } = require('../middleware/auth');

const router = express.Router();

function serialize(row) {
  return {
    id: String(row.id),
    name: row.name,
    email: row.email,
    studentId: row.student_id || '',
    program: row.program || '',
    yearLevel: row.year_level || '',
    section: row.section || '',
    status: row.status,
    dateOfBirth: row.date_of_birth || '',
    sex: row.sex || '',
    civilStatus: row.civil_status || '',
    nationality: row.nationality || '',
    religion: row.religion || '',
    address: row.address || '',
    mobile: row.mobile || '',
    guardianName: row.guardian_name || '',
    guardianContact: row.guardian_contact || '',
    adviser: row.adviser || '',
    dateAdmitted: row.date_admitted || '',
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

/**
 * GET /api/profiles/me
 * The signed-in student's own profile record — read-only self-service.
 * Placed above the blanket `requireAdmin` gate below and scoped with its
 * own requireRole('student') instead, since a student may only ever see
 * their own record (identity comes from the verified JWT, never a
 * client-supplied id/email) and every other route on this router is
 * admin-only roster management.
 *
 * Falls back to the bare account details (name/email/Student ID/program,
 * with section and year level blank) when this student doesn't have an
 * admin-maintained student_profiles row yet — e.g. a freshly-approved
 * signup an admin hasn't assigned a section to. Used by
 * student-dashboard.html's Profile tab.
 */
router.get('/me', requireAuth, requireRole('student'), async (req, res) => {
  try {
    const email = String(req.user.email || '').trim().toLowerCase();
    const [rows] = await pool.query(
      'SELECT * FROM student_profiles WHERE LOWER(email) = ? ORDER BY id DESC LIMIT 1',
      [email]
    );
    if (rows.length) {
      return res.json({ profile: serialize(rows[0]) });
    }

    const [userRows] = await pool.query('SELECT * FROM users WHERE id = ?', [req.user.id]);
    const u = userRows[0];
    return res.json({
      profile: {
        id: '',
        name: u ? u.name : (req.user.name || ''),
        email: u ? u.email : email,
        studentId: u ? (u.student_id || '') : '',
        program: u ? (u.detail || '') : '',
        yearLevel: '',
        section: '',
        status: 'Regular',
        dateOfBirth: '', sex: '', civilStatus: '', nationality: '', religion: '',
        address: '', mobile: '', guardianName: '', guardianContact: '', adviser: '', dateAdmitted: '',
        createdAt: u ? u.created_at : null,
        updatedAt: null
      }
    });
  } catch (err) {
    console.error('GET /api/profiles/me failed:', err);
    return res.status(500).json({ message: 'Could not load your profile.' });
  }
});

// All student-profile routes are admin-only (roster management screen).
router.use(requireAuth, requireAdmin);

// GET /api/profiles
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM student_profiles ORDER BY name ASC');
    return res.json({ profiles: rows.map(serialize) });
  } catch (err) {
    console.error('GET /api/profiles failed:', err);
    return res.status(500).json({ message: 'Could not load student profiles.' });
  }
});

// POST /api/profiles
router.post('/', async (req, res) => {
  try {
    const b = req.body || {};
    const name = String(b.name || '').trim();
    const email = String(b.email || '').trim().toLowerCase();
    if (!name || !email) {
      return res.status(400).json({ message: 'Name and email are required.' });
    }

    const [result] = await pool.query(
      `INSERT INTO student_profiles
        (name, email, student_id, program, year_level, section, status,
         date_of_birth, sex, civil_status, nationality, religion, address, mobile,
         guardian_name, guardian_contact, adviser, date_admitted)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        name, email, b.studentId || null, b.program || null, b.yearLevel || null, b.section || null,
        b.status || 'Regular', b.dateOfBirth || null, b.sex || null, b.civilStatus || null,
        b.nationality || null, b.religion || null, b.address || null, b.mobile || null,
        b.guardianName || null, b.guardianContact || null, b.adviser || null, b.dateAdmitted || null
      ]
    );
    const [rows] = await pool.query('SELECT * FROM student_profiles WHERE id = ?', [result.insertId]);
    return res.status(201).json({ profile: serialize(rows[0]) });
  } catch (err) {
    console.error('POST /api/profiles failed:', err);
    return res.status(500).json({ message: 'Could not create the student profile.' });
  }
});

// PUT /api/profiles/:id
router.put('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ message: 'Invalid profile id.' });

    const [existing] = await pool.query('SELECT * FROM student_profiles WHERE id = ?', [id]);
    if (!existing.length) return res.status(404).json({ message: 'Student profile not found.' });

    const b = req.body || {};
    const cur = existing[0];
    await pool.query(
      `UPDATE student_profiles SET
        name=?, email=?, student_id=?, program=?, year_level=?, section=?, status=?,
        date_of_birth=?, sex=?, civil_status=?, nationality=?, religion=?, address=?, mobile=?,
        guardian_name=?, guardian_contact=?, adviser=?, date_admitted=?
       WHERE id=?`,
      [
        b.name ?? cur.name, (b.email ?? cur.email).toLowerCase?.() || cur.email,
        b.studentId ?? cur.student_id, b.program ?? cur.program, b.yearLevel ?? cur.year_level,
        b.section ?? cur.section, b.status ?? cur.status, b.dateOfBirth ?? cur.date_of_birth,
        b.sex ?? cur.sex, b.civilStatus ?? cur.civil_status, b.nationality ?? cur.nationality,
        b.religion ?? cur.religion, b.address ?? cur.address, b.mobile ?? cur.mobile,
        b.guardianName ?? cur.guardian_name, b.guardianContact ?? cur.guardian_contact,
        b.adviser ?? cur.adviser, b.dateAdmitted ?? cur.date_admitted, id
      ]
    );
    const [rows] = await pool.query('SELECT * FROM student_profiles WHERE id = ?', [id]);
    return res.json({ profile: serialize(rows[0]) });
  } catch (err) {
    console.error('PUT /api/profiles/:id failed:', err);
    return res.status(500).json({ message: 'Could not update the student profile.' });
  }
});

// DELETE /api/profiles/:id
router.delete('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ message: 'Invalid profile id.' });
    const [result] = await pool.query('DELETE FROM student_profiles WHERE id = ?', [id]);
    return res.json({ deleted: result.affectedRows > 0 });
  } catch (err) {
    console.error('DELETE /api/profiles/:id failed:', err);
    return res.status(500).json({ message: 'Could not delete the student profile.' });
  }
});

module.exports = router;
