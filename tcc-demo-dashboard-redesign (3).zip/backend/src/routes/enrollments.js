const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

function serialize(row) {
  let subjects = [];
  try { subjects = typeof row.subjects === 'string' ? JSON.parse(row.subjects) : (row.subjects || []); }
  catch (e) { subjects = []; }
  return {
    id: String(row.id),
    studentEmail: row.student_email,
    studentName: row.student_name,
    term: row.term || '',
    subjects,
    totalUnits: row.total_units,
    status: row.status,
    source: row.source,
    submittedAt: row.submitted_at,
    decidedAt: row.decided_at
  };
}

function computeUnits(subjects) {
  if (!Array.isArray(subjects)) return 0;
  return subjects.reduce((sum, s) => sum + (Number(s && s.units) || 0), 0);
}

router.use(requireAuth);

// GET /api/enrollments — admin=all, student=own
router.get('/', async (req, res) => {
  try {
    const { role, email } = req.user;
    let rows;
    if (role === 'admin') {
      [rows] = await pool.query('SELECT * FROM enrollments ORDER BY submitted_at DESC');
    } else {
      [rows] = await pool.query('SELECT * FROM enrollments WHERE student_email = ? ORDER BY submitted_at DESC', [email]);
    }
    return res.json({ enrollments: rows.map(serialize) });
  } catch (err) {
    console.error('GET /api/enrollments failed:', err);
    return res.status(500).json({ message: 'Could not load enrollments.' });
  }
});

// POST /api/enrollments — student request
router.post('/', requireRole('student'), async (req, res) => {
  try {
    const b = req.body || {};
    const subjects = Array.isArray(b.subjects) ? b.subjects : [];
    const [result] = await pool.query(
      `INSERT INTO enrollments (student_email, student_name, term, subjects, total_units, status, source)
       VALUES (?,?,?,?,?, 'pending', 'request')`,
      [req.user.email, req.user.name, b.term || null, JSON.stringify(subjects), computeUnits(subjects)]
    );
    const [rows] = await pool.query('SELECT * FROM enrollments WHERE id = ?', [result.insertId]);
    return res.status(201).json({ enrollment: serialize(rows[0]) });
  } catch (err) {
    console.error('POST /api/enrollments failed:', err);
    return res.status(500).json({ message: 'Could not submit the enrollment request.' });
  }
});

// POST /api/enrollments/assign — admin assigns directly, pre-approved
router.post('/assign', requireRole('admin'), async (req, res) => {
  try {
    const b = req.body || {};
    const studentEmail = String(b.studentEmail || '').trim().toLowerCase();
    const studentName = String(b.studentName || '').trim();
    if (!studentEmail || !studentName) {
      return res.status(400).json({ message: 'Student is required.' });
    }
    const subjects = Array.isArray(b.subjects) ? b.subjects : [];
    const [result] = await pool.query(
      `INSERT INTO enrollments (student_email, student_name, term, subjects, total_units, status, source, decided_at)
       VALUES (?,?,?,?,?, 'approved', 'assigned', NOW())`,
      [studentEmail, studentName, b.term || null, JSON.stringify(subjects), computeUnits(subjects)]
    );
    const [rows] = await pool.query('SELECT * FROM enrollments WHERE id = ?', [result.insertId]);
    return res.status(201).json({ enrollment: serialize(rows[0]) });
  } catch (err) {
    console.error('POST /api/enrollments/assign failed:', err);
    return res.status(500).json({ message: 'Could not assign the enrollment.' });
  }
});

async function decide(req, res, newStatus) {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ message: 'Invalid enrollment id.' });
    const [existing] = await pool.query('SELECT * FROM enrollments WHERE id = ?', [id]);
    if (!existing.length) return res.status(404).json({ message: 'Enrollment not found.' });

    await pool.query('UPDATE enrollments SET status=?, decided_at=NOW() WHERE id=?', [newStatus, id]);
    const [rows] = await pool.query('SELECT * FROM enrollments WHERE id = ?', [id]);
    return res.json({ enrollment: serialize(rows[0]) });
  } catch (err) {
    console.error('POST /api/enrollments/:id/' + newStatus + ' failed:', err);
    return res.status(500).json({ message: 'Could not update the enrollment.' });
  }
}

// POST /api/enrollments/:id/approve — admin only
router.post('/:id/approve', requireRole('admin'), (req, res) => decide(req, res, 'approved'));
// POST /api/enrollments/:id/reject — admin only
router.post('/:id/reject', requireRole('admin'), (req, res) => decide(req, res, 'rejected'));

module.exports = router;
