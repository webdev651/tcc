const express = require('express');
const pool = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

function serialize(row) {
  return {
    id: String(row.id),
    title: row.title,
    message: row.message,
    recipientType: row.recipient_type,
    recipientEmail: row.recipient_email || '',
    scheduledFor: row.scheduled_for,
    status: row.status,
    createdAt: row.created_at,
    sentAt: row.sent_at
  };
}

// Admin-only, same as the original localStorage version.
router.use(requireAuth, requireAdmin);

// GET /api/notifications — promotes any due "scheduled" notification to
// "sent" first, so the frontend's checkScheduled() is just a refresh().
router.get('/', async (req, res) => {
  try {
    await pool.query(
      `UPDATE notifications SET status='sent', sent_at=NOW()
       WHERE status='scheduled' AND scheduled_for IS NOT NULL AND scheduled_for <= NOW()`
    );
    const [rows] = await pool.query('SELECT * FROM notifications ORDER BY created_at DESC');
    return res.json({ notifications: rows.map(serialize) });
  } catch (err) {
    console.error('GET /api/notifications failed:', err);
    return res.status(500).json({ message: 'Could not load notifications.' });
  }
});

// POST /api/notifications
router.post('/', async (req, res) => {
  try {
    const b = req.body || {};
    const title = String(b.title || '').trim();
    const message = String(b.message || '').trim();
    if (!title || !message) return res.status(400).json({ message: 'Title and message are required.' });

    const scheduledFor = b.scheduledFor || null;
    const status = scheduledFor && new Date(scheduledFor) > new Date() ? 'scheduled' : 'sent';

    const [result] = await pool.query(
      `INSERT INTO notifications (title, message, recipient_type, recipient_email, scheduled_for, status, sent_at)
       VALUES (?,?,?,?,?,?,?)`,
      [
        title, message, b.recipientType || 'all', b.recipientEmail || null,
        scheduledFor, status, status === 'sent' ? new Date() : null
      ]
    );
    const [rows] = await pool.query('SELECT * FROM notifications WHERE id = ?', [result.insertId]);
    return res.status(201).json({ notification: serialize(rows[0]) });
  } catch (err) {
    console.error('POST /api/notifications failed:', err);
    return res.status(500).json({ message: 'Could not create the notification.' });
  }
});

// POST /api/notifications/:id/cancel — only meaningful for scheduled ones
router.post('/:id/cancel', async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ message: 'Invalid notification id.' });
    const [result] = await pool.query(`DELETE FROM notifications WHERE id = ? AND status = 'scheduled'`, [id]);
    if (!result.affectedRows) return res.json({ notification: null });
    return res.json({ notification: { id: String(id) } });
  } catch (err) {
    console.error('POST /api/notifications/:id/cancel failed:', err);
    return res.status(500).json({ message: 'Could not cancel the notification.' });
  }
});

// DELETE /api/notifications/:id
router.delete('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ message: 'Invalid notification id.' });
    const [result] = await pool.query('DELETE FROM notifications WHERE id = ?', [id]);
    return res.json({ deleted: result.affectedRows > 0 });
  } catch (err) {
    console.error('DELETE /api/notifications/:id failed:', err);
    return res.status(500).json({ message: 'Could not delete the notification.' });
  }
});

module.exports = router;
