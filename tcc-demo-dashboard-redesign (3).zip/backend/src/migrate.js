const pool = require('./db');

/* =========================================================================
   Self-healing migrations.
   Whenever a new table is added to schema.sql for a feature after someone
   has already set up their database (e.g. teacher_students for the
   "assign a student to a teacher" / master list feature), running the
   full schema.sql again is the "proper" fix — but it's easy to forget,
   and the error that results ("Table '...' doesn't exist", ER_NO_SUCH_TABLE)
   is confusing if you don't know that's the cause.

   This runs the handful of CREATE TABLE IF NOT EXISTS statements for
   tables added after the original schema on every server start. It's
   fully idempotent and a no-op once the table already exists, so it's
   safe to leave in permanently — no separate "migrate" step to remember.
   ========================================================================= */

const STATEMENTS = [
  {
    name: 'teacher_students',
    sql: `CREATE TABLE IF NOT EXISTS teacher_students (
      id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      teacher_email  VARCHAR(190) NOT NULL,
      teacher_name   VARCHAR(150) NULL,
      student_email  VARCHAR(190) NOT NULL,
      student_name   VARCHAR(150) NOT NULL,
      assigned_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_teacher_student (teacher_email, student_email),
      INDEX idx_teacher_students_teacher (teacher_email),
      INDEX idx_teacher_students_student (student_email)
    ) ENGINE=InnoDB`
  },
  {
    name: 'masterlist_shares',
    sql: `CREATE TABLE IF NOT EXISTS masterlist_shares (
      id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      teacher_email  VARCHAR(190) NOT NULL,
      teacher_name   VARCHAR(150) NOT NULL,
      section        VARCHAR(50)  NULL,
      students       JSON NOT NULL,
      sent_by_name   VARCHAR(150) NOT NULL,
      sent_by_email  VARCHAR(190) NULL,
      sent_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      viewed_at      DATETIME NULL,
      INDEX idx_masterlist_shares_teacher (teacher_email)
    ) ENGINE=InnoDB`
  },
  {
    name: 'announcement_reads',
    sql: `CREATE TABLE IF NOT EXISTS announcement_reads (
      id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      announcement_id  INT UNSIGNED NOT NULL,
      reader_email     VARCHAR(190) NOT NULL,
      read_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_announcement_reads (announcement_id, reader_email),
      CONSTRAINT fk_announcement_reads_announcement FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE CASCADE,
      INDEX idx_announcement_reads_reader (reader_email)
    ) ENGINE=InnoDB`
  },
  {
    name: 'events',
    sql: `CREATE TABLE IF NOT EXISTS events (
      id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      title              VARCHAR(200) NOT NULL,
      description        VARCHAR(500) NULL,
      type               ENUM('announcement','registration_deadline','enrollment_deadline','academic_deadline','school_event','activity','exam')
                           NOT NULL DEFAULT 'school_event',
      event_date         DATETIME NOT NULL,
      audience           ENUM('all','student','teacher') NOT NULL DEFAULT 'all',
      created_by_name    VARCHAR(150) NULL,
      created_by_email   VARCHAR(190) NULL,
      created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_events_date (event_date),
      INDEX idx_events_audience (audience),
      INDEX idx_events_type (type)
    ) ENGINE=InnoDB`
  },
  // ---- Phase 3 — normalized schema (see schema.sql for the full design
  // notes). Order matters: each table below only references ones created
  // before it (students/teachers -> sections -> student_section_assignments
  // -> masterlists -> teacher_masterlist_assignments).
  {
    name: 'students',
    sql: `CREATE TABLE IF NOT EXISTS students (
      id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id           INT UNSIGNED NOT NULL,
      student_id        VARCHAR(20)  NOT NULL,
      program           VARCHAR(150) NULL,
      year_level        VARCHAR(50)  NULL,
      status            ENUM('Regular','Irregular','Inactive') NOT NULL DEFAULT 'Regular',
      date_of_birth     VARCHAR(50)  NULL,
      sex               VARCHAR(20)  NULL,
      civil_status      VARCHAR(50)  NULL,
      nationality       VARCHAR(80)  NULL,
      religion          VARCHAR(80)  NULL,
      address           VARCHAR(255) NULL,
      mobile            VARCHAR(50)  NULL,
      guardian_name     VARCHAR(150) NULL,
      guardian_contact  VARCHAR(50)  NULL,
      date_admitted     VARCHAR(50)  NULL,
      created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      UNIQUE KEY uq_students_user (user_id),
      UNIQUE KEY uq_students_student_id (student_id),
      INDEX idx_students_program (program)
    ) ENGINE=InnoDB`
  },
  {
    name: 'teachers',
    sql: `CREATE TABLE IF NOT EXISTS teachers (
      id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id        INT UNSIGNED NOT NULL,
      department     VARCHAR(150) NULL,
      subjects       VARCHAR(255) NULL,
      created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      CONSTRAINT fk_teachers_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      UNIQUE KEY uq_teachers_user (user_id),
      INDEX idx_teachers_department (department)
    ) ENGINE=InnoDB`
  },
  {
    name: 'sections',
    sql: `CREATE TABLE IF NOT EXISTS sections (
      id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      section_code        VARCHAR(50)  NOT NULL,
      program             VARCHAR(150) NULL,
      year_level          VARCHAR(50)  NULL,
      term                VARCHAR(100) NOT NULL,
      adviser_teacher_id  INT UNSIGNED NULL,
      created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      CONSTRAINT fk_sections_adviser FOREIGN KEY (adviser_teacher_id) REFERENCES teachers(id) ON DELETE SET NULL,
      UNIQUE KEY uq_sections_code_term (section_code, term),
      INDEX idx_sections_adviser (adviser_teacher_id)
    ) ENGINE=InnoDB`
  },
  {
    name: 'student_section_assignments',
    sql: `CREATE TABLE IF NOT EXISTS student_section_assignments (
      id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      student_id     INT UNSIGNED NOT NULL,
      section_id     INT UNSIGNED NOT NULL,
      status         ENUM('active','dropped','completed') NOT NULL DEFAULT 'active',
      assigned_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      CONSTRAINT fk_ssa_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
      CONSTRAINT fk_ssa_section FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE,
      UNIQUE KEY uq_ssa_student_section (student_id, section_id),
      INDEX idx_ssa_section (section_id)
    ) ENGINE=InnoDB`
  },
  {
    name: 'masterlists',
    sql: `CREATE TABLE IF NOT EXISTS masterlists (
      id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      section_id     INT UNSIGNED NOT NULL,
      term           VARCHAR(100) NOT NULL,
      title          VARCHAR(200) NULL,
      generated_by   INT UNSIGNED NULL,
      generated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_masterlists_section FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE,
      CONSTRAINT fk_masterlists_generated_by FOREIGN KEY (generated_by) REFERENCES users(id) ON DELETE SET NULL,
      UNIQUE KEY uq_masterlists_section_term (section_id, term),
      INDEX idx_masterlists_generated_by (generated_by)
    ) ENGINE=InnoDB`
  },
  {
    name: 'teacher_masterlist_assignments',
    sql: `CREATE TABLE IF NOT EXISTS teacher_masterlist_assignments (
      id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      masterlist_id       INT UNSIGNED NOT NULL,
      teacher_id          INT UNSIGNED NOT NULL,
      assigned_by         INT UNSIGNED NULL,
      notification_title  VARCHAR(200) NULL,
      notification_body   TEXT NULL,
      status              ENUM('sent','viewed') NOT NULL DEFAULT 'sent',
      assigned_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      viewed_at           DATETIME NULL,
      CONSTRAINT fk_tma_masterlist FOREIGN KEY (masterlist_id) REFERENCES masterlists(id) ON DELETE CASCADE,
      CONSTRAINT fk_tma_teacher FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
      CONSTRAINT fk_tma_assigned_by FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
      UNIQUE KEY uq_tma_masterlist_teacher (masterlist_id, teacher_id),
      INDEX idx_tma_teacher (teacher_id)
    ) ENGINE=InnoDB`
  }
];

async function runMigrations() {
  for (const stmt of STATEMENTS) {
    try {
      const [existing] = await pool.query(
        `SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema = ? AND table_name = ?`,
        [process.env.DB_NAME || 'tcc_college', stmt.name]
      );
      const existed = !!existing[0].n;
      await pool.query(stmt.sql);
      if (!existed) console.log('🔧 Created missing table "' + stmt.name + '" (auto-migration).');
    } catch (err) {
      console.error('⚠️  Could not ensure table "' + stmt.name + '" exists:', err.message);
    }
  }

  await ensureStudentIdColumn();
  await ensureNotificationsColumns();
  await ensureNotificationsRelatedMasterlistColumn();
  await ensureSectionsSentColumns();
  await ensureEventsTypeEnum();
  await ensureAnnouncementsColumns();
  await backfillNormalizedTables();
}

/* =========================================================================
   backfillNormalizedTables()
   One-time (but safe-to-repeat) copy of existing email/string-matched data
   into the Phase 3 normalized tables (students, teachers, sections,
   student_section_assignments — see schema.sql). Every statement is
   INSERT IGNORE against a table with a UNIQUE key covering exactly what's
   being inserted, so re-running this on every server start never creates
   duplicates and never overwrites a row someone has since edited directly
   in the new tables.

   Sections backfilled this way get an "Unspecified Term" placeholder,
   since student_profiles.section was never term-scoped — rename/split
   those sections by real term once Section Management is wired to these
   tables.
   ========================================================================= */
const LEGACY_SECTION_TERM = 'Unspecified Term';

async function backfillNormalizedTables() {
  try {
    await pool.query(`
      INSERT IGNORE INTO students
        (user_id, student_id, program, year_level, status, date_of_birth, sex,
         civil_status, nationality, religion, address, mobile,
         guardian_name, guardian_contact, date_admitted)
      SELECT u.id, u.student_id, sp.program, sp.year_level,
             IFNULL(sp.status, 'Regular'), sp.date_of_birth, sp.sex,
             sp.civil_status, sp.nationality, sp.religion, sp.address, sp.mobile,
             sp.guardian_name, sp.guardian_contact, sp.date_admitted
      FROM users u
      LEFT JOIN student_profiles sp ON LOWER(sp.email) = LOWER(u.email)
      WHERE u.role = 'student' AND u.status = 'approved' AND u.student_id IS NOT NULL
    `);

    await pool.query(`
      INSERT IGNORE INTO teachers (user_id, department, subjects)
      SELECT u.id, u.detail, st.subjects
      FROM users u
      LEFT JOIN staff st ON LOWER(st.email) = LOWER(u.email)
      WHERE u.role = 'teacher' AND u.status = 'approved'
    `);

    await pool.query(
      `INSERT IGNORE INTO sections (section_code, term)
       SELECT DISTINCT TRIM(sp.section), ?
       FROM student_profiles sp
       WHERE sp.section IS NOT NULL AND TRIM(sp.section) <> ''`,
      [LEGACY_SECTION_TERM]
    );

    await pool.query(
      `INSERT IGNORE INTO student_section_assignments (student_id, section_id)
       SELECT s.id, sec.id
       FROM student_profiles sp
       JOIN users u ON LOWER(u.email) = LOWER(sp.email)
       JOIN students s ON s.user_id = u.id
       JOIN sections sec ON sec.section_code = TRIM(sp.section) AND sec.term = ?
       WHERE sp.section IS NOT NULL AND TRIM(sp.section) <> ''`,
      [LEGACY_SECTION_TERM]
    );
  } catch (err) {
    console.error('⚠️  Could not backfill normalized tables:', err.message);
  }
}

/* Adds the notifications columns (recipient_type, recipient_email,
   scheduled_for, status, sent_at) to databases whose "notifications" table
   was created before these fields existed in schema.sql. Same idempotent,
   check-then-add pattern as the other ensure*Column() functions — safe to
   run on every server start. */
async function ensureNotificationsColumns() {
  const dbName = process.env.DB_NAME || 'tcc_college';
  const columns = [
    { name: 'recipient_type', ddl: `ADD COLUMN recipient_type ENUM('all','student','teacher','specific') NOT NULL DEFAULT 'all' AFTER message` },
    { name: 'recipient_email', ddl: `ADD COLUMN recipient_email VARCHAR(190) NULL AFTER recipient_type` },
    { name: 'scheduled_for', ddl: `ADD COLUMN scheduled_for DATETIME NULL AFTER recipient_email` },
    { name: 'status', ddl: `ADD COLUMN status ENUM('scheduled','sent') NOT NULL DEFAULT 'sent' AFTER scheduled_for` },
    { name: 'sent_at', ddl: `ADD COLUMN sent_at DATETIME NULL AFTER status` }
  ];
  for (const col of columns) {
    try {
      const [cols] = await pool.query(
        `SELECT COUNT(*) AS n FROM information_schema.columns
         WHERE table_schema = ? AND table_name = 'notifications' AND column_name = ?`,
        [dbName, col.name]
      );
      if (!cols[0].n) {
        await pool.query(`ALTER TABLE notifications ${col.ddl}`);
        console.log('🔧 Added missing column "notifications.' + col.name + '" (auto-migration).');
      }
    } catch (err) {
      console.error('⚠️  Could not ensure notifications.' + col.name + ' column exists:', err.message);
    }
  }
}

/* Adds notifications.related_masterlist_id to databases that were set up
   before "Send Masterlist to Teacher" existed — same idempotent,
   check-then-add pattern as ensureStudentIdColumn() above. */
async function ensureNotificationsRelatedMasterlistColumn() {
  const dbName = process.env.DB_NAME || 'tcc_college';
  try {
    const [cols] = await pool.query(
      `SELECT COUNT(*) AS n FROM information_schema.columns
       WHERE table_schema = ? AND table_name = 'notifications' AND column_name = 'related_masterlist_id'`,
      [dbName]
    );
    if (!cols[0].n) {
      await pool.query(`ALTER TABLE notifications ADD COLUMN related_masterlist_id INT UNSIGNED NULL AFTER sent_at`);
      await pool.query(`ALTER TABLE notifications ADD INDEX idx_notifications_related_masterlist (related_masterlist_id)`);
      console.log('🔧 Added missing column "notifications.related_masterlist_id" (auto-migration).');
    }
  } catch (err) {
    console.error('⚠️  Could not ensure notifications.related_masterlist_id column exists:', err.message);
  }
}

/* Adds the Announcement Center columns (category, priority, status) to
   databases whose "announcements" table was created before these fields
   existed in schema.sql. Same idempotent, check-then-add pattern as the
   other ensure*Column() functions — safe to run on every server start. */
async function ensureAnnouncementsColumns() {
  const dbName = process.env.DB_NAME || 'tcc_college';
  const columns = [
    { name: 'category', ddl: `ADD COLUMN category ENUM('General','Academic','Enrollment','Registration','Schedule','Important') NOT NULL DEFAULT 'General' AFTER audience` },
    { name: 'priority', ddl: `ADD COLUMN priority ENUM('Low','Normal','High','Urgent') NOT NULL DEFAULT 'Normal' AFTER category` },
    { name: 'status', ddl: `ADD COLUMN status ENUM('Published','Draft','Archived') NOT NULL DEFAULT 'Published' AFTER priority` }
  ];
  for (const col of columns) {
    try {
      const [cols] = await pool.query(
        `SELECT COUNT(*) AS n FROM information_schema.columns
         WHERE table_schema = ? AND table_name = 'announcements' AND column_name = ?`,
        [dbName, col.name]
      );
      if (!cols[0].n) {
        await pool.query(`ALTER TABLE announcements ${col.ddl}`);
        console.log('🔧 Added missing column "announcements.' + col.name + '" (auto-migration).');
      }
    } catch (err) {
      console.error('⚠️  Could not ensure announcements.' + col.name + ' column exists:', err.message);
    }
  }
  try {
    await pool.query(
      `ALTER TABLE announcements
       ADD INDEX idx_announcements_category (category),
       ADD INDEX idx_announcements_priority (priority),
       ADD INDEX idx_announcements_status (status)`
    );
  } catch (err) {
    // ER_DUP_KEYNAME (1061) just means these indexes already exist — fine to ignore.
    if (err.errno !== 1061) console.error('⚠️  Could not ensure announcements category/priority/status indexes exist:', err.message);
  }
}

/* Adds sections.sent_to_teacher_id + sections.sent_at ("Send to Teacher")
   to databases whose "sections" table was created before this feature
   existed. Same idempotent, check-then-add pattern as the other
   ensure*Column() functions — safe to run on every server start. */
async function ensureSectionsSentColumns() {
  const dbName = process.env.DB_NAME || 'tcc_college';
  const columns = [
    { name: 'sent_to_teacher_id', ddl: `ADD COLUMN sent_to_teacher_id INT UNSIGNED NULL AFTER adviser_teacher_id` },
    { name: 'sent_at', ddl: `ADD COLUMN sent_at DATETIME NULL AFTER sent_to_teacher_id` }
  ];
  for (const col of columns) {
    try {
      const [cols] = await pool.query(
        `SELECT COUNT(*) AS n FROM information_schema.columns
         WHERE table_schema = ? AND table_name = 'sections' AND column_name = ?`,
        [dbName, col.name]
      );
      if (!cols[0].n) {
        await pool.query(`ALTER TABLE sections ${col.ddl}`);
        console.log('🔧 Added missing column "sections.' + col.name + '" (auto-migration).');
      }
    } catch (err) {
      console.error('⚠️  Could not ensure sections.' + col.name + ' column exists:', err.message);
    }
  }
}

/* Adds users.student_id (+ its UNIQUE index) to databases that were set up
   before the Student ID Number field existed. Same idempotent,
   check-then-add pattern as the table migrations above — safe to run on
   every server start. */
async function ensureStudentIdColumn() {
  const dbName = process.env.DB_NAME || 'tcc_college';
  try {
    const [cols] = await pool.query(
      `SELECT COUNT(*) AS n FROM information_schema.columns
       WHERE table_schema = ? AND table_name = 'users' AND column_name = 'student_id'`,
      [dbName]
    );
    if (!cols[0].n) {
      await pool.query(`ALTER TABLE users ADD COLUMN student_id VARCHAR(20) NULL AFTER detail`);
      console.log('🔧 Added missing column "users.student_id" (auto-migration).');
    }

    const [idx] = await pool.query(
      `SELECT COUNT(*) AS n FROM information_schema.statistics
       WHERE table_schema = ? AND table_name = 'users' AND index_name = 'uq_users_student_id'`,
      [dbName]
    );
    if (!idx[0].n) {
      await pool.query(`ALTER TABLE users ADD UNIQUE KEY uq_users_student_id (student_id)`);
      console.log('🔧 Added missing unique index "uq_users_student_id" (auto-migration).');
    }
  } catch (err) {
    console.error('⚠️  Could not ensure users.student_id column/index exists:', err.message);
  }
}

/* Feature 5 (Calendar) added two more values — 'academic_deadline' and
   'exam' — to events.type after some databases already had the table
   from Feature 4. A plain CREATE TABLE IF NOT EXISTS (the STATEMENTS
   list above) is a no-op once a table exists, so a MODIFY COLUMN is
   needed to widen the ENUM on those. Reads COLUMN_TYPE back from
   information_schema rather than unconditionally re-running the ALTER
   every boot, since MySQL's SHOW/DESCRIBE echoes back the exact enum
   list you gave it (quoted, comma-separated, no spaces), so a plain
   string compare against the same literal is enough to tell "already
   applied" from "still needs it." */
async function ensureEventsTypeEnum() {
  const dbName = process.env.DB_NAME || 'tcc_college';
  const desired = "enum('announcement','registration_deadline','enrollment_deadline','academic_deadline','school_event','activity','exam')";
  try {
    const [cols] = await pool.query(
      `SELECT COLUMN_TYPE AS colType FROM information_schema.columns
       WHERE table_schema = ? AND table_name = 'events' AND column_name = 'type'`,
      [dbName]
    );
    if (!cols.length) return; // events table doesn't exist yet — the STATEMENTS loop above will create it with the right enum
    if (cols[0].colType !== desired) {
      await pool.query(
        `ALTER TABLE events MODIFY COLUMN type
         ENUM('announcement','registration_deadline','enrollment_deadline','academic_deadline','school_event','activity','exam')
         NOT NULL DEFAULT 'school_event'`
      );
      console.log('🔧 Widened "events.type" enum with academic_deadline/exam (auto-migration).');
    }
  } catch (err) {
    console.error('⚠️  Could not ensure events.type enum is up to date:', err.message);
  }
}

module.exports = { runMigrations };
